# Build on a Windows 11 x64 machine with Python 3.13 + Tk installed.
# This script never installs Python on the eventual user's computer.
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
Set-Location $root
$python = (Get-Command python -ErrorAction Stop).Source
& $python -c 'import sys, tkinter, _tkinter; assert sys.version_info[:2] == (3,13) and sys.maxsize > 2**32; t=tkinter.Tcl();print("Tcl/Tk:",t.eval("info patchlevel"))'
if ($LASTEXITCODE -ne 0) { throw 'Build Python 3.13/Tkinter not found' }
& $python -m pip install --disable-pip-version-check 'pyinstaller>=6.14,<7'
if ($LASTEXITCODE -ne 0) { throw 'Could not install PyInstaller in the build environment' }
Push-Location (Join-Path $root 'source')
try {
    & $python -m unittest discover -v
    if ($LASTEXITCODE -ne 0) { throw 'Source tests failed' }
} finally { Pop-Location }
& $python -m PyInstaller --noconfirm --clean --onedir --windowed --name FieldIndex --distpath "$root\buildout\dist" --workpath "$root\buildout\work" --specpath "$root\buildout\spec" --add-data "$root\ExtensionPacks;ExtensionPacks" --add-data "$root\source\capture;capture" "$root\source\fieldindex.py"
if ($LASTEXITCODE -ne 0) { throw 'PyInstaller failed' }
$exe = Join-Path $root 'buildout\dist\FieldIndex\FieldIndex.exe'
if (-not (Test-Path $exe)) { throw 'Compiled program missing' }
$smoke = Join-Path $root 'buildout\smoke-result.txt'
if (Test-Path $smoke) { Remove-Item $smoke -Force }
$p = Start-Process -FilePath $exe -ArgumentList @('--installer-smoke-test', ('"' + $smoke + '"')) -PassThru
if (-not $p.WaitForExit(45000)) { $p.Kill(); throw 'Frozen executable smoke test timed out' }
if ($p.ExitCode -ne 0 -or -not (Test-Path $smoke) -or -not ((Get-Content $smoke -Raw).StartsWith('OK:'))) {
    if (Test-Path $smoke) { Get-Content $smoke }
    throw 'Frozen executable did not pass the GUI/SQLite smoke test'
}
$candidates = @(
    (Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6\ISCC.exe')
    'C:\Program Files\Inno Setup 6\ISCC.exe'
)
$iscc = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $iscc) { throw 'Inno Setup 6 not installed on this Windows BUILD machine. Get it from https://jrsoftware.org/isinfo.php' }
& $iscc "$root\installer\FieldIndex_Clean.iss"
if ($LASTEXITCODE -ne 0) { throw 'Inno Setup build failed' }
$setup=Join-Path $root 'buildout\release\FieldIndex_0_11_1_Offline_Setup_x64.exe'
if (-not (Test-Path $setup)) { throw 'Installer missing' }
Get-FileHash $setup -Algorithm SHA256 | Format-List
Write-Host ('OFFLINE INSTALLER READY: ' + $setup) -ForegroundColor Green
