# FieldIndex 0.11 — Commercial Installation & Operations Manual

**Product:** FieldIndex 0.11 (Extensible OSINT Research & Evidence Workbench)
**Target Platform:** Windows 11 (x64, per-user installation, zero administrator privileges required)
**Database Engine:** Local SQLite 3 (WAL mode, schema v8) at `%LOCALAPPDATA%\FieldIndex\cases.sqlite3`

> **Evidentiary & Operational Boundary:** FieldIndex is a local-first public-source research and evidence management workbench. A search snippet, matching handle, venue listing, or automated CLI hit is an **unverified lead**—never proof of account ownership, venue attendance, relationship conduct, or real-world identity. FieldIndex performs no login bypasses, paywall evasion, credential enumeration, or unattended scraping of member-gated communities.

---

## Part I: Installation & Deployment Guide

### 1. System Requirements
- **OS:** Windows 11 (64-bit) or Windows 10 (64-bit); also runs on Linux desktops with `python3-tk`.
- **Runtime:** Python 3.11, 3.12, or 3.13 with Tkinter (Python 3.13 recommended).
- **Privileges:** Standard non-admin Windows account (`%LOCALAPPDATA%` and `%APPDATA%` only).
- **IDE Requirement:** None. VS Code is not required.
- **Disk Space:** ~1 MB base app; ~250–450 MB per optional Maigret/Sherlock isolated venv.

### 2. Pre-Installation Preflight (Windows 11)
1. Extract the entire `FieldIndex_0_11_Complete_Release_v2.zip` archive to a permanent local folder (e.g., `C:\Tools\FieldIndex_0_11\`).
2. Verify Python 3.11+ and Tkinter:
   ```powershell
   py -3 -c "import sys, tkinter; print(sys.version); print('Tkinter OK')"
   ```
   If Python is missing:
   ```powershell
   winget install -e --id Python.Python.3.13
   ```
3. Run the non-destructive Windows preflight suite from the extracted folder:
   ```powershell
   powershell -NoProfile -ExecutionPolicy Bypass -File .\TOOLS\CHECK_ON_WINDOWS.ps1
   ```
   Verify all 53 unit and GUI tests pass and `source\capture\manifest.json` is detected.

### 3. Deployment Modes
- **Mode A — Standard Per-User Install (Recommended):** Close older FieldIndex versions and double-click `INSTALL_FIELD_INDEX_0_11.cmd`. Automatically creates a timestamped backup (`cases.pre_0_11_YYYYMMDD_HHMMSS.sqlite3`) of any existing case database, installs to `%LOCALAPPDATA%\Programs\FieldIndex011\`, and creates Desktop and Start Menu shortcuts.
- **Mode B — Portable Run (Zero Install):** Double-click `RUN_FIELD_INDEX_0_11.cmd` directly from the extracted folder.
- **Mode C — Compile Native Windows EXE & Inno Setup Installer:**
  1. Install PyInstaller: `py -3 -m pip install --upgrade pyinstaller`
  2. Run `BUILD_STANDALONE_ON_WINDOWS.cmd` (runs all 53 tests, compiles `compiled\FieldIndex011.exe` with `ExtensionPacks` and `source\capture` embedded, prints SHA-256).
  3. Optionally compile `source\installer.iss` with Inno Setup 6 (`AppId=FieldIndexResearchWorkbench`) to emit `FieldIndex_Setup_0_11_x64.exe`.

### 4. Optional Scanners & Extensions (Never Bundled or Auto-Installed)
- **Maigret Full Scanner:** Open **Maigret -> Install / repair Maigret** (or run `INSTALL_MAIGRET_FOR_FIELDINDEX.cmd`), OR place official `maigret_standalone.exe` in `%LOCALAPPDATA%\FieldIndex\tools\maigret\`. Click **Recheck installation** and **Probe version & flags**.
- **Sherlock Full Scanner:** Open **Sherlock -> Install / repair Sherlock** (or run `INSTALL_SHERLOCK_FOR_FIELDINDEX.cmd`). Click **Recheck installation** and **Probe version & flags**.
- **Restored Browser Capture Extension (Manifest V3):** Open `chrome://extensions` or `edge://extensions`, enable **Developer mode**, click **Load unpacked**, and select `source\capture`.
- **Brave Search API Key (Optional):** Set `BRAVE_SEARCH_API_KEY` or enter it when prompted in **Web discovery** (stored in RAM only).

---

## Part II: Commercial Operations & Workspace Reference

### 1. Case Setup, Scope & Intake
- Click **New case** in the left sidebar to create an isolated SQLite case (supports Greek, German, and full UTF-8 Unicode).
- Populate only verified clues in **Intake** (`subject`, `user`, `email`, `phone`, `ip`, `org`, `place`, `site`, `url`, `doi`, `phrase`, `goal`).
- Document **Case Scope & Lawful Authorization** (`Authority / permission basis`, `Permitted scope`, `Prohibited scope`) and click **Save case scope**.

### 2. Investigation Plan
- Reviews every derived route (`Web results`, `Archival lookup`, `DOI lookup`, `Exact email search`, `Handle API`, `Local tool`, `Catalogue API`, `Browser search`) before sending anything externally.
- Runs up to 3 concurrent asynchronous workers off the UI thread.
- Supports **Cancel pending sources** and **Retry failed or unfinished sources** across restarts.

### 3. Username Investigation Suite (`Usernames`, `Maigret`, `Sherlock`)
- **Usernames:** 10 direct public JSON APIs (`GitHub`, `GitLab`, `Codeberg`, `DEV Community`, `Hacker News`, `Lichess`, `Chess.com`, `Codewars`, `Keybase`, `English Wikipedia`).
- **Maigret:** Uncapped full-scan modes: `Top 500 sites`, `All supported sites (-a)`, `Filter by tags (--tags)`, `Specific sites (--site)`, and `Legacy 3-site compat`. Parses `--json simple` and NDJSON with TXT fallback. Appends a `Scan coverage summary` distinguishing `attempted`, `claimed`, `not_found`, `blocked`, `rate_limited`, `timed_out`, and `inconclusive`. Blocked/rate-limited sites are never reported as "no account."
- **Sherlock:** Uncapped full-site CSV scan with opt-in adult/NSFW checkbox, per-site timeout (12s), version/flag capability probing, and clean process-tree cancellation.

### 4. Guided Multi-Engine Dorking (`Google dorking` & `Google builder`)
- Supports Google, Bing, DuckDuckGo, Yahoo, Yandex, Baidu, and Ecosia with explicit `OPERATOR_MATRIX` transparency (omitting unsupported date/title/URL operators on non-supporting engines with clear notes).
- Normalizes internationalized domains (IDN) to punycode, sanitizes quoted `OR` clauses, and shows a `[PRIVACY NOTICE]` confirmation dialog whenever an outgoing query contains an email address or phone number.
- Includes saved per-case recipes, JSON plan export, and the legacy 4-mode `Walk me through it` builder.

### 5. Adult & Relationship Public Research (`Community sources` & `Extensions`)
- Install **Adult public research v2.0.0** under **Extensions** (73 curated public sources and 10 public-page recipes across Dallas/Fort Worth, wider Texas, US national, Europe, and international directories, including TABC, Texas Comptroller, colette Dallas, NLA-Dallas, Beyond Vanilla, DFW Dungeon, XCLUSIV Houston, SLS Texas, Dallas County DCHHS, Texas DSHS, OPEN, KAP, ASHA, CDC, Polyamory Europe, JOYclub HelpCenter, OnlyFans Transparency Center, Match Group, Bumble, and Pineapple Support).
- Click **Filter regions/categories** on any installed pack to hide categories or regions without rebuilding (`filters.json` persists across upgrades).
- Import reviewed custom directories via **Import website list from CSV** or **Import JSON directory** (strictly data-only: blocks `.py` payloads, ZIP bombs >1 MB, non-HTTPS schemes, credentials, custom ports, and IP literals).

### 6. Web Discovery, Local File Search, Browser Captures & Holehe
- **Web discovery:** DuckDuckGo/Brave Search web queries, connectivity check, local file literal search with SHA-256 digest (up to 8 MB, UTF-16/UTF-8, strips HTML scripts/styles), and deduplicated `fieldindex.capture.v1` JSON capture import.
- **Holehe OSINT:** Manual-only launcher for `https://holehe.org/` (distinct from `megadose/holehe` CLI), supporting `Username`, `Email`, `Phone`, and `IP address` intake autofill and optional unverified reference logging.

### 7. Evidence Review, Hypotheses, Overlap Deduplication & Defensible Reports
- **Immutable observations + editable reviews:** Double-click any entry to set an attribution decision (`Unreviewed`, `Same handle — identity not established`, `Confirmed public page`, `Corroborated fact`, `Rejected / false positive`, `Counterevidence`, `Inaccessible / blocked source`), separate `Published date` and `Claimed event date` from `Collected (UTC)`, and log counterevidence.
- **Group findings by URL:** Collapses overlapping Sherlock, Maigret, and API hits pointing to the same canonical URL into **one** public page observation labeled `Overlapping tools (1 page)`.
- **Case hypotheses:** Tracks claims alongside supporting observations, contradicting/alternative explanations, and missing evidence.
- **Exports & Backups:** Atomic temp-file writes for Markdown reports (`Export Markdown report`), `fieldindex.case.v3` JSON, formula-safe CSV, and integrity-checked SQLite backups (`PRAGMA integrity_check`).

---

## Part III: Security, Migration & Rollback
- `%LOCALAPPDATA%\FieldIndex\cases.sqlite3` is local plaintext SQLite; enable Windows BitLocker and avoid syncing to unencrypted cloud folders.
- Migrations `v6 -> v7 -> v8` are purely additive (`evidence_reviews`, `case_hypotheses`, `case_scope`).
- To roll back cleanly: close FieldIndex 0.11, move `cases.sqlite3` (and any `-wal`/`-shm` files) aside, restore `cases.pre_0_11_*.sqlite3` to `cases.sqlite3`, and reopen FieldIndex 0.10 or 0.6.
