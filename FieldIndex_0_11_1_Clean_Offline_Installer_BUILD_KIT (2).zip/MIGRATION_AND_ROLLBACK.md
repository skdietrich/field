# FieldIndex 0.11 — Data Migration and Rollback Guide

## Database Location
`%LOCALAPPDATA%\FieldIndex\cases.sqlite3`

FieldIndex 0.11 **never deletes or overwrites** existing v0.6–v0.10 cases, fields, records, annotations, runs, captures, publishers, recipes, or dork recipes.

## Schema Changes (Additive Only)
On first launch, `storage.apply_migrations()` runs idempotently inside transactions:
- Enables `PRAGMA journal_mode = WAL` and `PRAGMA foreign_keys = ON`.
- Preserves all v0.6–v0.10 tables untouched (including `schema_migrations` version `6`).
- **Migration v7:** Adds `evidence_reviews(record PRIMARY KEY, decision, published_date, event_date, counterevidence, reviewed_utc)` so original rows in `records` remain immutable while analyst attribution decisions and distinct source dates are stored separately.
- **Migration v8:** Adds `case_hypotheses(...)` and `case_scope(...)` for structured competing-explanation boards and lawful-scope documentation.

## Safe Upgrade Procedure
1. Close any running instance of FieldIndex 0.6–0.10.
2. Back up `%LOCALAPPDATA%\FieldIndex\cases.sqlite3` (either via **Evidence -> Back up all cases** or by running `INSTALL_FIELD_INDEX_0_11.cmd`, which automatically copies a timestamped `cases.pre_0_11_YYYYMMDD_HHMMSS.sqlite3` snapshot before launching).
3. Launch FieldIndex 0.11 (`RUN_FIELD_INDEX_0_11.cmd` or installed shortcut). Verify all existing cases and counts appear in **Dashboard** and **Evidence**.

## Rollback to FieldIndex 0.10 or 0.6
Because migrations v7 and v8 are purely additive tables, FieldIndex 0.10 can still read a v8 database, **however** for a clean rollback:
1. Close FieldIndex 0.11 completely (ensuring `-wal` and `-shm` files checkpoint cleanly).
2. Rename `%LOCALAPPDATA%\FieldIndex\cases.sqlite3` to `cases.0_11_backup.sqlite3` (and remove any stale `.sqlite3-wal` / `.sqlite3-shm` files).
3. Copy your pre-upgrade backup (`cases.pre_0_11_*.sqlite3`) back to `cases.sqlite3`.
4. Launch FieldIndex 0.10 or 0.6 and verify `PRAGMA integrity_check` via **Evidence -> Back up all cases**.

## Security Note on Local Data at Rest
`cases.sqlite3` is a local plaintext SQLite database. FieldIndex does **not** claim built-in database encryption. Protect sensitive cases with Windows BitLocker / full-disk encryption, OS user-account isolation, and encrypted archives when sharing exports.
