#define AppVersion "0.11.1"
[Setup]
AppId=FieldIndexResearchWorkbench
AppName=Field Index
AppVersion={#AppVersion}
VersionInfoVersion=0.11.1.0
AppPublisher=WolframTek
DefaultDirName={localappdata}\Programs\FieldIndex
DefaultGroupName=Field Index
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=..\buildout\release
OutputBaseFilename=FieldIndex_0_11_1_Offline_Setup_x64
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\FieldIndex.exe
CloseApplications=yes
RestartApplications=no
DisableProgramGroupPage=yes

[Files]
Source: "..\buildout\dist\FieldIndex\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\MANUAL.md"; DestDir: "{app}\Documentation"; Flags: ignoreversion
Source: "..\RELEASE_NOTES_0_11.md"; DestDir: "{app}\Documentation"; Flags: ignoreversion
Source: "..\MIGRATION_AND_ROLLBACK.md"; DestDir: "{app}\Documentation"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\Field Index"; Filename: "{app}\FieldIndex.exe"
Name: "{autodesktop}\Field Index"; Filename: "{app}\FieldIndex.exe"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: checkedonce

[Run]
Filename: "{app}\FieldIndex.exe"; Description: "Launch Field Index"; Flags: nowait postinstall skipifsilent

; No [UninstallDelete] entries: case databases and user files are never removed.
