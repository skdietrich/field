FIELD INDEX 0.11 | EXTENSIBLE OSINT RESEARCH & EVIDENCE WORKBENCH

See README_INSTALL_FIRST.txt, MAIGRET_QUICK_START.txt, SHERLOCK_QUICK_START.txt,
GOOGLE_DORKING_QUICK_START.txt, MIGRATION_AND_ROLLBACK.md, and RELEASE_NOTES_0_11.md.

Local case database: %LOCALAPPDATA%\FieldIndex\cases.sqlite3 (plaintext local SQLite;
protect with BitLocker/OS disk encryption and back up regularly via Evidence > Back up all cases).
Browser capture extension (Manifest V3): source\capture\ (load unpacked in Chrome/Edge).
