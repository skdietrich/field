"""Normalized upstream adapter metadata, error taxonomy, and source-dependency deduplication.

Prevents treating overlapping tool hits against the same underlying public page
as independent identity confirmations.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from urllib.parse import urlsplit, urlunsplit

OUTCOME_CATEGORIES = (
    "unavailable",
    "timeout",
    "throttled",
    "blocked/auth",
    "malformed",
    "transport_error",
    "no_observation",
    "candidate_public_page",
    "partial",
    "verified_public_page",
)


@dataclass(frozen=True)
class AdapterDescriptor:
    id: str
    version: str
    input_types: tuple[str, ...]
    source: str
    capabilities: tuple[str, ...]
    access_mode: str
    rate_policy: str
    visibility: str
    execution_method: str
    output_schema: str
    last_tested_utc: str
    license: str
    status: str

    def to_dict(self):
        return asdict(self)


ADAPTER_REGISTRY: tuple[AdapterDescriptor, ...] = (
    AdapterDescriptor(
        id="maigret-cli",
        version="0.11.0-adapter",
        input_types=("username",),
        source="https://github.com/soxoj/maigret",
        capabilities=("full_site_scan", "top_sites", "tag_filter", "site_filter", "json_report", "txt_fallback", "cancel"),
        access_mode="optional_local_cli",
        rate_policy="tool_managed_per_site_timeout",
        visibility="public_pages_only",
        execution_method="subprocess_argv",
        output_schema="fieldindex.observation.v1",
        last_tested_utc="2026-11-21",
        license="MIT (upstream tool installed separately by operator)",
        status="fixture_tested",
    ),
    AdapterDescriptor(
        id="sherlock-cli",
        version="0.11.0-adapter",
        input_types=("username",),
        source="https://github.com/sherlock-project/sherlock",
        capabilities=("full_site_scan", "opt_in_nsfw", "site_filter", "csv_report", "capability_probe", "cancel"),
        access_mode="optional_local_cli",
        rate_policy="tool_managed_per_site_timeout",
        visibility="public_pages_only",
        execution_method="subprocess_argv",
        output_schema="fieldindex.observation.v1",
        last_tested_utc="2026-11-21",
        license="MIT (upstream tool installed separately by operator)",
        status="fixture_tested",
    ),
    AdapterDescriptor(
        id="direct-handle-apis",
        version="0.11.0",
        input_types=("username",),
        source="10 documented public JSON endpoints (GitHub, GitLab, Codeberg, DEV, HN, Lichess, Chess.com, Codewars, Keybase, Wikipedia)",
        capabilities=("exact_handle_lookup", "http_status_classification"),
        access_mode="public_http_json",
        rate_policy="max_3_concurrent_requests",
        visibility="public_open",
        execution_method="urllib_https",
        output_schema="fieldindex.observation.v1",
        last_tested_utc="2026-11-21",
        license="Upstream public API terms apply",
        status="fixture_tested",
    ),
    AdapterDescriptor(
        id="dork-search-builder",
        version="0.11.0",
        input_types=("topic", "phrase", "domain", "date_range", "filetype"),
        source="Google, Bing, DuckDuckGo, Yahoo, Ecosia, Yandex, Baidu",
        capabilities=("operator_translation", "pack_scoping", "disclosure_warning", "recipe_export"),
        access_mode="manual_browser_handoff",
        rate_policy="operator_controlled",
        visibility="public_search_index",
        execution_method="browser_url",
        output_schema="fieldindex.search_plan.v1",
        last_tested_utc="2026-11-21",
        license="Internal stdlib module",
        status="unit_tested",
    ),
    AdapterDescriptor(
        id="holehe-web-portal",
        version="0.11.0",
        input_types=("username", "email", "phone", "ip"),
        source="https://holehe.org/",
        capabilities=("input_validation", "manual_portal_handoff", "unverified_reference_logging"),
        access_mode="manual_browser_handoff",
        rate_policy="operator_controlled",
        visibility="third_party_web_portal",
        execution_method="browser_url",
        output_schema="fieldindex.observation.v1",
        last_tested_utc="2026-11-21",
        license="External website; distinct from megadose/holehe CLI",
        status="manual_only",
    ),
    AdapterDescriptor(
        id="whatsmyname-archive",
        version="discontinued-2026-11-09",
        input_types=("username",),
        source="https://github.com/WebBreacher/WhatsMyName",
        capabilities=(),
        access_mode="discontinued_historical_snapshot",
        rate_policy="none",
        visibility="archived_reference_only",
        execution_method="none",
        output_schema="none",
        last_tested_utc="2026-11-21",
        license="Upstream license (archived)",
        status="discontinued",
    ),
)


def canonical_url(url: str) -> str:
    try:
        bits = urlsplit((url or "").strip())
        if bits.scheme not in ("http", "https") or not bits.hostname or bits.username or bits.password:
            return ""
        port = bits.port
        host = bits.hostname.lower()
        if ":" in host:
            host = "[" + host + "]"
        default = (bits.scheme == "http" and port == 80) or (bits.scheme == "https" and port == 443)
        if port is not None and not default:
            host += ":" + str(port)
        path = bits.path or "/"
        frag = bits.fragment if bits.fragment.startswith(("/", "!")) else ""
        return urlunsplit((bits.scheme.lower(), host, path, bits.query, frag))
    except (ValueError, AttributeError):
        return ""


def normalize_outcome(status_text: str) -> str:
    """Map FieldIndex legacy and new status labels to the standardized error taxonomy."""
    s = (status_text or "").strip().lower()
    if not s:
        return "unavailable"
    if any(tok in s for tok in ("verified by human", "verified public page", "corroborated")):
        return "verified_public_page"
    if any(tok in s for tok in (
        "handle match", "sherlock-reported", "maigret-reported", "tool-reported lead",
        "indexed result", "browser capture", "catalogue record", "manual observation",
        "literal page mention", "literal file mention", "page excerpt", "catalogue reference",
        "public_page_observed",
    )):
        return "candidate_public_page"
    if any(tok in s for tok in ("incomplete", "partial")):
        return "partial"
    if any(tok in s for tok in ("timed out", "timeout")):
        return "timeout"
    if any(tok in s for tok in ("rate limit", "throttl", "429")):
        return "throttled"
    if any(tok in s for tok in ("blocked", "access restricted", "sign-in required", "challenge", "waf", "captcha", "403", "401")):
        return "blocked/auth"
    if any(tok in s for tok in ("malformed", "unrecognized", "unexpected", "invalid")):
        return "malformed"
    if any(tok in s for tok in ("dns", "connection failed", "transport", "http ")):
        return "transport_error"
    if any(tok in s for tok in (
        "no record", "no profile", "no indexed", "no reported", "no snapshot",
        "no literal", "no readable", "no records", "different handle",
    )):
        return "no_observation"
    if any(tok in s for tok in ("unavailable", "not installed", "cancelled", "api key required", "error")):
        return "unavailable"
    return "no_observation"


def underlying_source_key(url: str) -> str:
    """Identify the canonical public publisher/page regardless of which tool found it."""
    norm = canonical_url(url)
    if not norm:
        return ""
    bits = urlsplit(norm)
    host = (bits.hostname or "").lower().removeprefix("www.")
    path = bits.path.rstrip("/") or "/"
    return f"{host}{path}" + (f"?{bits.query}" if bits.query else "")


def deduplicate_observations(records):
    """Group records by underlying public page and expose shared-source overlap."""
    grouped = {}
    for item in records:
        if isinstance(item, dict):
            utc = item.get("utc", "")
            source = item.get("source") or item.get("provider", "")
            query = item.get("query", "")
            status = item.get("status") or item.get("outcome", "")
            url = item.get("url", "")
            note = item.get("note") or item.get("excerpt", "")
        else:
            utc, source, query, status, url, note = item
        key = underlying_source_key(url)
        canon = canonical_url(url)
        if not key or not canon:
            continue
        category = normalize_outcome(status)
        entry = grouped.setdefault(key, {
            "underlying_key": key,
            "canonical_url": canon,
            "adapters": [],
            "categories": [],
            "first_seen_utc": utc,
            "last_seen_utc": utc,
            "observations": [],
        })
        if source and source not in entry["adapters"]:
            entry["adapters"].append(source)
        if category not in entry["categories"]:
            entry["categories"].append(category)
        if utc and (not entry["first_seen_utc"] or utc < entry["first_seen_utc"]):
            entry["first_seen_utc"] = utc
        if utc and (not entry["last_seen_utc"] or utc > entry["last_seen_utc"]):
            entry["last_seen_utc"] = utc
        entry["observations"].append({
            "utc": utc,
            "source": source,
            "query": query,
            "status": status,
            "category": category,
            "url": url,
            "note": note,
        })
    results = []
    for entry in grouped.values():
        entry["adapters"] = sorted(entry["adapters"])
        entry["categories"] = sorted(entry["categories"])
        overlap = len(entry["adapters"]) > 1
        entry["overlapping_tools"] = overlap
        entry["independence_note"] = (
            "Multiple tools observed this same public URL. Overlapping tool hits share one underlying page and are NOT independent identity confirmations."
            if overlap
            else "Single-tool observation; corroborate independently before attributing identity."
        )
        results.append(entry)
    return results
