@echo off
setlocal
cd /d "%~dp0.."
call BUILD_STANDALONE_ON_WINDOWS.cmd
