function captureVisibleResults() {
  const host = location.hostname.toLowerCase();
  const engines = [
    [/^(www\.)?google\.com$/, "Google", "h3", "q"],
    [/^(www\.)?bing\.com$/, "Bing", "li.b_algo h2", "q"],
    [/^(www\.|html\.)?duckduckgo\.com$/, "DuckDuckGo", "[data-testid='result-title-a'],a.result__a", "q"],
    [/^search\.yahoo\.com$/, "Yahoo", "#web h3", "p"],
    [/^(www\.)?ecosia\.org$/, "Ecosia", ".result-title, [data-test-id='organic-result'] h2", "q"],
    [/^(www\.)?search\.brave\.com$/, "Brave Search", ".snippet .title, .snippet h2", "q"],
    [/^(www\.)?yandex\.(ru|com)$/, "Yandex", "li.serp-item h2", "text"],
    [/^(www\.)?baidu\.com$/, "Baidu", "#content_left h3", "wd"]
  ];
  const engine = engines.find(([pattern]) => pattern.test(host));
  if (!engine) throw new Error("Open a supported public search results page first.");
  const query = new URL(location.href).searchParams.get(engine[3]) || "";
  const results = [];
  const seen = new Set();
  for (const title of document.querySelectorAll(engine[2])) {
    if (!title.getClientRects().length) continue;
    const link = title.closest("a[href]") || title.querySelector("a[href]");
    if (!link) continue;
    const target = new URL(link.href);
    if (!["http:", "https:"].includes(target.protocol)) continue;
    const url = target.href;
    const text = title.textContent.trim();
    if (!text || seen.has(url)) continue;
    seen.add(url);
    results.push({title:text.slice(0,500), url});
    if (results.length === 100) break;
  }
  if (!results.length) throw new Error("No result links recognized on this page. Check that results are displayed.");
  return {format:"fieldindex.capture.v1", provider:engine[1], page:location.href,
          query, captured:new Date().toISOString(), results};
}
document.querySelector("#save").addEventListener("click", async () => {
  const status = document.querySelector("#status");
  try {
    const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
    const [result] = await chrome.scripting.executeScript({target:{tabId:tab.id},func:captureVisibleResults});
    if (!result.result) throw new Error("This tab did not return a capture. Open a supported search results page.");
    const data = result.result;
    const blob = new Blob([JSON.stringify(data,null,2)],{type:"application/json"});
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a"); link.href=url; link.download="FieldIndex_Capture_"+Date.now()+".json"; link.click();
    setTimeout(()=>URL.revokeObjectURL(url),20000);
    status.textContent = data.results.length+" results exported.";
  } catch (error) {status.textContent=error.message;}
});
