"""Read-only public discovery and locally searchable source catalogue."""
import json
import hashlib
from pathlib import Path
import re
import socket
from html import unescape
from html.parser import HTMLParser
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlencode, urljoin, urlsplit, urlunsplit
from urllib.request import Request, urlopen
from source_catalog import RECORDS

# Curated entry points. Descriptions are editorial metadata, not live retrieved pages.
SOURCES = [
 ("Dating publications","Tinder Newsroom","https://www.tinderpressroom.com/about","Company background, platform announcements and press coverage."),
 ("Dating publications","Grindr press and contacts","https://www.grindr.com/contact","Public company channels and press information."),
 ("BDSM & kink","FetLife rules and policies","https://fetlife.com/policies","Public policies of a membership-based kink community."),
 ("BDSM & kink","Leather Archives & Museum","https://leatherarchives.org/","Museum, archival collections and leather history."),
 ("Swing & lifestyle","Desire Riviera Maya calendar","https://www.desire-resorts.com/desire-riviera-maya/events.php","Published resort events for adults."),
 ("Adult industry","XBIZ News","https://www.xbiz.com/news/","Adult entertainment trade news."),
 ("Dating publications","Feeld magazine announcement","https://feeld.co/press/releases/a-feeld-magazine-launch","Editorial publishing and relationship culture."),
 ("Dating publications","Feeld State of Dating","https://feeld.co/press/releases/state-of-dating-vol-4","Publisher's research and reporting on dating."),
 ("Swing & lifestyle","Naughty Events","https://www.naughty-events.com/","Public convention, travel, club and resort information."),
 ("Swing & lifestyle","Swing.com company history","https://www.swing.com/about","Public history of SwingLifeStyle and its dating platform."),
 ("BDSM & kink","The Eulenspiegel Society","https://www.tes.org/","BDSM education, exchange and public organization information."),
 ("BDSM & kink","NCSF resource library","https://ncsfreedom.org/resource-library/","BDSM glossary, event organizing and kink education resources."),
 ("Adult industry","Free Speech Coalition industry overview","https://www.freespeechcoalition.com/about-the-adult-industry","Industry terminology, production and publishing."),
 ("Adult industry","Free Speech Coalition scholars","https://www.freespeechcoalition.com/scholars","Academic research on adult media and sexuality."),
 ("Adult industry","Free Speech Coalition banking report","https://www.freespeechcoalition.com/banks","Industry research on financial access."),
 ("Advocacy & relationships","NCSF public resources","https://ncsfreedom.org/resources/","Consent, non-monogamy, policy and community resources."),
 ("Advocacy & relationships","NCSF partners and events","https://members.ncsfreedom.org/","Public community events and coalition activities."),
 ("Naturism","American Association for Nude Recreation","https://www.aanr.com/","Public resources on social nudism, clubs and recreation."),
]
SOURCE_INFO = {row["url"]:row for row in RECORDS}
for category,name,url,description in SOURCES:
    SOURCE_INFO.setdefault(url,dict(category=category,name=name,url=url,
        country="International",kind="Reference",description=description,
        evidence_url=url,reviewed="2026-11-21",status="Public web source located"))
SOURCES.extend((row["category"],row["name"],row["url"],row["description"]) for row in RECORDS)

def filter_sources(sources,category="All collections",region="All regions",words="",source_info=None):
    source_info = SOURCE_INFO if source_info is None else source_info
    terms=words.casefold().split()
    result=[]
    for item in sources:
        info=source_info.get(item[2],{})
        if category!="All collections" and item[0]!=category:continue
        if region!="All regions" and info.get("country","User added")!=region:continue
        searchable=" ".join((*item,info.get("country",""),info.get("kind",""),info.get("locality",""))).casefold()
        if all(word in searchable for word in terms):result.append(item)
    return result

def canonical(url):
    try:
        bits=urlsplit(url.strip())
        if bits.scheme not in ("http","https") or not bits.hostname or bits.username or bits.password:return ""
        port=bits.port
        host=bits.hostname.lower()
        if ":" in host:host="["+host+"]"
        default=(bits.scheme=="http" and port==80) or (bits.scheme=="https" and port==443)
        if port is not None and not default:host+=":"+str(port)
        return urlunsplit((bits.scheme.lower(),host,bits.path or "/",bits.query,bits.fragment if bits.fragment.startswith(("/","!")) else ""))
    except (ValueError,AttributeError):
        return ""

def grouped_records(records):
    eligible={
        "Handle match",
        "Tool-reported lead",
        "Sherlock-reported public profile",
        "Maigret-reported public profile",
        "Catalogue record",
        "Manual observation",
        "Browser capture",
        "Indexed result",
        "Literal page mention",
        "Page excerpt",
        "Catalogue reference",
    }
    grouped={}
    for stamp,source,query,status,url,note in records:
        key=canonical(url)
        if not key or status in ("Query opened","Prepared browser search"):continue
        grouped.setdefault(key,[]).append(dict(utc=stamp,source=source,query=query,outcome=status,url=url,excerpt=note))
    findings=[]
    for url,observations in grouped.items():
        if not any(item["outcome"] in eligible for item in observations):continue
        sources=sorted({item["source"] for item in observations})
        findings.append(dict(
            canonical_url=url,
            sources=sources,
            first_seen_utc=min(item["utc"] for item in observations),
            last_seen_utc=max(item["utc"] for item in observations),
            overlapping_tools=len(sources) > 1,
            independence_note=(
                "Multiple tools reported this same URL; shared underlying page is NOT independent identity confirmation."
                if len(sources) > 1 else
                "Single-source public observation; corroborate independently."
            ),
            observations=observations,
        ))
    return findings

def network_error(exc):
    if isinstance(exc,HTTPError):return {401:"Sign-in required",403:"Access restricted",429:"Rate limited"}.get(exc.code,"HTTP "+str(exc.code))
    reason=getattr(exc,"reason",exc)
    if isinstance(reason,socket.gaierror):return "DNS lookup failed"
    if isinstance(reason,TimeoutError):return "Connection timed out"
    if isinstance(exc,(URLError,OSError)):return "Connection failed"
    return "Unrecognized provider reply"

def read(url,accept="text/html",token=None):
    headers={"User-Agent":"FieldIndex/0.11 public research desktop","Accept":accept}
    if token:headers["X-Subscription-Token"]=token
    with urlopen(Request(url,headers=headers),timeout=12) as resp:
        raw=resp.read(2_000_001)
        if len(raw)>2_000_000:raise ValueError("Response exceeds 2 MB")
        return raw.decode(resp.headers.get_content_charset() or "utf-8",errors="replace")

class ResultsParser(HTMLParser):
    def __init__(self):
        super().__init__();self.results=[];self.mode="";self.words=[];self.url=""
    def handle_starttag(self,tag,attrs):
        if tag!="a":return
        a=dict(attrs);classes=a.get("class","").split()
        self.mode="title" if "result__a" in classes else "snippet" if "result__snippet" in classes else ""
        self.words=[];self.url=a.get("href","")
    def handle_data(self,data):
        if self.mode:self.words.append(data)
    def handle_endtag(self,tag):
        if tag!="a" or not self.mode:return
        text=" ".join("".join(self.words).split())
        if self.mode=="title":
            u=urljoin("https://duckduckgo.com",self.url);bits=urlsplit(u)
            if bits.hostname in ("duckduckgo.com","www.duckduckgo.com") and bits.path.startswith("/l/"):
                u=parse_qs(bits.query).get("uddg",[""])[0]
            self.results.append([text,canonical(u),""])
        elif self.results:self.results[-1][2]=text
        self.mode=""

def web_results(query,provider="DuckDuckGo",key=""):
    """Return provider observations with distinct transport, challenge and empty outcomes."""
    def row(status,url="",note=""):return (provider,query,status,url,note)
    try:
        if provider=="Brave Search":
            if not key:return [row("API key required")]
            raw=read("https://api.search.brave.com/res/v1/web/search?"+urlencode({"q":query,"count":20}),"application/json",key)
            payload=json.loads(raw)
            if "web" not in payload and payload.get("type")!="search":raise ValueError("Unrecognized search response")
            items=[(x["title"],canonical(x["url"]),x.get("description","")) for x in payload.get("web",{}).get("results",[])]
        else:
            raw=read("https://html.duckduckgo.com/html/?"+urlencode({"q":query}))
            if "anomaly-modal" in raw or "challenge-form" in raw:return [row("Search provider challenge")]
            parser=ResultsParser();parser.feed(raw);items=parser.results
            if not items and "no-results" not in raw:return [row("Unrecognized provider reply")]
        rows=[];seen=set()
        for title,url,snippet in items:
            if not url or url in seen:continue
            seen.add(url)
            text=unescape(re.sub("<[^>]+>"," ",title+"  "+snippet))
            rows.append(row("Indexed result",url," ".join(text.split())[:1200]))
        return rows or [row("No indexed results")]
    except (OSError,ValueError,TypeError,KeyError,AttributeError) as exc:
        return [row(network_error(exc),note=str(getattr(exc,"reason",exc))[:240])]

class PageText(HTMLParser):
    def __init__(self):
        super().__init__();self.parts=[];self.ignore=0
    def handle_starttag(self,tag,attrs):
        if tag in ("style","script","template"):self.ignore+=1
    def handle_endtag(self,tag):
        if tag in ("style","script","template") and self.ignore:self.ignore-=1
    def handle_data(self,data):
        if not self.ignore:self.parts.append(data)

def passage(text,needle):
    match=re.search(re.escape(needle),text,re.I)
    if not match:return None
    return text[max(0,match.start()-100):match.end()+150]

def read_catalogue(source,term):
    category,name,url,description=source
    try:
        raw=read(url)
        if any(marker in raw.lower() for marker in ("cf-chl-platform","challenge-form","anomaly-modal")):
            return (name,term,"Publisher challenge",url,"")
        parser=PageText();parser.feed(raw);text=" ".join(" ".join(parser.parts).split())
        if not text:return (name,term,"No readable text",url,"")
        if not term:return (name,term,"Page excerpt",url,text[:350])
        extract=passage(text,term)
        return (name,term,"Literal page mention" if extract else "No literal mention in response",url,extract or "")
    except (OSError,ValueError) as exc:return (name,term,network_error(exc),url,str(exc)[:200])

def search_file(path,term):
    p=Path(path)
    try:
        with p.open("rb") as f:raw=f.read(8_000_001)
        if len(raw)>8_000_000:return ("Saved files",term,"File exceeds 8 MB","",p.name)
        codec="utf-16" if raw.startswith((b"\xff\xfe",b"\xfe\xff")) else "utf-8-sig"
        text=raw.decode(codec,errors="replace")
        if p.suffix.lower() in (".html",".htm"):
            parser=PageText();parser.feed(text);text=" ".join(parser.parts)
        sample=passage(text,term)
        note=p.name+" | SHA-256 "+hashlib.sha256(raw).hexdigest()
        if sample:note+=" | "+sample
        return ("Saved files",term,"Literal file mention" if sample else "No literal file mention","",note)
    except (OSError,ValueError) as exc:return ("Saved files",term,"File unavailable","",p.name+": "+str(exc))

def captured_rows(path):
    with open(path,"rb") as f:raw=f.read(2_000_001)
    if len(raw)>2_000_000:raise ValueError("Capture exceeds 2 MB")
    data=json.loads(raw)
    if not isinstance(data,dict) or data.get("format")!="fieldindex.capture.v1":raise ValueError("Select a Field Index browser capture.")
    keys=("provider","query","captured","page")
    if any(not isinstance(data.get(k),str) for k in keys):raise ValueError("Invalid capture metadata")
    if not canonical(data["page"]):raise ValueError("Invalid search page")
    results=data.get("results")
    if not isinstance(results,list) or not 1<=len(results)<=100:raise ValueError("Expected 1 to 100 results")
    rows=[];seen=set()
    for item in results:
        if not isinstance(item,dict) or not all(isinstance(item.get(k),str) for k in ("url","title")):raise ValueError("Invalid result")
        url=canonical(item["url"])
        if not url:raise ValueError("Invalid result URL")
        if url in seen:continue
        seen.add(url)
        note=item["title"][:500]+" | Captured "+data["captured"][:60]+" | "+data["page"][:2000]
        rows.append((data["provider"][:60],data["query"][:1000],"Browser capture",url,note))
    return hashlib.sha256(raw).hexdigest(),rows
