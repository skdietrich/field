"""Field Index 0.11 guided public-web dork builder.

Builds auditable browser searches with explicit engine-operator support transparency.
Search results are leads, never account verification. The module is dependency-free
and does not perform unattended scraping.
"""
from __future__ import annotations

import itertools
import re
from datetime import date
from dataclasses import dataclass
from urllib.parse import quote, urlsplit

ENGINE_URLS = {
    'Google': 'https://www.google.com/search?q=',
    'Bing': 'https://www.bing.com/search?q=',
    'DuckDuckGo': 'https://duckduckgo.com/?q=',
    'Yahoo': 'https://search.yahoo.com/search?p=',
    'Yandex': 'https://yandex.com/search/?text=',
    'Baidu': 'https://www.baidu.com/s?wd=',
    'Ecosia': 'https://www.ecosia.org/search?q=',
}

OPERATOR_MATRIX = {
    'Google':     {'site': 'documented', 'phrase': 'documented', 'exclude': 'documented', 'filetype': 'documented', 'date': 'documented',  'intitle': 'best_effort', 'inurl': 'best_effort'},
    'Bing':       {'site': 'documented', 'phrase': 'documented', 'exclude': 'documented', 'filetype': 'documented', 'date': 'unsupported', 'intitle': 'best_effort', 'inurl': 'unsupported'},
    'DuckDuckGo': {'site': 'documented', 'phrase': 'documented', 'exclude': 'documented', 'filetype': 'documented', 'date': 'unsupported', 'intitle': 'best_effort', 'inurl': 'best_effort'},
    'Yahoo':      {'site': 'best_effort','phrase': 'documented', 'exclude': 'best_effort','filetype': 'best_effort','date': 'unsupported', 'intitle': 'unsupported', 'inurl': 'unsupported'},
    'Yandex':     {'site': 'documented', 'phrase': 'documented', 'exclude': 'best_effort','filetype': 'best_effort','date': 'unsupported', 'intitle': 'unsupported', 'inurl': 'unsupported'},
    'Baidu':      {'site': 'documented', 'phrase': 'documented', 'exclude': 'best_effort','filetype': 'best_effort','date': 'unsupported', 'intitle': 'unsupported', 'inurl': 'unsupported'},
    'Ecosia':     {'site': 'documented', 'phrase': 'documented', 'exclude': 'documented', 'filetype': 'best_effort','date': 'unsupported', 'intitle': 'unsupported', 'inurl': 'unsupported'},
}

MAX_BRANCHES = 120


@dataclass(frozen=True)
class SearchBranch:
    query: str
    url: str
    label: str


@dataclass(frozen=True)
class SearchPlan:
    engine: str
    branches: tuple[SearchBranch, ...]
    notes: tuple[str, ...]


def csv_items(value: str):
    return list(dict.fromkeys(x.strip() for x in re.split(r'[,\n]+', value or '') if x.strip()))


def search_domain(value: str):
    """Normalize a user-entered site or HTTPS URL to its public ASCII/punycode hostname."""
    site = (value or '').strip()
    if not site:
        raise ValueError('A site/domain entry is empty.')
    if site.startswith('https://'):
        bits = urlsplit(site)
        if bits.username or bits.password or bits.port is not None or bits.query or bits.fragment:
            raise ValueError('Enter an ordinary public publisher URL or domain without credentials, port or query.')
        site = bits.hostname or ''
    elif '://' in site or '/' in site or '?' in site or '#' in site:
        raise ValueError('Use a domain like example.org, or its https:// URL.')
    site = site.lower().rstrip('.')
    if any(ord(c) > 127 for c in site):
        try:
            site = site.encode('idna').decode('ascii')
        except UnicodeError as exc:
            raise ValueError('Invalid internationalized domain: ' + value[:70]) from exc
    if not re.fullmatch(r'(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}', site):
        raise ValueError('Invalid public domain: ' + value[:70])
    if site.endswith(('.local', '.internal', '.localhost', '.arpa')):
        raise ValueError('Private network domains are not supported.')
    return site


def _plain(value, name, limit=300):
    if not isinstance(value, str) or len(value) > limit or any(ord(c) < 32 and c not in '\n\t' for c in value):
        raise ValueError(name + ' contains invalid characters or is too long.')
    return ' '.join(value.split())


def _quote(value, name):
    cleaned = _plain(value, name)
    if '"' in cleaned:
        raise ValueError(name + ': remove typed quotation marks. The builder adds them.')
    return '"' + cleaned + '"'


def disclosure_warning(query: str) -> str:
    """Warn if an outgoing browser query appears to contain a private email or phone pattern."""
    if re.search(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}', query or ''):
        return 'This query contains an email address and will be sent to the selected external search engine.'
    if re.search(r'(?<!\d)(?:\+?\d[\d\s().-]{8,}\d)(?!\d)', query or ''):
        return 'This query appears to contain a telephone number and will be sent to the selected external search engine.'
    return ''


def source_pack_choices(manifests):
    """Dictionary of stable pack keys -> display label and public domains."""
    result = {'': ('All public websites (no restriction)', [])}
    for pack in manifests:
        groups = {'*': []}
        for source in pack.get('sources', []):
            try:
                host = search_domain(source['url'])
            except (ValueError, KeyError, TypeError):
                continue
            groups['*'].append(host)
            groups.setdefault(source.get('category', 'Other'), []).append(host)
        for group, domains in groups.items():
            unique = list(dict.fromkeys(domains))
            if not unique:
                continue
            key = pack['id'] + '::' + group
            heading = 'All categories' if group == '*' else group
            result[key] = (f"{pack['name']} / {heading} ({len(unique)} domains)", unique)
    return result


def _valid_date(value, name):
    if not value:
        return ''
    if not re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
        raise ValueError(name + ' must use YYYY-MM-DD.')
    try:
        date.fromisoformat(value)
    except ValueError as exc:
        raise ValueError(name + ' is not a real calendar date.') from exc
    return value


def build_plan(fields: dict, engine='Google', pack_domains=()):
    """Build browser-search branches from form values; never silently report hits."""
    if engine not in ENGINE_URLS:
        raise ValueError('Choose one of the supported search engines.')
    matrix = OPERATOR_MATRIX[engine]
    take = lambda key, cap=300: _plain(fields.get(key, ''), key, cap)
    subject = take('subject')
    exact = take('exact')
    title = take('title')
    inurl = take('inurl')
    include_any = csv_items(fields.get('any', ''))
    exclude = csv_items(fields.get('exclude', ''))
    sites = list(dict.fromkeys([search_domain(s) for s in csv_items(fields.get('sites', ''))] + [search_domain(s) for s in pack_domains]))
    excluded_sites = list(dict.fromkeys(search_domain(s) for s in csv_items(fields.get('exclude_sites', ''))))
    formats = list(dict.fromkeys(x.lower().lstrip('.') for x in csv_items(fields.get('filetype', ''))))
    alternatives = csv_items(fields.get('variants', '')) or ['']
    after, before = _valid_date(take('after'), 'From date'), _valid_date(take('before'), 'Before date')
    if after and before and after >= before:
        raise ValueError('Before date must be later than From date.')
    for token in formats:
        if not re.fullmatch(r'[a-z0-9]{1,10}', token):
            raise ValueError('File type must be a short extension such as pdf or csv.')
    if not any((subject, exact, title, inurl, sites, include_any, fields.get('raw', '').strip())):
        raise ValueError('Enter a topic, exact phrase, website, or advanced filter first.')
    if any(s == bad or s.endswith('.' + bad) for s in sites for bad in excluded_sites):
        raise ValueError('One of the selected source domains is also excluded.')
    if len(exclude) > 20 or len(excluded_sites) > 25 or len(include_any) > 12:
        raise ValueError('Reduce the number of exclusions or alternate keywords.')
    total = max(1, len(sites)) * max(1, len(formats)) * len(alternatives)
    if total > MAX_BRANCHES:
        raise ValueError(f'{total} queries would be generated. Narrow the source pack or reduce variants/formats (limit {MAX_BRANCHES}).')

    notes = []
    if engine in ('Yahoo', 'Yandex', 'Baidu', 'Ecosia'):
        notes.append('This engine may interpret advanced operators differently. Confirm restrictions in the results.')
    if title and matrix['intitle'] == 'unsupported':
        notes.append('Page-title operator omitted: not reliably supported by this engine.')
    if inurl and matrix['inurl'] == 'unsupported':
        notes.append('URL-word operator omitted: not reliably supported by this engine.')
    if (after or before) and matrix['date'] == 'unsupported':
        notes.append('Google date operators omitted. Set a date filter in the search engine after opening.')
    if formats and matrix['filetype'] != 'documented':
        notes.append('File-type operator may be ignored by this search engine.')
    if (title or inurl) and engine == 'Google':
        notes.append('Google intitle:/inurl: are best-effort operators; results can be broader than requested.')
    if fields.get('raw', '').strip():
        notes.append('Custom syntax is passed through as typed. Check provider support before trusting it.')
    if len(sites) > 1:
        notes.append('Each publisher is searched separately. Open only selected searches, rather than dozens of tabs.')

    common = []
    if subject:
        common.append(subject)
    if exact:
        common.append(_quote(exact, 'Exact phrase'))
    if include_any:
        or_parts = []
        for item in include_any:
            cleaned = _plain(item, 'Any of these')
            if '"' in cleaned:
                raise ValueError('Any of these: remove typed quotation marks. The builder adds them.')
            or_parts.append('"' + cleaned + '"' if ' ' in cleaned else cleaned)
        common.append('(' + ' OR '.join(or_parts) + ')')
    for term in exclude:
        common.append('-' + _quote(term, 'Exclude phrase'))
    for site in excluded_sites:
        common.append('-site:' + site)
    if title and matrix['intitle'] != 'unsupported':
        common.append('intitle:' + _quote(title, 'Page title'))
    if inurl and matrix['inurl'] != 'unsupported':
        common.append('inurl:' + _quote(inurl, 'URL word'))
    if matrix['date'] == 'documented':
        if after:
            common.append('after:' + after)
        if before:
            common.append('before:' + before)
    raw = take('raw', 350)
    if raw:
        common.append(raw)

    branches = []
    for s, f, variant in itertools.product(sites or [''], formats or [''], alternatives):
        clauses = list(common)
        if variant:
            clauses.append(_quote(variant, 'Alternative name'))
        if s:
            clauses.append('site:' + s)
        if f:
            clauses.append('filetype:' + f)
        query = ' '.join(clauses)
        if len(query) > 1800:
            raise ValueError('Generated query is too long. Shorten the fields or source list.')
        subtitle = ' / '.join(x for x in (s or 'All web', f.upper() if f else '', variant) if x)
        branches.append(SearchBranch(query, ENGINE_URLS[engine] + quote(query, safe=''), subtitle))

    distinct = tuple(dict.fromkeys(branches))
    return SearchPlan(engine, distinct, tuple(dict.fromkeys(notes)))
