"""Public source routing, exact-handle lookups and guided Google queries."""
import json
import re
import shutil
import os
import itertools
from datetime import date
from urllib.error import HTTPError
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

from process_runner import run_command, ToolCancelled
import sherlock_bridge as sherlock_cli
import maigret_bridge as maigret_cli
import discovery

PROVIDERS = {
    "GitHub": ("https://api.github.com/users/{}", "https://github.com/{}", "login"),
    "GitLab": ("https://gitlab.com/api/v4/users?username={}", "https://gitlab.com/{}", "username"),
    "Codeberg": ("https://codeberg.org/api/v1/users/{}", "https://codeberg.org/{}", "login"),
    "DEV Community": ("https://dev.to/api/users/by_username?url={}", "https://dev.to/{}", "username"),
    "Hacker News": ("https://hacker-news.firebaseio.com/v0/user/{}.json", "https://news.ycombinator.com/user?id={}", "id"),
    "Lichess": ("https://lichess.org/api/user/{}", "https://lichess.org/@/{}", "username"),
    "Chess.com": ("https://api.chess.com/pub/player/{}", "https://www.chess.com/member/{}", "username"),
    "Codewars": ("https://www.codewars.com/api/v1/users/{}", "https://www.codewars.com/users/{}", "username"),
    "Keybase": ("https://keybase.io/_/api/1.0/user/lookup.json?usernames={}", "https://keybase.io/{}", "username"),
    "English Wikipedia": ("https://en.wikipedia.org/w/api.php?action=query&format=json&list=users&ususers={}", "https://en.wikipedia.org/wiki/User:{}", "name"),
}
ENGINES = {
    "Google":"https://www.google.com/search?q=", "Bing":"https://www.bing.com/search?q=",
    "DuckDuckGo":"https://duckduckgo.com/?q=", "Yahoo":"https://search.yahoo.com/search?p=",
    "Ecosia":"https://www.ecosia.org/search?q=", "Yandex":"https://yandex.com/search/?text=",
    "Baidu":"https://www.baidu.com/s?wd=",
}
CATALOG = {
    "Archives": {"Internet Archive":"https://archive.org/search?query=", "Library of Congress":"https://www.loc.gov/search/?q=", "Europeana":"https://www.europeana.eu/en/search?query=", "National Archives (US)":"https://catalog.archives.gov/search?q="},
    "Publications": {"Crossref":"https://search.crossref.org/?q=", "PubMed":"https://pubmed.ncbi.nlm.nih.gov/?term=", "OpenAlex":"https://openalex.org/works?search=", "Google Scholar":"https://scholar.google.com/scholar?q="},
    "Organizations": {"SEC EDGAR":"https://www.sec.gov/edgar/search/#/q=", "Companies House":"https://find-and-update.company-information.service.gov.uk/search?q=", "OpenCorporates":"https://opencorporates.com/companies?q=", "GLEIF":"https://search.gleif.org/#/search/simpleSearch="},
    "Places & maps": {"OpenStreetMap":"https://www.openstreetmap.org/search?query=", "GeoNames":"https://www.geonames.org/search.html?q=", "Wikimedia Commons":"https://commons.wikimedia.org/w/index.php?search="},
    "News & web": {**ENGINES,"Google News":"https://news.google.com/search?q=", "GDELT":"https://api.gdeltproject.org/api/v2/doc/doc?mode=artlist&format=html&query="},
}
MODES = ["Basic","Guided","Advanced","God Mode"]
FIELDS = [
 ("terms","Research subject","Enter the words a relevant page is likely to contain.",0),
 ("phrase","Exact wording","Keep a quotation, name or title together as one phrase.",1),
 ("site","Publishers or domains","Comma-separated domains, such as loc.gov, archives.gov. Each gets a separate query.",1),
 ("omit","Words or phrases to exclude","Separate unwanted meanings with commas.",2),
 ("file","Document formats","Comma-separated extensions, such as pdf, docx or csv. Each gets a separate query.",2),
 ("after","Updated after","Use YYYY-MM-DD. This concerns the page date rather than the event date.",2),
 ("before","Updated before","Use YYYY-MM-DD as the upper bound.",2),
 ("other","Alternative names","Enter comma-separated spellings. Each produces a separate query for comparison.",3),
 ("skip","Exclude publishers","Comma-separated domains to omit from every query.",3),
 ("title","Words in the page title","Comma-separated words or phrases required in the title.",2),
 ("url_words","Words in the page URL","Comma-separated words or phrases to look for in the URL.",2),
 ("place_words","Place wording","A place name required in the page text. This filters wording, not physical location.",3),
]
def domain(s):
    if not re.fullmatch(r"(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}",s,re.I):
        raise ValueError("Use a plain domain such as loc.gov, without a path.")
    return s.lower()

def queries(data, mode):
    v={k:(data.get(k,"").strip() if level<=mode else "") for k,_,_,level in FIELDS}
    if not any(v[k] for k in ("terms","phrase","site","other")):
        raise ValueError("Enter a subject, phrase, publisher or alternative name.")
    if any('"' in v[k] for k in ("phrase","omit","other")):
        raise ValueError("Remove quotation marks. The builder adds them around phrases.")
    parts=[v["terms"]]
    if v["phrase"]: parts.append('"'+v["phrase"]+'"')
    sites=[domain(s) for s in split(v["site"])]
    for term in split(v["omit"]): parts.append('-"'+term+'"')
    formats=[]
    for extension in split(v["file"]):
        ext=extension.lstrip(".").lower()
        if not re.fullmatch("[a-z0-9]{1,10}",ext): raise ValueError("Enter one file extension.")
        formats.append(ext)
    for k in ("after","before"):
        if v[k]:
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}",v[k]): raise ValueError("Use YYYY-MM-DD for each date.")
            date.fromisoformat(v[k])
            parts.append(k+":"+v[k])
    if v["after"] and v["before"] and v["after"]>=v["before"]: raise ValueError("The end date must follow the start date.")
    for s in split(v["skip"]):
        d=domain(s)
        if any(site==d or site.endswith("."+d) for site in sites):raise ValueError("A chosen publisher is also excluded.")
        parts.append("-site:"+d)
    for field,operator in (("title","intitle"),("url_words","inurl")):
        for term in split(v[field]):
            if '"' in term:raise ValueError("Remove quotes from title and URL fields.")
            parts.append(operator+':"'+term+'"')
    if v["place_words"]:
        if '"' in v["place_words"]:raise ValueError("Remove quotes from the place field.")
        parts.append('"'+v["place_words"]+'"')
    alternatives=split(v["other"]) or [""]
    if len(sites or [""])*len(formats or [""])*len(alternatives)>80:
        raise ValueError("This plan exceeds 80 queries. Reduce domains, formats or variants.")
    result=[]
    for site,extension,alternative in itertools.product(sites or [""],formats or [""],alternatives):
        clauses=list(parts)
        if site:clauses.append("site:"+site)
        if extension:clauses.append("filetype:"+extension)
        if alternative:clauses.append('"'+alternative+'"')
        result.append(" ".join(x for x in clauses if x))
    return list(dict.fromkeys(result))

def provider_queries(data,mode,provider):
    adjusted=dict(data)
    notes=[]
    if provider=="DuckDuckGo":
        if mode>=2 and (data.get("after") or data.get("before")):
            adjusted["after"]="";adjusted["before"]=""
            notes.append("Set the date range using DuckDuckGo's date controls. These queries omit the Google date operators.")
    elif provider!="Google":
        raise ValueError("Choose Google or DuckDuckGo.")
    queries(data,mode)
    return queries(adjusted,mode),notes

def split(s): return list(dict.fromkeys(x.strip() for x in s.split(",") if x.strip()))

def handle(s):
    if not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}",s): raise ValueError("Use a single handle of 1–64 letters, numbers, underscores, dots or hyphens.")
    return s

def fetch(url):
    req=Request(url,headers={"User-Agent":"FieldIndex-Research/0.11 (interactive desktop public-source lookup)","Accept":"application/json"})
    with urlopen(req,timeout=9) as response:
        raw=response.read(2_000_001)
        if len(raw)>2_000_000: raise ValueError("Source response too large")
        return json.loads(raw)

def lookup(name,value):
    u=quote(handle(value),safe="")
    api,public,key=PROVIDERS[name]
    url=public.format(u)
    try:
        data=fetch(api.format(u))
        if name=="GitLab":
            if not isinstance(data,list): raise ValueError("Unexpected response")
            data=next((x for x in data if str(x.get(key,"")).casefold()==value.casefold()),None)
        if name=="Keybase":
            if data["status"]["code"]!=0: raise ValueError("Provider error")
            data=next((x["basics"] for x in data["them"] if x),None)
        if name=="English Wikipedia":
            data=data["query"]["users"][0]
            if "invalid" in data: return ("Unsupported spelling",url)
            if "missing" in data: data=None
        if data is None: return ("No record returned",url)
        identity=data[key]
        return ("Handle match" if identity.casefold()==value.casefold() else "Different handle",url)
    except HTTPError as e:
        status={404:"No record returned",429:"Rate limited",403:"Access restricted",401:"Sign-in required"}.get(e.code,"HTTP "+str(e.code))
        return status,url
    except OSError as exc:
        return discovery.network_error(exc),url
    except (ValueError,TypeError,KeyError,IndexError,AttributeError):
        return "Unavailable / unrecognized reply",url

def tool_report(tool,user,cancel=None,legacy=False):
    handle(user)
    if tool not in ("sherlock","maigret"): raise ValueError("Unknown tool")
    if tool=="sherlock":
        rows=sherlock_cli.scan(user,cancel=cancel)
        errors=[r[4] for r in rows if r[2]=="Source unavailable"]
        if errors:raise ValueError("Sherlock unavailable: "+errors[0])
        return [r[3] for r in rows if r[2]=="Sherlock-reported public profile"]
    rows=maigret_cli.scan(user,legacy_three_sites=legacy,cancel=cancel)
    errors=[r[4] for r in rows if r[2] in ("Source unavailable","Malformed tool report","Timed out")]
    if errors:raise ValueError("Maigret unavailable: "+errors[0])
    return [r[3] for r in rows if r[2]=="Maigret-reported public profile"]

def tool_health():
    rows=[]
    for label,probe_fn in (("Maigret",maigret_cli.probe_capabilities),("Sherlock",sherlock_cli.probe_capabilities)):
        caps=probe_fn()
        if not caps["installed"]:
            rows.append((label,"--version","Not installed","","Executable not found in managed tools folder or on PATH."))
            continue
        if caps["error"]:
            rows.append((label,"--version","Tool installation failed","",caps["error"][:400]))
            continue
        enabled_flags=[k for k,v in caps["flags"].items() if v]
        detail=f"Executable: {caps['executable']} | Version: {caps['version']} | Flags: {', '.join(enabled_flags) or 'none detected'}"
        rows.append((label,"--version","Tool responded","",detail[:600]))
    return rows

CATALOG_PROVIDERS={"Archives":"Internet Archive","Publications":"Crossref","Organizations":"GLEIF","Places & maps":"Open-Meteo / GeoNames","News & web":"GDELT"}

def catalogue_results(group,term):
    q=quote(term,safe="")
    if group=="Publications":
        d=fetch("https://api.crossref.org/works?rows=10&query="+q)
        return [((i.get("title") or [i["DOI"]])[0],"https://doi.org/"+i["DOI"]) for i in d["message"]["items"]]
    if group=="Archives":
        params=urlencode({"q":term,"output":"json","rows":10,"fl[]":["identifier","title"]},doseq=True)
        d=fetch("https://archive.org/advancedsearch.php?"+params)
        return [(i.get("title",i["identifier"]),"https://archive.org/details/"+quote(i["identifier"],safe="")) for i in d["response"]["docs"]]
    if group=="Organizations":
        params=urlencode({"filter[entity.legalName]":term,"page[size]":10})
        d=fetch("https://api.gleif.org/api/v1/lei-records?"+params)
        return [(x["attributes"]["entity"]["legalName"]["name"]+" | LEI "+x["id"],"https://search.gleif.org/#/record/"+quote(x["id"],safe="")) for x in d["data"]]
    if group=="Places & maps":
        d=fetch("https://geocoding-api.open-meteo.com/v1/search?"+urlencode({"name":term,"count":10,"language":"en","format":"json"}))
        if "results" not in d and "generationtime_ms" not in d:raise ValueError("Unrecognized geocoding response")
        return [(", ".join(str(x[k]) for k in ("name","admin1","country") if x.get(k))+" | "+str(x["latitude"])+", "+str(x["longitude"]),"https://www.geonames.org/"+str(int(x["id"]))) for x in d.get("results",[])]
    if group=="News & web":
        d=fetch("https://api.gdeltproject.org/api/v2/doc/doc?"+urlencode({"query":term,"mode":"ArtList","format":"json","maxrecords":10}))
        return [(x["title"],x["url"]) for x in d["articles"] if discovery.canonical(x["url"])]
    raise ValueError("No structured connector for this collection.")

def plan_sources(intake):
    """Return explicit (provider, input, method, enabled) routes for review."""
    routes=[]
    handles=[]
    if intake.get("url"):
        if not discovery.canonical(intake["url"]):raise ValueError("Enter a full http or https document URL.")
        routes.append(("Wayback Machine",intake["url"],"Archival lookup",True))
    if intake.get("doi"):
        doi=intake["doi"].removeprefix("https://doi.org/").strip()
        if not re.fullmatch(r"10\.\d{4,9}/[^\s]+",doi):raise ValueError("Enter a DOI beginning with 10. and its publisher number.")
        routes.append(("Crossref",doi,"DOI lookup",True))
    address=intake["email"].strip()
    if address:
        if not re.fullmatch(r'[^@"\s]+@[^@"\s]+\.[^@"\s]+',address):
            raise ValueError("Enter the complete email address, including its domain.")
        routes.extend((name,'"'+address+'"',"Exact email search",True) for name in ENGINES)
        routes.insert(0,("DuckDuckGo",'"'+address+'"',"Web results",True))
        if os.environ.get("BRAVE_SEARCH_API_KEY"):
            routes.insert(1,("Brave Search",'"'+address+'"',"Web results",True))
    for clue in (intake["user"].lstrip("@"), intake["email"].partition("@")[0]):
        if clue and clue not in handles:handles.append(clue)
    if not handles and intake["subject"]:
        handles.append(re.sub(r"\s+","",intake["subject"]))
    for value in handles:
        try:handle(value)
        except ValueError:continue
        for name in PROVIDERS:routes.append((name,value,"Handle API",True))
        routes.append(("maigret",value,"Local tool",bool(maigret_cli.find_executable(which=shutil.which))))
        routes.append(("sherlock",value,"Local tool",bool(sherlock_cli.find_executable(which=shutil.which))))
    topic=intake["phrase"] or intake["subject"] or intake["org"] or intake["place"] or intake["goal"]
    if topic:
        routes.append(("DuckDuckGo",topic,"Web results",True))
        routes.extend([(s,topic,"Catalogue API",True) for s in ("Internet Archive","Crossref")])
    elif intake["user"]:
        routes.append(("DuckDuckGo",'"'+intake["user"].lstrip("@")+'"',"Web results",True))
    for group,key in [("Organizations","org"),("Places & maps","place"),("News & web","subject")]:
        if intake[key]:
            routes.append((CATALOG_PROVIDERS[group],intake[key],"Catalogue API",True))
            routes.extend((s,intake[key],"Browser search",True) for s in CATALOG[group])
    if intake["site"] or intake["phrase"]:
        query=queries({"site":intake["site"],"phrase":intake["phrase"],"terms":intake["subject"]},1)[0]
        routes.append(("Google",query,"Browser search",True))
    return list(dict.fromkeys(routes))

def run_source(route,cancel=None):
    source,query,kind,_=route
    def row(status,url="",note=""):return (source,query,status,url,note)
    try:
        if kind=="Web results":
            return discovery.web_results(query,source,os.environ.get("BRAVE_SEARCH_API_KEY",""))
        if kind=="Archival lookup":
            response=fetch("https://archive.org/wayback/available?"+urlencode({"url":query}))
            item=response["archived_snapshots"].get("closest")
            if not item or not item["available"]:return [row("No snapshot returned")]
            return [row("Catalogue record",item["url"],"Wayback capture "+item["timestamp"])]
        if kind=="DOI lookup":
            item=fetch("https://api.crossref.org/works/"+quote(query,safe=""))["message"]
            return [row("Catalogue record","https://doi.org/"+item["DOI"],(item.get("title") or [query])[0])]
        if kind=="Handle API":
            status,url=lookup(source,query)
            return [row(status,url)]
        if kind=="Local tool":
            if source=="sherlock":return sherlock_cli.scan(query,cancel=cancel)
            if source=="maigret":return maigret_cli.scan(query,cancel=cancel)
            urls=tool_report(source,query,cancel)
            return [row("Tool-reported lead",url) for url in urls] or [row("No reported links")]
        if kind=="Catalogue API":
            group=next(k for k,v in CATALOG_PROVIDERS.items() if v==source)
            hits=catalogue_results(group,query)
            return [row("Catalogue record",url,str(title)) for title,url in hits] or [row("No records returned")]
        base=next(sources[source] for sources in CATALOG.values() if source in sources)
        return [row("Prepared browser search",base+quote(query,safe=""))]
    except ToolCancelled as exc:
        return [row("Cancelled",note=str(exc))]
    except Exception as exc:
        return [row("Source unavailable",note=str(exc)[:400])]
