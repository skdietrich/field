"""Field Index local declarative extension packs.

Packs contain manifest.json (and optional README.txt) only. No extension-supplied
Python code is loaded or executed. Installation is transactional and preserves
the SQLite case database.

Schema notes (v0.11.0):
- Backward-compatible with fieldindex.module.v1 manifests.
- Supports optional public-source provenance metadata: subpages, locality,
  search_method, login_required, age_gate, visibility, robots_notes,
  last_reviewed, status, and caveats.
- Supports per-pack category and region enable/disable filters stored alongside
  the installed pack so analysts can tailor regions or categories without
  rebuilding the application.
- Supports reviewed CSV and JSON directory imports with strict URL and archive
  safety checks.
"""
from __future__ import annotations

import csv
import ipaddress
import json
import re
import shutil
import tempfile
import zipfile
from datetime import date
from pathlib import Path
from urllib.parse import urlsplit

FORMAT = "fieldindex.module.v1"
VERSION = "0.11.0"
ID_PATTERN = re.compile(r"[a-z][a-z0-9-]{2,48}$")
SEMVER = re.compile(r"\d+\.\d+\.\d+$")
ISO_DATE = re.compile(r"\d{4}-\d{2}-\d{2}$")
MAX_FILE = 1_000_000
MAX_ENTRIES = 4
MAX_SOURCES = 300
MAX_RECIPES = 50
MAX_SUBPAGES = 10
VALID_ENGINES = ("Google", "Bing", "DuckDuckGo", "Yahoo", "Ecosia", "Yandex", "Baidu")
ALLOWED_ARCHIVE_FILES = frozenset({"manifest.json", "README.txt"})

VALID_SEARCH_METHODS = frozenset({
    "site_dork",
    "public_directory",
    "public_api",
    "manual_browse",
    "archive_search",
    "public_registry",
})
VALID_LOGIN_MODES = frozenset({
    "none",
    "partial_member_areas",
    "member_gated_community",
})
VALID_AGE_GATES = frozenset({"none", "18+", "21+"})
VALID_VISIBILITIES = frozenset({
    "public_open",
    "public_overview_only",
    "public_calendar_and_policies",
    "public_government_record",
    "public_help_center",
})
VALID_STATUSES = frozenset({
    "active_public",
    "public_info_member_gated",
    "regional_directory",
    "dormant_or_restricted",
})


class PackError(ValueError):
    """Malformed or unsupported pack, without changing installed data."""


def _string(value, what, limit=200, allow_empty=False):
    if (
        not isinstance(value, str)
        or (not allow_empty and not value.strip())
        or len(value) > limit
        or "\x00" in value
        or any(ord(ch) < 32 and ch not in "\t\n\r" for ch in value)
    ):
        raise PackError("Invalid " + what)
    return value.strip()


def _enum(value, what, allowed):
    cleaned = _string(value, what, 64)
    if cleaned not in allowed:
        raise PackError(f"Invalid {what}: {cleaned}")
    return cleaned


def _iso_date(value, what):
    cleaned = _string(value, what, 16)
    if not ISO_DATE.fullmatch(cleaned):
        raise PackError(f"Invalid {what}: expected YYYY-MM-DD")
    try:
        date.fromisoformat(cleaned)
    except ValueError as exc:
        raise PackError(f"Invalid {what}: not a real calendar date") from exc
    return cleaned


def _web_url(value):
    url = _string(value, "source URL", 1200)
    try:
        parsed = urlsplit(url)
        host = parsed.hostname
        port = parsed.port
    except ValueError as exc:
        raise PackError("Invalid source URL") from exc
    if (
        parsed.scheme != "https"
        or not host
        or parsed.username
        or parsed.password
        or port is not None
        or "\\" in url
        or host == "localhost"
        or host.endswith((".localhost", ".local", ".internal", ".arpa"))
        or "." not in host
        or not re.fullmatch(r"[a-z0-9.-]+", host, flags=re.I)
    ):
        raise PackError("Use an external HTTPS publisher URL, without credentials or port")
    is_ip = False
    try:
        ipaddress.ip_address(host)
        is_ip = True
    except ValueError:
        is_ip = False
    if is_ip:
        raise PackError("IP address literals are not allowed in source packs")
    return url


def _validate_source(record):
    if not isinstance(record, dict):
        raise PackError("Invalid source record")
    for field, limit in (
        ("name", 110),
        ("category", 90),
        ("region", 90),
        ("type", 90),
        ("description", 400),
    ):
        _string(record.get(field), "source " + field, limit)
    url = _web_url(record.get("url"))

    # Optional provenance and investigative reliability fields (backward-compatible)
    if "locality" in record and record["locality"] != "":
        _string(record["locality"], "source locality", 120)
    if "search_method" in record and record["search_method"] != "":
        _enum(record["search_method"], "source search_method", VALID_SEARCH_METHODS)
    if "login_required" in record and record["login_required"] != "":
        _enum(record["login_required"], "source login_required", VALID_LOGIN_MODES)
    if "age_gate" in record and record["age_gate"] != "":
        _enum(record["age_gate"], "source age_gate", VALID_AGE_GATES)
    if "visibility" in record and record["visibility"] != "":
        _enum(record["visibility"], "source visibility", VALID_VISIBILITIES)
    if "status" in record and record["status"] != "":
        _enum(record["status"], "source status", VALID_STATUSES)
    if "last_reviewed" in record and record["last_reviewed"] != "":
        _iso_date(record["last_reviewed"], "source last_reviewed")
    if "robots_notes" in record and record["robots_notes"] != "":
        _string(record["robots_notes"], "source robots_notes", 350)
    if "caveats" in record and record["caveats"] != "":
        _string(record["caveats"], "source caveats", 450)
    if "subpages" in record and record["subpages"] is not None:
        subpages = record["subpages"]
        if not isinstance(subpages, list) or len(subpages) > MAX_SUBPAGES:
            raise PackError("Invalid source subpages list")
        seen_sub = set()
        for sub in subpages:
            sub_url = _web_url(sub)
            if sub_url in seen_sub:
                raise PackError("Duplicate subpage URL in source record")
            seen_sub.add(sub_url)
    return url


def validate_manifest(data):
    if not isinstance(data, dict) or data.get("format") != FORMAT:
        raise PackError("Not a Field Index v1 module")
    ident = _string(data.get("id"), "module ID", 49)
    if not ID_PATTERN.fullmatch(ident):
        raise PackError("Module ID must use lowercase letters, digits and dashes")
    version = _string(data.get("version"), "version", 24)
    if not SEMVER.fullmatch(version):
        raise PackError("Module version must be major.minor.patch")
    _string(data.get("name"), "module name", 90)
    _string(data.get("description"), "description", 600)
    if "reviewed" in data and data["reviewed"]:
        _iso_date(data["reviewed"], "module reviewed date")
    if "scope_boundary" in data and data["scope_boundary"]:
        _string(data["scope_boundary"], "module scope_boundary", 600)

    sources = data.get("sources", [])
    recipes = data.get("recipes", [])
    if (
        not isinstance(sources, list)
        or not isinstance(recipes, list)
        or len(sources) > MAX_SOURCES
        or len(recipes) > MAX_RECIPES
    ):
        raise PackError("Source or recipe limit exceeded")
    if not sources and not recipes:
        raise PackError("Module has no sources or recipes")

    unique_urls = set()
    for s in sources:
        url = _validate_source(s)
        if url in unique_urls:
            raise PackError("Duplicate source URL within module")
        unique_urls.add(url)

    recipe_names = set()
    for r in recipes:
        if not isinstance(r, dict):
            raise PackError("Invalid search recipe")
        name = _string(r.get("name"), "recipe name", 110)
        if name in recipe_names:
            raise PackError("Duplicate recipe name")
        recipe_names.add(name)
        query = _string(r.get("query"), "recipe query", 350)
        _string(r.get("description"), "recipe description", 300)
        if "category" in r and r["category"]:
            _string(r["category"], "recipe category", 90)
        if "region" in r and r["region"]:
            _string(r["region"], "recipe region", 90)
        # Templates support two literal substitutions and NO Python expressions.
        if not re.fullmatch(r"(?:[^{}]|\{topic\}|\{region\})+", query):
            raise PackError("Recipe may use only {topic} and {region} placeholders")
    return data


def pack_bytes(path):
    path = Path(path)
    if path.stat().st_size > MAX_FILE:
        raise PackError("Module exceeds 1 MB")
    with zipfile.ZipFile(path) as z:
        entries = z.infolist()
        if not 1 <= len(entries) <= MAX_ENTRIES or not any(x.filename == "manifest.json" for x in entries):
            raise PackError("Module must contain a manifest.json")
        seen_names = set()
        total = 0
        for item in entries:
            if (
                item.filename in seen_names
                or item.filename not in ALLOWED_ARCHIVE_FILES
                or item.is_dir()
                or (item.external_attr >> 16) & 0o170000 == 0o120000
            ):
                raise PackError("Module contains unsupported files")
            seen_names.add(item.filename)
            # Bounded stream read prevents spoofed ZIP-header size bombs.
            with z.open(item, "r") as stream:
                chunk = stream.read(MAX_FILE + 1)
            if len(chunk) > MAX_FILE:
                raise PackError("Module is too large")
            total += len(chunk)
            if total > MAX_FILE:
                raise PackError("Module is too large")
            if item.filename == "manifest.json":
                raw = chunk
    try:
        data = json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeError) as exc:
        raise PackError("Invalid manifest.json") from exc
    return validate_manifest(data), raw


def _split_subpages(value):
    if not value:
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in re.split(r"[;|\n]+", str(value)) if x.strip()]


class Registry:
    def __init__(self, home):
        self.folder = Path(home) / "extensions"
        self.folder.mkdir(parents=True, exist_ok=True)

    def installed(self):
        rows = []
        for folder in sorted(self.folder.iterdir()):
            if not folder.is_dir() or not ID_PATTERN.fullmatch(folder.name):
                continue
            try:
                raw = (folder / "manifest.json").read_bytes()
                if len(raw) > MAX_FILE:
                    raise PackError("Manifest exceeds limit")
                obj = validate_manifest(json.loads(raw.decode("utf-8")))
                if obj["id"] != folder.name:
                    raise PackError("Module folder and ID disagree")
                enabled = (folder / "disabled.flag").exists() is False
                rows.append((obj, enabled, ""))
            except (OSError, ValueError, UnicodeError) as exc:
                rows.append(({"id": folder.name, "name": folder.name, "version": "?", "description": ""}, False, str(exc)))
        return rows

    def get_filters(self, ident):
        if not ID_PATTERN.fullmatch(ident):
            raise PackError("Invalid module ID")
        path = self.folder / ident / "filters.json"
        if not path.is_file():
            return {"disabled_categories": [], "disabled_regions": []}
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {"disabled_categories": [], "disabled_regions": []}
        cats = [x for x in raw.get("disabled_categories", []) if isinstance(x, str)]
        regs = [x for x in raw.get("disabled_regions", []) if isinstance(x, str)]
        return {"disabled_categories": sorted(set(cats)), "disabled_regions": sorted(set(regs))}

    def set_filters(self, ident, disabled_categories=None, disabled_regions=None):
        """Enable or disable categories/regions within a pack without rebuilding."""
        if not ID_PATTERN.fullmatch(ident):
            raise PackError("Invalid module ID")
        target = self.folder / ident
        if not target.is_dir():
            raise PackError("Module not installed")
        current = self.get_filters(ident)
        if disabled_categories is not None:
            current["disabled_categories"] = sorted({_string(x, "category filter", 90) for x in disabled_categories})
        if disabled_regions is not None:
            current["disabled_regions"] = sorted({_string(x, "region filter", 90) for x in disabled_regions})
        tmp = target / ".filters.json.tmp"
        tmp.write_text(json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(target / "filters.json")
        return current

    def active(self):
        return [entry for entry, enabled, error in self.installed() if enabled and not error]

    def active_filtered(self):
        """Return active pack manifests with disabled categories/regions pruned."""
        result = []
        for pack in self.active():
            filters = self.get_filters(pack["id"])
            off_cats = set(filters["disabled_categories"])
            off_regs = set(filters["disabled_regions"])
            if not off_cats and not off_regs:
                result.append(pack)
                continue
            pruned = dict(pack)
            pruned["sources"] = [
                s for s in pack.get("sources", [])
                if s.get("category") not in off_cats and s.get("region") not in off_regs
            ]
            pruned["recipes"] = [
                r for r in pack.get("recipes", [])
                if r.get("category") not in off_cats and r.get("region") not in off_regs
            ]
            result.append(pruned)
        return result

    def sources(self):
        rows = []
        info = {}
        seen = set()
        for pack in self.active_filtered():
            pack_reviewed = pack.get("reviewed") or "User-installed pack"
            for s in pack.get("sources", []):
                if s["url"] in seen:
                    continue
                seen.add(s["url"])
                rows.append((s["category"], s["name"], s["url"], s["description"]))
                status_label = {
                    "active_public": "Active public source",
                    "public_info_member_gated": "Public info only (member-gated community)",
                    "regional_directory": "Regional public directory",
                    "dormant_or_restricted": "Dormant or restricted — verify before relying",
                }.get(s.get("status", ""), "Unverified source-pack entry")
                info[s["url"]] = dict(
                    country=s["region"],
                    kind=s["type"],
                    reviewed=s.get("last_reviewed") or pack_reviewed,
                    status=status_label,
                    module=pack["name"],
                    locality=s.get("locality", s["region"]),
                    subpages=list(s.get("subpages", [])),
                    search_method=s.get("search_method", "site_dork"),
                    login_required=s.get("login_required", "none"),
                    age_gate=s.get("age_gate", "none"),
                    visibility=s.get("visibility", "public_open"),
                    robots_notes=s.get("robots_notes", ""),
                    caveats=s.get("caveats", ""),
                )
        return rows, info

    def recipes(self):
        return [
            (pack["name"], r["name"], r["query"], r["description"])
            for pack in self.active_filtered()
            for r in pack.get("recipes", [])
        ]

    def install(self, path):
        data, raw = pack_bytes(path)
        ident = data["id"]
        target = self.folder / ident
        staging = Path(tempfile.mkdtemp(prefix=".fieldindex-install-", dir=self.folder))
        backup = self.folder / (".backup-" + ident)
        try:
            (staging / "manifest.json").write_bytes(raw)
            if target.exists():
                if (target / "disabled.flag").exists():
                    (staging / "disabled.flag").write_text("disabled", encoding="ascii")
                if (target / "filters.json").is_file():
                    shutil.copy2(target / "filters.json", staging / "filters.json")
            if backup.exists():
                raise PackError("Backup exists from an incomplete update. Contact support before replacing module")
            if target.exists():
                target.rename(backup)
            try:
                staging.rename(target)
            except OSError:
                if backup.exists():
                    backup.rename(target)
                raise
            if backup.exists():
                shutil.rmtree(backup)
        finally:
            if staging.exists():
                shutil.rmtree(staging)
        return data

    def _install_manifest_dict(self, data):
        validated = validate_manifest(data)
        with tempfile.TemporaryDirectory(prefix=".fieldindex-import-") as temp:
            archive = Path(temp) / (validated["id"] + ".fipack")
            with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
                z.writestr("manifest.json", json.dumps(validated, ensure_ascii=False, indent=2))
            return self.install(archive)

    def import_csv(self, csv_path, module_name):
        """Make a local data-only source module from a reviewed CSV directory."""
        module_name = _string(module_name, "module name", 90)
        ident = re.sub(r"[^a-z0-9]+", "-", module_name.lower()).strip("-")[:49].strip("-")
        if len(ident) < 3 or not ID_PATTERN.fullmatch(ident):
            raise PackError("Choose a longer module name using letters")
        path = Path(csv_path)
        if path.stat().st_size > 250_000:
            raise PackError("CSV file exceeds 250 KB")
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            if not reader.fieldnames or not {"name", "url"}.issubset({x.lower().strip() for x in reader.fieldnames}):
                raise PackError("CSV needs name and url columns")
            sources = []
            for record in reader:
                if len(sources) >= MAX_SOURCES:
                    raise PackError("More than 300 source records")
                fields = {key.lower().strip(): (value or "").strip() for key, value in record.items() if isinstance(key, str)}
                entry = dict(
                    name=fields.get("name", ""),
                    url=fields.get("url", ""),
                    category=fields.get("category") or "User directory",
                    region=fields.get("region") or "International",
                    type=fields.get("type") or "Public source",
                    description=fields.get("description") or "User-imported source; verify independently.",
                )
                for opt in ("locality", "search_method", "login_required", "age_gate", "visibility", "robots_notes", "last_reviewed", "status", "caveats"):
                    if fields.get(opt):
                        entry[opt] = fields[opt]
                if fields.get("subpages"):
                    entry["subpages"] = _split_subpages(fields["subpages"])
                sources.append(entry)
        if not sources:
            raise PackError("No sources in CSV")
        data = dict(
            format=FORMAT,
            id=ident,
            version="1.0.0",
            name=module_name,
            description="Public-source directory imported from CSV. Verify all websites and rights to use the information.",
            sources=sources,
            recipes=[],
        )
        return self._install_manifest_dict(data)

    def import_json(self, json_path, module_name=None):
        """Import a reviewed JSON manifest or directory list as a data-only module."""
        path = Path(json_path)
        if path.stat().st_size > MAX_FILE:
            raise PackError("JSON file exceeds 1 MB")
        try:
            raw = json.loads(path.read_text(encoding="utf-8-sig"))
        except (OSError, ValueError, UnicodeError) as exc:
            raise PackError("Invalid JSON directory") from exc
        if not isinstance(raw, dict):
            raise PackError("JSON directory must be an object")
        if raw.get("format") == FORMAT:
            data = dict(raw)
            if module_name:
                data["name"] = _string(module_name, "module name", 90)
            return self._install_manifest_dict(data)
        sources = raw.get("sources")
        recipes = raw.get("recipes", [])
        if not isinstance(sources, list) or not sources:
            raise PackError("JSON directory needs a non-empty sources list")
        title = _string(module_name or raw.get("name") or path.stem, "module name", 90)
        ident = raw.get("id") or re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")[:49].strip("-")
        if len(ident) < 3 or not ID_PATTERN.fullmatch(ident):
            raise PackError("Choose a longer module name using letters")
        data = dict(
            format=FORMAT,
            id=ident,
            version=raw.get("version") or "1.0.0",
            name=title,
            description=raw.get("description") or "Public-source directory imported from JSON. Verify all websites independently.",
            sources=sources,
            recipes=recipes,
        )
        if raw.get("reviewed"):
            data["reviewed"] = raw["reviewed"]
        return self._install_manifest_dict(data)

    def export(self, ident, destination):
        """Save a module to a shareable data-only .fipack archive."""
        if not ID_PATTERN.fullmatch(ident):
            raise PackError("Invalid module ID")
        item = self.folder / ident / "manifest.json"
        obj = validate_manifest(json.loads(item.read_text(encoding="utf-8")))
        if obj["id"] != ident:
            raise PackError("Invalid module folder")
        with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("manifest.json", item.read_bytes())
        return destination

    def enable(self, ident, enable=True):
        if not ID_PATTERN.fullmatch(ident):
            raise PackError("Invalid module ID")
        target = self.folder / ident
        if not target.is_dir():
            raise PackError("Module not installed")
        flag = target / "disabled.flag"
        if enable:
            flag.unlink(missing_ok=True)
        else:
            flag.write_text("disabled", encoding="ascii")

    def remove(self, ident):
        if not ID_PATTERN.fullmatch(ident):
            raise PackError("Invalid module ID")
        target = self.folder / ident
        if not target.is_dir():
            raise PackError("Module not installed")
        shutil.rmtree(target)


def make_query(template, topic, region=""):
    query = _string(template, "recipe query", 350)
    if not re.fullmatch(r"(?:[^{}]|\{topic\}|\{region\})+", query):
        raise PackError("Invalid query recipe")
    topic = _string(topic, "research topic", 160)
    region = _string(region, "region", 80, allow_empty=True)
    result = query.replace("{topic}", topic).replace("{region}", region)
    return " ".join(result.split())
