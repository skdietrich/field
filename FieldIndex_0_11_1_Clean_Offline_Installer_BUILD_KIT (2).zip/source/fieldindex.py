"""Field Index 0.11 desktop research workbench."""
import csv
import io
import json
import os
import sys
import queue
import zipfile
import re
import sqlite3
import threading
import time
import webbrowser
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from urllib.parse import quote, urlsplit

import engine as e
import dork_search as ds
import holehe_portal as hp
import sherlock_bridge as sb
import maigret_bridge as mb
import discovery as d
import adapters
import storage
from extensions import Registry, PackError, make_query, pack_bytes

BG="#111820"; SIDE="#19232e"; PANEL="#202d39"; INK="#e9efef"; MUTED="#a8bbc4"; MINT="#8de0bf"; BLUE="#314756"
NAV=[
    "Dashboard","Intake","Investigation plan","Community sources","Web discovery",
    "Usernames","Maigret","Sherlock","Google dorking","Holehe OSINT",
    *e.CATALOG,"Extensions","Source health","Evidence"
]
INTAKE=[
    ("subject","Topic or display name"),
    ("user","Known username"),
    ("email","Public email address"),
    ("phone","Public phone number (optional)"),
    ("ip","Public IP address (optional)"),
    ("org","Organization"),
    ("place","Place or region"),
    ("site","Publisher domain"),
    ("url","Document or publisher URL"),
    ("doi","Publication DOI"),
    ("phrase","Exact title or quotation"),
    ("goal","Research question"),
]

def now(): return datetime.now(timezone.utc).isoformat(timespec="seconds")
def browser(url):
    if urlsplit(url).scheme in ("https","http") and urlsplit(url).hostname: webbrowser.open(url)
def button(p,s,f,accent=False):
    b=tk.Button(p,text=s,command=f,bg=MINT if accent else BLUE,fg=BG if accent else INK,activebackground="#acd9cd",relief="flat",padx=12,pady=6,font=("Segoe UI",10),cursor="hand2")
    b.pack(side="left",padx=(0,7),pady=3)
    return b
def frame(p,bg=BG): return tk.Frame(p,bg=bg)
def line(p):
    r=frame(p); r.pack(fill="x",pady=3); return r
def label(p,s,size=10,color=INK,bold=False):
    w=tk.Label(p,text=s,bg=p.cget("bg"),fg=color,font=("Segoe UI",size,"bold" if bold else "normal"),anchor="w",justify="left",wraplength=680)
    w.pack(anchor="w",fill="x"); return w
def entry(p,v):
    w=tk.Entry(p,textvariable=v,bg=PANEL,fg=INK,insertbackground=INK,relief="flat",font=("Segoe UI",11),highlightthickness=1,highlightbackground=BLUE)
    w.pack(fill="x",ipady=5,pady=(3,5)); return w

class Workspace:
    def __init__(self,root,folder=None):
        self.root=root; root.title("Field Index 0.11  |  Extensible Research Workbench"); root.geometry("1180x820"); root.minsize(800,560); root.configure(bg=BG)
        home=Path(folder or Path(os.getenv("LOCALAPPDATA") or Path.home())/"FieldIndex"); home.mkdir(parents=True,exist_ok=True)
        self.home = home
        self.extensions = Registry(home)
        db_path = home / "cases.sqlite3"
        prior_database = db_path.is_file()
        self.db = sqlite3.connect(db_path)
        # The first packaged launch may migrate an existing case database. Take a
        # SQLite-consistent backup first, while leaving the original untouched.
        # Never delete the backup as part of uninstalling the application.
        marker = home / ".pre_0_11_1_backup_complete"
        if prior_database and not marker.exists():
            stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            backup_path = home / ("cases.before_0_11_1_" + stamp + ".sqlite3")
            try:
                with sqlite3.connect(backup_path) as target:
                    self.db.backup(target)
                marker.write_text(backup_path.name + "\n", encoding="utf-8")
            except Exception:
                self.db.close()
                raise
        storage.apply_migrations(self.db)
        self.plan_events=queue.Queue()
        self.active_plans={}
        self.stop_events={}
        self.sherlock_cancel={}
        self.maigret_cancel={}
        self.bg_cancels={}
        self.search_key=os.environ.get("BRAVE_SEARCH_API_KEY","")
        self.closing=False
        self._close_deadline=0.0
        root.protocol("WM_DELETE_WINDOW",self.close)
        self.case=1; self.values={}; self.jobs=queue.Queue(); self.running={}; self.view=""
        self.side=frame(root,SIDE); self.side.pack(side="left",fill="y")
        label(self.side,"FIELD INDEX",17,MINT,True).pack_configure(padx=15,pady=(17,8))
        self.casebox=ttk.Combobox(self.side,state="readonly",width=22); self.casebox.pack(padx=12,pady=3)
        self.casebox.bind("<<ComboboxSelected>>",self.switch)
        button(line(self.side),"New case",self.new_case)
        self.buttons={}
        menu=tk.Menu(root);workspaces=tk.Menu(menu,tearoff=False)
        for destination in NAV:workspaces.add_command(label=destination,command=lambda n=destination:self.show(n))
        menu.add_cascade(label="Workspaces",menu=workspaces);root.configure(menu=menu)
        for n in NAV:
            b=tk.Button(self.side,text=n,command=lambda n=n:self.show(n),anchor="w",padx=16,pady=3,bg=SIDE,fg=INK,relief="flat",font=("Segoe UI",10),cursor="hand2")
            b.pack(fill="x");self.buttons[n]=b
        self.status=tk.StringVar(value="Ready")
        ttk.Label(root,textvariable=self.status,anchor="w",padding=6).pack(side="bottom",fill="x")
        outer=frame(root);outer.pack(fill="both",expand=True)
        self.canvas=tk.Canvas(outer,bg=BG,highlightthickness=0);bar=ttk.Scrollbar(outer,command=self.canvas.yview);bar.pack(side="right",fill="y")
        self.canvas.pack(fill="both",expand=True);self.canvas.configure(yscrollcommand=bar.set)
        self.body=frame(self.canvas);item=self.canvas.create_window(0,0,window=self.body,anchor="nw")
        self.canvas.bind("<Configure>",lambda ev:self.canvas.itemconfigure(item,width=ev.width))
        self.body.bind("<Configure>",lambda ev:self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        root.bind_all("<MouseWheel>",self._on_mousewheel)
        root.bind_all("<Button-4>",lambda ev:self._on_linux_scroll(ev,-1))
        root.bind_all("<Button-5>",lambda ev:self._on_linux_scroll(ev,1))
        self.refresh_cases();self.show("Dashboard");root.after(150,self.drain)

    def _on_mousewheel(self,ev):
        try:
            if ev.widget.winfo_toplevel() is not self.root:
                return
        except tk.TclError:
            return
        if not ev.delta:
            return
        step = -1 if ev.delta > 0 else 1
        units = -int(ev.delta / 120) if abs(ev.delta) >= 120 else step
        self.canvas.yview_scroll(units, "units")

    def _on_linux_scroll(self,ev,direction):
        try:
            if ev.widget.winfo_toplevel() is not self.root:
                return
        except tk.TclError:
            return
        self.canvas.yview_scroll(direction, "units")

    def refresh_cases(self):
        names=dict(self.db.execute("SELECT id,name FROM cases ORDER BY id")); self.casebox["values"]=list(names.values());self.casebox.set(names[self.case])

    def close(self):
        self.closing=True
        self._close_deadline = time.monotonic() + 3.0
        for stop in self.stop_events.values():stop.set()
        for stop in self.sherlock_cancel.values():stop.set()
        for stop in self.maigret_cancel.values():stop.set()
        for stop in self.bg_cancels.values():stop.set()
        self.status.set("Cancelling active requests and saving results before closing...")
        self.finish_close()

    def finish_close(self):
        if (self.active_plans or self.running) and time.monotonic() < self._close_deadline:
            self.root.after(150,self.finish_close);return
        for callback in self.root.tk.splitlist(self.root.tk.call("after","info")):
            self.root.after_cancel(callback)
        self.db.close()
        self.root.destroy()

    def switch(self,*a):
        self.case=self.db.execute("SELECT id FROM cases WHERE name=?",(self.casebox.get(),)).fetchone()[0]
        self.values={};self.show("Dashboard")

    def new_case(self):
        n=simpledialog.askstring("New case","Case name",parent=self.root)
        if not n or not n.strip():return
        try:
            with self.db:self.case=self.db.execute("INSERT INTO cases(name) VALUES(?)",(n.strip(),)).lastrowid
        except sqlite3.IntegrityError: return messagebox.showinfo("New case","This name is already in use.")
        self.values={};self.refresh_cases();self.show("Intake")

    def var(self,key,default=""):
        if key not in self.values:
            row=self.db.execute("SELECT v FROM fields WHERE c=? AND k=?",(self.case,key)).fetchone()
            v=tk.StringVar(value=row[0] if row else default);case=self.case
            def save(*args):
                with self.db:self.db.execute("INSERT OR REPLACE INTO fields VALUES(?,?,?)",(case,key,v.get()))
            v.trace_add("write",save);self.values[key]=v
        return self.values[key]

    def get(self,k):return self.var(k).get().strip()

    def show(self,n):
        self.view=n
        for child in self.body.winfo_children():child.destroy()
        for key,b in self.buttons.items():b.configure(bg=BLUE if n==key else SIDE,fg=MINT if n==key else INK)
        p=frame(self.body);p.pack(fill="both",expand=True,padx=26,pady=20)
        label(p,self.casebox.get().upper()+"   /   RESEARCH WORKSPACE",9,MINT,True)
        label(p,n,26,INK,True).pack_configure(pady=(2,12))
        if n=="Dashboard":self.dashboard(p)
        elif n=="Intake":self.intake(p)
        elif n=="Investigation plan":self.plan(p)
        elif n=="Community sources":self.communities(p)
        elif n=="Web discovery":self.discovery(p)
        elif n=="Usernames":self.usernames(p)
        elif n=="Maigret":self.maigret(p)
        elif n=="Sherlock":self.sherlock(p)
        elif n=="Google dorking":self.dorking(p)
        elif n=="Holehe OSINT":self.holehe(p)
        elif n=="Google builder":self.builder(p)
        elif n=="Extensions":self.extensions_page(p)
        elif n=="Source health":self.source_health(p)
        elif n=="Evidence":self.evidence(p)
        else:self.catalog(p,n)
        self.canvas.yview_moveto(0)

    def dashboard(self,p):
        total=self.db.execute("SELECT count(*) FROM records WHERE c=?",(self.case,)).fetchone()[0]
        hyp_count=self.db.execute("SELECT count(*) FROM case_hypotheses WHERE c=?",(self.case,)).fetchone()[0]
        label(p,f"{total} ledger entries     •     {hyp_count} case hypotheses     •     {len(e.PROVIDERS)} direct handle sources     •     Full Maigret & Sherlock bridges",11,MINT)
        label(p,"Start with what you know",16,INK,True).pack_configure(pady=(18,2))
        label(p,"Enter a handle, email, document URL, DOI or topic. For a one-word topic, use Full case intake.",10,MUTED)
        quick=tk.StringVar();entry(p,quick)
        def route():
            s=quick.get().strip()
            if not s:return
            k="email" if re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+",s) else "user" if s.startswith("@") or re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}",s) else "subject"
            if s.startswith(("https://doi.org/","10.")) and "/" in s:k="doi"
            elif s.startswith(("http://","https://")):k="url"
            self.var(k).set(s.lstrip("@") if k=="user" else s);self.show("Investigation plan")
        actions=line(p);button(actions,"Build investigation plan",route,True)
        button(actions,"Full case intake",lambda:self.show("Intake"))
        r=line(p);button(r,"Community sources",lambda:self.show("Community sources"),True)
        button(r,"Web discovery",lambda:self.show("Web discovery"))
        button(r,"Extensions",lambda:self.show("Extensions"))
        button(r,"Source health",lambda:self.show("Source health"))
        cards=[
            ("Usernames","Compare an exact handle across 10 direct public APIs."),
            ("Maigret","Run full uncapped Maigret CLI username scans with JSON parsing and coverage metrics."),
            ("Sherlock","Run full Sherlock CLI username scans with opt-in adult checks and CSV telemetry."),
            ("Google dorking","Build focused public-web queries with explicit 7-engine operator translation."),
            ("Holehe OSINT","Open the independent Holehe.org web portal for manually reviewed lookups."),
            ("Archives","Search digitized collections and historic records."),
            ("Publications","Find papers, DOI records and scholarly metadata."),
            ("Organizations","Look up filings, registries and legal entities."),
            ("Places & maps","Compare named places in public gazetteers."),
            ("News & web","Review news coverage and seven search engines."),
            ("Extensions","Install data-only research packs, region/category filters, and CSV/JSON imports."),
            ("Evidence","Review attribution decisions, hypotheses, grouped URLs, backups, and Markdown reports."),
        ]
        grid=frame(p);grid.pack(fill="x",pady=12)
        for i,(title,desc) in enumerate(cards):
            cell=frame(grid,PANEL);cell.grid(row=i//2,column=i%2,sticky="nsew",padx=3,pady=3,ipadx=4,ipady=4)
            b=tk.Button(cell,text=title+"   ›",command=lambda n=title:self.show(n),anchor="w",relief="flat",bg=PANEL,fg=MINT,font=("Segoe UI",12,"bold"),cursor="hand2");b.pack(fill="x")
            label(cell,desc,9,MUTED).configure(wraplength=280)
        grid.columnconfigure((0,1),weight=1,uniform="cards")

    def intake(self,p):
        button(line(p),"Build investigation plan",lambda:self.show("Investigation plan"),True)
        label(p,"Fill in any fields you know. Entries save as you type. Review a destination below to choose what gets sent.",10,MUTED)
        for k,title in INTAKE:
            label(p,title);entry(p,self.var(k))
        label(p,"Case Scope & Lawful Authorization",13,MINT,True).pack_configure(pady=(14,2))
        scope_row = self.db.execute("SELECT authority_basis, allowed_scope, prohibited_scope FROM case_scope WHERE c=?", (self.case,)).fetchone()
        auth_v = tk.StringVar(value=scope_row[0] if scope_row else "")
        allow_v = tk.StringVar(value=scope_row[1] if scope_row else "Public sources and operator-authorized records only")
        prohib_v = tk.StringVar(value=scope_row[2] if scope_row else "No login bypass, private member scraping, or unverified identity claims")
        label(p,"Authority / permission basis"); entry(p,auth_v)
        label(p,"Permitted scope"); entry(p,allow_v)
        label(p,"Prohibited scope"); entry(p,prohib_v)
        def save_scope():
            with self.db:
                self.db.execute(
                    "INSERT OR REPLACE INTO case_scope(c,authority_basis,allowed_scope,prohibited_scope,updated_utc) VALUES(?,?,?,?,?)",
                    (self.case, auth_v.get().strip(), allow_v.get().strip(), prohib_v.get().strip(), now()),
                )
            self.status.set("Saved case scope and authorization record.")
        button(line(p),"Save case scope",save_scope)
        r=line(p)
        button(r,"Review handle",lambda:self.show("Usernames"));button(r,"Build Google query",lambda:self.show("Google dorking"),True)
        suggested=[]
        if self.get("org"):suggested.append(("Organizations","organization"))
        if self.get("place"):suggested.append(("Places & maps","place"))
        if self.get("subject") or self.get("phrase"):
            suggested.extend([("Archives","topic or title"),("Publications","topic or title"),("News & web","topic or title")])
        if suggested:
            label(p,"Routes from your intake",13,MINT,True)
            for n,reason in suggested:button(line(p),n+"   ·   "+reason,lambda n=n:self.show(n))

    def suggested(self):
        return self.get("user") or self.get("email").partition("@")[0] or re.sub(r"\s+","",self.get("subject"))

    def record(self,c,source,q,status,url="",note=""):
        with self.db:return self.db.execute("INSERT INTO records(c,time,source,query,status,url,note) VALUES(?,?,?,?,?,?,?)",(c,now(),source,q,status,url,note)).lastrowid

    def plan(self,p):
        label(p,"Review the input beside each source. APIs and installed tools run together. Browser searches become links for you to open.",10,MUTED)
        r=line(p);button(r,"Edit case intake",lambda:self.show("Intake"))
        intake={k:self.get(k) for k,_ in INTAKE}
        try:routes=e.plan_sources(intake)
        except ValueError as ex:label(p,str(ex),11,MINT);return
        if not routes:
            label(p,"Add case clues to build a new plan.")
        if self.search_key and intake["email"] and not any(x[0]=="Brave Search" for x in routes):
            routes.insert(0,("Brave Search",'"'+intake["email"]+'"',"Web results",True))
        picks=[]
        groups={}
        for route in routes:
            source,q,kind,enabled=route
            groups.setdefault((kind,q),[]).append(route)
        def begin():
            chosen=[route for route,flag in picks if flag.get()]
            if not chosen:return messagebox.showinfo("Investigation plan","Select one or more routes.")
            self.start_plan(chosen);self.show("Investigation plan")
        if self.case in self.active_plans:
            label(r,"Search in progress. Results are saved as each source finishes.",10,MINT)
            button(line(p),"Cancel pending sources",self.stop_events[self.case].set)
        elif routes:button(r,"Run selected plan",begin,True)
        for (kind,q),items in groups.items():
            label(p,kind+"    /    "+q,12,MINT,True).pack_configure(pady=(10,2))
            if kind=="Exact email search":
                def open_email(query=q):
                    url=e.ENGINES["Google"]+quote(query,safe="")
                    self.record(self.case,"Google",query,"Query opened",url)
                    browser(url)
                button(line(p),"Search full address in Google",open_email,True)
            grid=frame(p);grid.pack(fill="x")
            for i,route in enumerate(items):
                source,value,method,enabled=route
                inferred=method in ("Handle API","Local tool") and not intake["user"] and not intake["email"]
                selected=(source=="Google" if method=="Exact email search" else method!="Browser search" and not inferred)
                flag=tk.BooleanVar(value=enabled and selected)
                picks.append((route,flag))
                cb=tk.Checkbutton(grid,text=source+("" if enabled else " (missing)"),variable=flag,bg=BG,fg=INK,selectcolor=PANEL,activebackground=BG,activeforeground=MINT,state="normal" if enabled else "disabled")
                cb.grid(row=i//3,column=i%3,sticky="w")
        runs=list(self.db.execute("SELECT id,started FROM runs WHERE c=? ORDER BY id DESC",(self.case,)))
        if runs:
            label(p,"Investigation history",13,MINT,True)
            names={f"#{i}  {stamp}":i for i,stamp in runs}
            selector=ttk.Combobox(p,values=list(names),state="readonly",width=48)
            selector.pack(anchor="w");selector.current(0)
            results=frame(p);results.pack(fill="x")
            def display(*args):
                for child in results.winfo_children():child.destroy()
                self.table(results,"r.id IN (SELECT record FROM run_records WHERE run=?)",[names[selector.get()]])
            selector.bind("<<ComboboxSelected>>",display);display()
            def retry_unfinished():
                if self.case in self.active_plans:
                    self.status.set("Wait for this case's current run to finish.");return
                original=names[selector.get()]
                routes=[json.loads(row[0]) for row in self.db.execute("SELECT route FROM run_routes WHERE run=? AND completed=0 ORDER BY position",(original,))]
                if not routes:
                    self.status.set("No unfinished routes stored for this run.");return
                self.start_plan(routes);self.show("Investigation plan")
            button(line(p),"Retry failed or unfinished sources",retry_unfinished)

    def start_plan(self,routes):
        if self.closing or not routes:return
        routes=list(dict.fromkeys(tuple(route) for route in routes))
        c=self.case
        if c in self.active_plans:
            self.status.set("This case already has an investigation running.");return
        with self.db:
            run=self.db.execute("INSERT INTO runs(c,started) VALUES(?,?)",(c,now())).lastrowid
            self.db.executemany("INSERT INTO run_routes(run,position,route) VALUES(?,?,?)",[(run,i,json.dumps(route)) for i,route in enumerate(routes)])
        self.active_plans[c]=[run,0,len(routes)]
        stop=threading.Event();self.stop_events[c]=stop
        self.status.set(f"Investigation {run} started • {len(routes)} routes")
        session_key=self.search_key
        def execute(route):
            if stop.is_set():return [(route[0],route[1],"Cancelled before request","","")]
            if route[2]=="Web results" and route[0]=="Brave Search":return d.web_results(route[1],route[0],session_key)
            return e.run_source(route,cancel=stop)
        def worker():
            with ThreadPoolExecutor(max_workers=3) as pool:
                futures={pool.submit(execute,route):i for i,route in enumerate(routes)}
                for future in as_completed(futures):
                    position=futures[future]
                    try:rows=future.result()
                    except Exception as exc:rows=[(routes[position][0],routes[position][1],"Source unavailable","",str(exc)[:400])]
                    self.plan_events.put((c,run,position,rows))
        threading.Thread(target=worker,daemon=True).start()

    def background(self,key,fn,cancel=None):
        if self.closing:return
        c=self.case
        if (c,key) in self.running:return messagebox.showinfo("Running","This case already has that search in progress.")
        self.running[c,key]=True
        if cancel is not None:
            self.bg_cancels[c,key]=cancel
        self.status.set("Running "+key+" …")
        def run():
            try:rows=fn()
            except Exception as ex:rows=[(key,"","Error",""," ".join(str(ex).split())[:500])]
            self.jobs.put((c,key,rows))
        threading.Thread(target=run,daemon=True).start()

    def drain(self):
        while not self.plan_events.empty():
            c,run,position,rows=self.plan_events.get()
            with self.db:
                for row in rows:
                    cursor=self.db.execute("INSERT INTO records(c,time,source,query,status,url,note) VALUES(?,?,?,?,?,?,?)",(c,now(),*row))
                    self.db.execute("INSERT INTO run_records VALUES(?,?)",(run,cursor.lastrowid))
                failures={"Cancelled","Cancelled before request","Source unavailable","DNS lookup failed","Connection failed","Connection timed out","Timed out","Rate limited","Access restricted","Blocked / auth required","Sign-in required","Unavailable / unrecognized reply","Unrecognized provider reply","Malformed tool report","Search provider challenge","API key required","Error"}
                finished=all(row[2] not in failures and not row[2].startswith("HTTP ") for row in rows)
                self.db.execute("UPDATE run_routes SET completed=? WHERE run=? AND position=?",(int(finished),run,position))
            progress=self.active_plans[c];progress[1]+=1
            self.status.set(f"Investigation {run} • {progress[1]} of {progress[2]} routes finished")
            if progress[1]==progress[2]:
                del self.active_plans[c]
                self.stop_events.pop(c,None)
                if self.case==c and self.view in ("Investigation plan","Evidence"):self.show(self.view)
        while not self.jobs.empty():
            c,key,rows=self.jobs.get()
            for row in rows:self.record(c,*row)
            self.running.pop((c,key),None)
            self.bg_cancels.pop((c,key),None)
            if key=="Sherlock scan":self.sherlock_cancel.pop(c,None)
            if key=="Maigret scan":self.maigret_cancel.pop(c,None)
            self.status.set(f"{key} finished • {len(rows)} entries saved to "+self.db.execute("SELECT name FROM cases WHERE id=?",(c,)).fetchone()[0])
            if self.case==c and self.view in (*e.CATALOG,"Usernames","Evidence","Web discovery","Community sources","Extensions","Sherlock","Maigret","Source health"):self.show(self.view)
        self.root.after(150,self.drain)

    def usernames(self,p):
        label(p,"Confirm the spelling before running checks. A matching account name is a lead. Ownership requires separate evidence.",10,MUTED)
        v=tk.StringVar(value=self.get("checked_handle") or self.suggested());entry(p,v)
        def use():v.set(self.suggested())
        button(line(p),"Use current intake suggestion",use)
        flags={};grid=frame(p);grid.pack(fill="x",pady=6)
        for i,n in enumerate(e.PROVIDERS):
            flag=self.var("on."+n,"1");flags[n]=flag
            tk.Checkbutton(grid,text=n,variable=flag,onvalue="1",offvalue="0",bg=BG,fg=INK,selectcolor=PANEL,activebackground=BG,activeforeground=MINT).grid(row=i//3,column=i%3,sticky="w")
        def start(tool=None, legacy=False):
            try:u=e.handle(v.get().strip().lstrip("@"))
            except ValueError as ex:return messagebox.showinfo("Handle",str(ex))
            self.var("checked_handle").set(u)
            names=[n for n,f in flags.items() if f.get()=="1"]
            if not tool and not names:return messagebox.showinfo("Sources","Choose at least one source.")
            cancel=threading.Event()
            def work():
                if tool=="maigret":
                    return mb.scan(u,legacy_three_sites=legacy,cancel=cancel)
                if tool:
                    urls=e.tool_report(tool,u,cancel=cancel)
                    return [(tool,u,"Tool-reported lead",url,"") for url in urls] or [(tool,u,"No reported links","","Review tool coverage before drawing conclusions.")]
                with ThreadPoolExecutor(max_workers=3) as pool:
                    jobs={pool.submit(e.lookup,n,u):n for n in names};rows=[]
                    for job in as_completed(jobs):
                        status,url=job.result(); rows.append((jobs[job],u,status,url,""))
                    return rows
            self.background(tool or "Handle checks",work,cancel=cancel)
        button(line(p),"Run selected sources",start,True)
        label(p,"Optional local CLI tools (full-scan workspaces)",13,INK,True)
        label(p,"Both Maigret and Sherlock now have dedicated full-scan workspaces with no artificial three-site limit, JSON/CSV coverage telemetry, and cancellation.",9,MUTED)
        r=line(p)
        button(r,"Maigret full scan",lambda:self.show("Maigret"),True)
        button(r,"Sherlock full scan",lambda:self.show("Sherlock"),True)
        b_leg=button(r,"Maigret (legacy 3 sites)",lambda:start("maigret",legacy=True))
        if not mb.find_executable():b_leg.configure(state="disabled")
        button(line(p),"Check local tool installations",lambda:self.background("Tool health",e.tool_health))
        all_sources=[*flags,"Sherlock","sherlock","Maigret","maigret"]
        self.table(p,"r.source IN ("+",".join("?" for _ in all_sources)+")",all_sources)

    def _launch_windows_installer(self, script_name, title, prompt_text):
        if getattr(sys,"frozen",False):
            messagebox.showinfo(
                title,
                "This standalone FieldIndex application needs no separate Python or Tkinter.\n\n"
                "Sherlock and Maigret are separate optional CLI programs and are not "
                "installed automatically. For Maigret, use the official standalone "
                "Windows download at https://github.com/soxoj/maigret/releases "
                "and place maigret_standalone.exe under "
                "%LOCALAPPDATA%\\FieldIndex\\tools\\maigret. "
                "Sherlock's Python-based CLI requires its own supported environment.\n\n"
                "Restart FieldIndex or select Recheck installation after installation.",
                parent=self.root,
            )
            return
        folder=Path(sys.executable).resolve().parent if getattr(sys,"frozen",False) else Path(__file__).resolve().parent.parent
        script=folder/script_name
        if not script.is_file():
            messagebox.showwarning("Installer not found",f"Extract the complete FieldIndex 0.11 package; {script_name} should be beside the application files.",parent=self.root)
            return
        if os.name != "nt":
            messagebox.showinfo("Windows installer","The managed installer can only be run on Windows.",parent=self.root)
            return
        if messagebox.askyesno(title,prompt_text,parent=self.root):
            os.startfile(str(script))

    def maigret(self,p):
        """Full uncapped Maigret public username scanner with JSON parsing and coverage telemetry."""
        label(p,"MAIGRET  /  FULL PUBLIC USERNAME SCANNER",13,MINT,True)
        label(p,"Runs the official Maigret CLI or standalone Windows binary on your computer. Supports top-500, full all-sites (-a), tag filtering, custom site selection, structured JSON parsing, and explicit blocked/rate-limited distinction.",10,MUTED)
        found = mb.find_executable()
        label(p,"Local executable: " + (found or "NOT INSTALLED"),10,MINT if found else MUTED)
        actions=line(p)
        button(actions,"Install / repair Maigret",lambda:self._launch_windows_installer(
            "INSTALL_MAIGRET_FOR_FIELDINDEX.cmd",
            "Install Maigret",
            "Install the independent Maigret package inside a FieldIndex-managed Python environment? Downloads from PyPI, requires internet, and never touches your case database.",
        ))
        button(actions,"Recheck installation",lambda:self.show("Maigret"))
        button(actions,"Official Maigret project",lambda:browser("https://github.com/soxoj/maigret"))
        button(actions,"Probe version & flags",lambda:self.background("Tool health",e.tool_health))

        label(p,"Username (public handle you are authorized to research)",11,INK,True).pack_configure(pady=(14,0))
        username=self.var("maigret.username",self.get("user"))
        entry(p,username)

        scope_mode=self.var("maigret.mode","top500")
        mode_row=line(p)
        for caption,val in (
            ("Top 500 sites (default)","top500"),
            ("All supported sites (-a)","all"),
            ("Filter by tags","tags"),
            ("Specific sites","sites"),
            ("Legacy 3-site compat","legacy3"),
        ):
            tk.Radiobutton(mode_row,text=caption,variable=scope_mode,value=val,bg=BG,fg=INK,selectcolor=PANEL,activebackground=BG,activeforeground=MINT).pack(side="left",padx=(0,10))

        label(p,"Optional tags (comma-separated, e.g. us, news, dating) — used when 'Filter by tags' is selected",9,MUTED)
        tags_v=self.var("maigret.tags","")
        entry(p,tags_v)
        label(p,"Optional site names (comma-separated) — used when 'Specific sites' is selected",9,MUTED)
        sites_v=self.var("maigret.sites","")
        entry(p,sites_v)

        include_unconf=self.var("maigret.include_unconfirmed","0")
        tk.Checkbutton(p,text="Also save blocked / rate-limited / timed-out / not-found rows to Evidence (verbose)",variable=include_unconf,onvalue="1",offvalue="0",bg=BG,fg=INK,selectcolor=PANEL,activebackground=BG,activeforeground=MINT).pack(anchor="w",pady=4)

        def start_scan():
            try:
                name=mb.validate_username(username.get())
                mode=scope_mode.get()
                picked_tags=[t.strip() for t in tags_v.get().split(",") if t.strip()] if mode=="tags" else []
                picked_sites=[s.strip() for s in sites_v.get().split(",") if s.strip()] if mode=="sites" else []
                if mode=="tags" and not picked_tags:
                    raise ValueError("Enter one or more comma-separated Maigret tags.")
                if mode=="sites" and not picked_sites:
                    raise ValueError("Enter one or more comma-separated Maigret site names.")
            except ValueError as exc:
                return messagebox.showwarning("Check Maigret inputs",str(exc),parent=self.root)
            if (self.case,"Maigret scan") in self.running:
                return messagebox.showinfo("Already running","There is already a Maigret scan running for this case.",parent=self.root)
            all_sites=(mode=="all")
            legacy3=(mode=="legacy3")
            verbose=(include_unconf.get()=="1")
            cancel=threading.Event()
            self.maigret_cancel[self.case]=cancel
            self.background(
                "Maigret scan",
                lambda:mb.scan(
                    name,
                    all_sites=all_sites,
                    tags=picked_tags,
                    sites=picked_sites,
                    legacy_three_sites=legacy3,
                    include_unconfirmed=verbose,
                    cancel=cancel,
                ),
                cancel=cancel,
            )

        def stop_scan():
            stop=self.maigret_cancel.get(self.case)
            if stop:
                stop.set();self.status.set("Cancelling Maigret scan …")
            else:
                messagebox.showinfo("Maigret","No Maigret scan running for this case.",parent=self.root)

        buttons=line(p)
        button(buttons,"Run full Maigret scan",start_scan,True)
        button(buttons,"Cancel Maigret",stop_scan)
        button(buttons,"View all evidence",lambda:self.show("Evidence"))
        label(p,"Blocked, WAF, CAPTCHA, and rate-limited responses are recorded distinctly and NEVER treated as 'no account'. A reported profile match is an unverified lead, not identity proof.",10,MUTED).pack_configure(pady=(8,8))
        self.table(p,"r.source IN ('Maigret','maigret')")

    def sherlock(self,p):
        """Optional full-site Sherlock public username scanner, without hidden installation."""
        label(p,"SHERLOCK  /  PUBLIC USERNAME RESEARCH",13,MINT,True)
        label(p,"Runs the official Sherlock CLI on your computer. All supported public sites by default, not three. A reported match is a lead, not proof of account ownership or adult-site membership.",10,MUTED)
        found = sb.find_executable()
        label(p,"Local executable: " + (found or "NOT INSTALLED"),10,MINT if found else MUTED)
        actions=line(p)
        button(actions,"Install / repair Sherlock",lambda:self._launch_windows_installer(
            "INSTALL_SHERLOCK_FOR_FIELDINDEX.cmd",
            "Install Sherlock",
            "Install the independent Sherlock package inside a FieldIndex-managed Python environment? This downloads code and dependencies from PyPI, requires internet, and does not modify your case database.",
        ))
        button(actions,"Recheck installation",lambda:self.show("Sherlock"))
        button(actions,"Official Sherlock project",lambda:browser("https://github.com/sherlock-project/sherlock"))
        button(actions,"Probe version & flags",lambda:self.background("Tool health",e.tool_health))
        label(p,"Username (use a public username you are authorized to investigate)",11,INK,True).pack_configure(pady=(18,0))
        username=self.var("sherlock.username",self.get("user"))
        entry(p,username)
        adult=self.var("sherlock.nsfw","0")
        tk.Checkbutton(p,text="Include adult / NSFW sites available in Sherlock's supported list",variable=adult,onvalue="1",offvalue="0",bg=BG,fg=INK,selectcolor=PANEL,activebackground=BG,activeforeground=MINT).pack(anchor="w",pady=6)
        label(p,"Optional: restrict to official Sherlock site names (comma-separated). Leave empty for ALL sites.",10,MUTED)
        sites=self.var("sherlock.sites","")
        entry(p,sites)
        controls=line(p)
        label(controls,"Per-site timeout: 12 seconds. Full scans can run several minutes.",9,MUTED)
        def start_scan():
            try:
                name=sb.validate_username(username.get())
                picked=[v.strip() for v in sites.get().split(",") if v.strip()]
                if any(not re.fullmatch(r"[A-Za-z0-9][\w .&+\-]{0,79}", v) for v in picked):
                    raise ValueError("Enter official Sherlock site names, separated by commas.")
            except ValueError as exc:
                return messagebox.showwarning("Check username",str(exc),parent=self.root)
            if (self.case,"Sherlock scan") in self.running:
                return messagebox.showinfo("Already running","There is already a Sherlock scan running for this case.",parent=self.root)
            adult_enabled=(adult.get()=="1")
            cancel=threading.Event()
            self.sherlock_cancel[self.case]=cancel
            self.background("Sherlock scan",lambda:sb.scan(name,nsfw=adult_enabled,sites=picked,cancel=cancel),cancel=cancel)
        def stop_scan():
            stop=self.sherlock_cancel.get(self.case)
            if stop:
                stop.set();self.status.set("Cancelling Sherlock scan …")
            else:
                messagebox.showinfo("Sherlock","No Sherlock scan running for this case.",parent=self.root)
        buttons=line(p)
        button(buttons,"Run full Sherlock scan",start_scan,True)
        button(buttons,"Cancel Sherlock",stop_scan)
        button(buttons,"View all evidence",lambda:self.show("Evidence"))
        label(p,"Only the username you enter is submitted to sites checked by Sherlock. Adult-site scanning is opt-in. This is not an identity verification or membership detector; investigate public leads independently.",10,MUTED).pack_configure(pady=(10,9))
        self.table(p,"r.source IN ('Sherlock','sherlock')")

    def source_health(self,p):
        """Adapter registry, installed tool diagnostics, and discontinued provider notices."""
        label(p,"Normalized upstream adapter inventory, tool installation status, and provider limitations. Raw source counts never imply verified live coverage.",10,MUTED)
        r=line(p)
        button(r,"Probe local Maigret & Sherlock",lambda:self.background("Tool health",e.tool_health),True)
        button(r,"Manage extension packs",lambda:self.show("Extensions"))
        tree=ttk.Treeview(p,columns=("version","mode","status","tested","source"),show="headings",height=8)
        for col,title,w in [
            ("version","Adapter / Version",185),
            ("mode","Access Mode",150),
            ("status","Status",115),
            ("tested","Last Reviewed",105),
            ("source","Upstream / Notes",320),
        ]:
            tree.heading(col,text=title);tree.column(col,width=w,minwidth=60)
        tree.pack(fill="x",pady=8)
        for desc in adapters.ADAPTER_REGISTRY:
            tree.insert("","end",values=(f"{desc.id} ({desc.version})",desc.access_mode,desc.status,desc.last_tested_utc,desc.source))
        label(p,"Recent tool health checks",13,MINT,True).pack_configure(pady=(10,2))
        self.table(p,"r.query='--version'")

    def holehe(self,p):
        """Manual public portal launcher. No unapproved API or background checks."""
        label(p,"HOLEHE.ORG  /  PUBLIC SOURCE RESEARCH",12,MINT,True)
        label(p,"The independent Holehe.org website offers username, email, phone and IP searches. The original open-source Holehe Python tool is a separate project focused on email registration checks.",10,MUTED)
        label(p,"Field Index does NOT transmit a lookup automatically, read the website's results, or classify any account as found. Open the portal yourself, paste the lookup, then evaluate the evidence there. Consider privacy implications before connecting any account to an outside platform.",10,MUTED).pack_configure(pady=(6,12))
        kinds=hp.LOOKUP_TYPES
        kind=tk.StringVar(value="Username")
        kind_row=line(p)
        for name in kinds:
            tk.Radiobutton(kind_row,text=name,variable=kind,value=name,bg=BG,fg=INK,selectcolor=PANEL,activebackground=BG,activeforeground=MINT).pack(side="left",padx=(0,14))
        label(p,"Lookup value (kept in this window until you choose Save reference)",11,INK,True)
        value=tk.StringVar()
        lookup=entry(p,value)
        lookup.configure(width=55)
        def use_intake():
            field={"Username":"user","Email":"email","Phone":"phone","IP address":"ip"}[kind.get()]
            candidate=self.get(field)
            if not candidate:
                messagebox.showinfo("Case intake","No saved "+field+" value for this case. Enter it directly above.",parent=self.root)
                return
            value.set(candidate)
        def checked():
            try:return hp.validate_lookup(kind.get(),value.get())
            except ValueError as exc:
                messagebox.showwarning("Check lookup",str(exc),parent=self.root)
                return None
        def copy_only():
            subject=checked()
            if subject is None:return
            self.root.clipboard_clear();self.root.clipboard_append(subject)
            self.status.set("Lookup copied. Paste it into Holehe.org manually.")
        def open_portal():
            browser(hp.WEB_PORTAL)
            self.status.set("Opened independent Holehe.org web portal. Nothing was auto-submitted.")
        def both():
            subject=checked()
            if subject is None:return
            self.root.clipboard_clear();self.root.clipboard_append(subject)
            open_portal()
            self.status.set("Opened portal, lookup copied. Paste into the appropriate search box.")
        actions=line(p)
        button(actions,"Copy lookup + open Holehe.org",both,True)
        button(actions,"Open portal only",open_portal)
        button(actions,"Copy lookup",copy_only)
        button(line(p),"Use existing case intake value",use_intake)
        label(p,"Evidence and privacy",15,MINT,True).pack_configure(pady=(18,4))
        label(p,"A username match or registration hint is a lead, never proof of identity, ownership or membership. Site behavior, blocked requests and rate limits can cause misleading results. Use your own data or information you are authorized to investigate.",10,MUTED)
        label(p,"You can save a portal reference in Evidence without pretending that a search result has been verified. Save only information you intentionally want to keep in the case.",10,MUTED)
        def save_reference():
            subject=checked()
            if subject is None:return
            if not messagebox.askyesno("Save research reference", "Save this lookup value as an UNVERIFIED manual research reference in the current case? No website search is performed.",parent=self.root):return
            self.record(self.case,"Holehe.org / "+kind.get(),subject,"Manual lookup pending",hp.WEB_PORTAL,"User saved reference; portal results were not imported or verified")
            self.status.set("Saved manual research reference; not a verified account finding.")
        button(line(p),"Save unverified reference to Evidence",save_reference)
        label(p,"Original open-source project (different from Holehe.org)",15,MINT,True).pack_configure(pady=(19,3))
        label(p,"Holehe by megadose is an optional local command-line tool, not included or executed by this module. Its account-check mechanisms can break when providers change. No API or remote-scanning integration is implied.",10,MUTED)
        other=line(p)
        button(other,"Original Holehe project",lambda:browser(hp.ORIGINAL_CLI))
        button(other,"Python package details",lambda:browser(hp.PYPI_PAGE))
        button(other,"Install website source pack",lambda:self.show("Extensions"))

    def dorking(self,p):
        """Simple first-run search composer with optional power-user controls."""
        label(p,"Build precise public-web searches. No coding, no scraping, and no sign-in bypass. A search hit is a lead, not proof of a private account.",10,MUTED)
        top=line(p)
        button(top,"Detailed four-mode builder",lambda:self.show("Google builder"))
        button(top,"Install / manage source packs",lambda:self.show("Extensions"))

        def instructions():
            popup=tk.Toplevel(self.root);popup.title("Google dorking: five-minute guide");popup.geometry("770x590");popup.configure(bg=BG)
            box=frame(popup);box.pack(fill="both",expand=True,padx=18,pady=18)
            guide=(
                "1. Enter a topic, quotation or subject. If you know the exact wording, use Exact phrase.\n\n"
                "2. Add one publisher in Website, or choose an installed source pack. Field Index creates one search per domain.\n\n"
                "3. Narrow the results with PDF, excluded phrases, dates or title/URL words under Advanced.\n\n"
                "4. Check the live query preview. Select one branch, then Open selected search. Copy query if you want to edit it in your browser.\n\n"
                "5. Save a recipe to rerun it. Searches you open also appear in the case's Evidence history.\n\n"
                'Examples:\nsite:loc.gov "oral history" filetype:pdf\n'
                '"public event calendar" -tickets\n'
                'site:archives.gov "1944" after:2020-01-01\n\n'
                'Operator notes: site:, quoted phrases, exclusions, filetype: and after:/before: are documented by Google. intitle: and inurl: are best effort. Non-Google engines vary.\n\n'
                'Publicly indexed results do not prove who controls a profile. Never bypass age checks, logins or consent requirements.'
            )
            info=tk.Text(box,wrap="word",font=("Segoe UI",11),bg=PANEL,fg=INK,relief="flat",padx=12,pady=12)
            info.pack(fill="both",expand=True);info.insert("1.0",guide);info.configure(state="disabled")
            button(line(box),"Close",popup.destroy,True)
        button(top,"5-minute directions",instructions,True)
        first_actions=line(p)
        button(first_actions,"Search now",lambda:launch(),True)
        button(first_actions,"Copy query",lambda:copy_selected())
        button(first_actions,"Clear filters",lambda:clear_search())

        opts={k:self.var("dork."+k,default) for k,default in (
            ("subject",self.get("subject") or self.get("org")),
            ("exact",self.get("phrase")),("sites",self.get("site")),
            ("exclude",""),("filetype",""),("any",""),("title",""),("inurl",""),
            ("after",""),("before",""),("exclude_sites",""),("variants",""),("raw",""))}
        engine=self.var("dork.engine","Google")
        advanced=self.var("dork.advanced","0")
        group=self.var("dork.pack","")
        packs=ds.source_pack_choices(self.extensions.active_filtered())
        pack_labels={key:display for key,(display,domains) in packs.items()}
        inverse={value:key for key,value in pack_labels.items()}
        if group.get() not in packs:group.set("")
        header=frame(p);header.pack(fill="x",pady=(13,5))
        for col in (0,1):header.columnconfigure(col,weight=1,uniform="dork")
        tk.Label(header,text="Search engine",fg=MINT,bg=BG,anchor="w",font=("Segoe UI",10,"bold")).grid(row=0,column=0,sticky="w")
        tk.Label(header,text="Optional public-site pack",fg=MINT,bg=BG,anchor="w",font=("Segoe UI",10,"bold")).grid(row=0,column=1,sticky="w")
        engine_picker=ttk.Combobox(header,textvariable=engine,state="readonly",values=list(ds.ENGINE_URLS),width=30)
        engine_picker.grid(row=1,column=0,sticky="ew",padx=(0,12),pady=4)
        pack_view=tk.StringVar(value=pack_labels[group.get()])
        pack_picker=ttk.Combobox(header,textvariable=pack_view,state="readonly",values=list(inverse),width=47)
        pack_picker.grid(row=1,column=1,sticky="ew",pady=4)

        def field_box(parent,row,col,name,tip,key):
            cell=frame(parent);cell.grid(row=row,column=col,sticky="new",padx=(0,12) if col==0 else (0,0),pady=6)
            tk.Label(cell,text=name,bg=BG,fg=INK,anchor="w",font=("Segoe UI",10,"bold")).pack(fill="x")
            tk.Label(cell,text=tip,bg=BG,fg=MUTED,anchor="w",font=("Segoe UI",9)).pack(fill="x")
            control=entry(cell,opts[key]);return control

        label(p,"START HERE",12,MINT,True).pack_configure(pady=(12,2))
        basic=frame(p);basic.pack(fill="x")
        for i in (0,1):basic.columnconfigure(i,weight=1,uniform="dork")
        field_box(basic,0,0,"Topic or keywords","Example: 1944 Greek resistance", "subject")
        field_box(basic,0,1,"Exact phrase","Example: military archives", "exact")
        field_box(basic,1,0,"Website(s), optional","example.org, archives.gov (comma-separated)", "sites")
        field_box(basic,1,1,"Exclude words or phrases","Example: advertisement, tickets", "exclude")
        field_box(basic,2,0,"Document types, optional","Example: pdf, csv (one query per type)", "filetype")
        quick=line(p)
        def pdf_only():opts['filetype'].set('pdf')
        def pack_adult():
            choices=[key for key in packs if key.startswith('adult-public-research::') and key.endswith('::*')]
            if not choices:
                messagebox.showinfo('Adult public sources','Install Adult public research in Extensions first. Then select the pack here.');return
            group.set(choices[0]);pack_view.set(pack_labels[group.get()]);refresh()
        button(quick,"PDFs only",pdf_only)
        button(quick,"Search adult public sites",pack_adult)
        tk.Checkbutton(quick,text="Advanced filters",variable=advanced,onvalue="1",offvalue="0",bg=BG,fg=MINT,selectcolor=PANEL,
                       activeforeground=MINT,activebackground=BG,font=("Segoe UI",10,"bold"),command=lambda:self.show("Google dorking")).pack(side="left",padx=9)
        if advanced.get()=="1":
            label(p,"ADVANCED FILTERS",12,MINT,True).pack_configure(pady=(12,2))
            expert=frame(p);expert.pack(fill="x")
            for i in (0,1):expert.columnconfigure(i,weight=1,uniform="dork")
            field_box(expert,0,0,"Any of these alternatives (OR)","Comma-separated words or quoted phrases", "any")
            field_box(expert,0,1,"Required words in page title","Best effort: intitle:", "title")
            field_box(expert,1,0,"Word or phrase in page URL","Best effort: inurl:", "inurl")
            field_box(expert,1,1,"Exclude website(s)","Example: pinterest.com", "exclude_sites")
            field_box(expert,2,0,"Updated from / after","YYYY-MM-DD", "after")
            field_box(expert,2,1,"Updated before","YYYY-MM-DD", "before")
            field_box(expert,3,0,"Name / wording variants","One separate query for each comma-separated item", "variants")
            field_box(expert,3,1,"Custom search syntax (expert)","Typed literally. Review carefully.", "raw")

        label(p,"LIVE SEARCH PREVIEW",12,MINT,True).pack_configure(pady=(13,3))
        count=tk.StringVar(value="")
        tk.Label(p,textvariable=count,bg=BG,fg=MUTED,anchor="w",font=("Segoe UI",9),wraplength=760,justify="left").pack(fill="x")
        queries_box=tk.Listbox(p,height=5,exportselection=False,bg=PANEL,fg=INK,selectbackground=BLUE,
                               selectforeground=MINT,relief="flat",font=("Segoe UI",10))
        queries_box.pack(fill="x",pady=4)
        preview=tk.StringVar()
        tk.Label(p,textvariable=preview,bg=PANEL,fg=MINT,font=("Consolas",10),justify="left",anchor="w",wraplength=730,padx=10,pady=9).pack(fill="x")
        state={'plan':None, 'suppress':False}

        def select_query():
            result=state['plan']
            if result is None or not result.branches:return None
            indexes=queries_box.curselection()
            index=indexes[0] if indexes else 0
            return result.branches[min(index,len(result.branches)-1)]

        def current_spec():return {k:var.get() for k,var in opts.items()}

        def refresh(*ignored):
            if state['suppress']:
                return
            old=queries_box.curselection()
            try:
                plan=ds.build_plan(current_spec(),engine.get(),packs[group.get()][1])
                state['plan']=plan
            except (ValueError,KeyError) as exc:
                state['plan']=None
                queries_box.delete(0,"end")
                preview.set('');count.set('To build a query: '+str(exc))
                return
            queries_box.delete(0,"end")
            for i,b in enumerate(plan.branches):queries_box.insert("end",f"{i+1:03d}  {b.label}")
            index=min(old[0] if old else 0,len(plan.branches)-1)
            queries_box.selection_set(index);queries_box.activate(index)
            update_selected()

        def update_selected(*ignored):
            b=select_query()
            if b is None:return
            plan=state['plan']
            preview.set(b.query)
            more='  '.join(plan.notes)
            warn=ds.disclosure_warning(b.query)
            prefix=f"[PRIVACY NOTICE: {warn}]  " if warn else ""
            count.set(prefix + f"{len(plan.branches)} separate query(s). Select a row below. " + more)
        queries_box.bind('<<ListboxSelect>>',update_selected)
        engine_picker.bind('<<ComboboxSelected>>',refresh)
        def change_pack(*unused):
            group.set(inverse.get(pack_view.get(),''));refresh()
        pack_picker.bind('<<ComboboxSelected>>',change_pack)
        active_traces=[]
        for v in list(opts.values()):
            active_traces.append((v,v.trace_add('write',lambda *unused:refresh())))
        def teardown(event):
            if event.widget is p:
                for v,trace in active_traces:
                    try:v.trace_remove('write',trace)
                    except tk.TclError:pass
        p.bind('<Destroy>',teardown)

        def clear_search():
            if not messagebox.askyesno("Clear search filters","Clear the current dork search fields for this case? Your saved recipes and evidence stay unchanged.",parent=self.root):return
            state['suppress']=True
            try:
                for value in opts.values():value.set('')
                group.set('');pack_view.set(pack_labels['']);engine.set('Google')
            finally:
                state['suppress']=False
            refresh()
        def copy_selected():
            b=select_query()
            if b:
                self.root.clipboard_clear();self.root.clipboard_append(b.query)
                self.status.set('Search copied to clipboard')
        def copy_all():
            plan=state['plan']
            if plan:
                self.root.clipboard_clear();self.root.clipboard_append('\n'.join(branch.query for branch in plan.branches))
                self.status.set(f'Copied {len(plan.branches)} queries')
        def launch():
            b=select_query()
            if b:
                warn=ds.disclosure_warning(b.query)
                if warn and not messagebox.askyesno("Confirm external query", warn + "\n\nContinue opening this search?", parent=self.root):
                    return
                self.record(self.case,'Dork / '+engine.get(),b.query,'Query opened',b.url,b.label)
                browser(b.url)
                self.status.set('Opened '+engine.get()+' search. This is not an identity verification.')
        def save_recipe():
            if state['plan'] is None:return messagebox.showinfo('Save query','Build a valid query first.')
            name=simpledialog.askstring('Save search recipe','Give this query a name',parent=self.root)
            if not name or not name.strip():return
            name=name.strip()
            if len(name)>100:return messagebox.showerror('Recipe name','Keep the name under 100 characters.')
            spec={'fields':current_spec(),'engine':engine.get(),'pack':group.get(),'advanced':advanced.get()}
            existing=self.db.execute('SELECT 1 FROM dork_recipes WHERE c=? AND name=?',(self.case,name)).fetchone()
            if existing and not messagebox.askyesno('Update saved recipe','Replace the previously saved recipe called '+name+'?'):return
            with self.db:self.db.execute('INSERT OR REPLACE INTO dork_recipes(c,name,settings,created) VALUES(?,?,?,?)',(self.case,name,json.dumps(spec),now()))
            self.status.set('Saved recipe: '+name)
            self.show('Google dorking')
        def export_plan():
            plan=state['plan']
            if not plan:return messagebox.showinfo('Export search','Build a valid query first.')
            filename=filedialog.asksaveasfilename(defaultextension='.json',filetypes=[('JSON search plan','*.json'),('All files','*.*')])
            if not filename:return
            payload={'engine':engine.get(),'fields':current_spec(),'pack':group.get(),'notes':list(plan.notes),
                     'branches':[{'label':b.label,'query':b.query,'url':b.url} for b in plan.branches],
                     'note':'Queries are public-web searches, not verified identities or memberships.'}
            try:
                storage.atomic_write_text(filename, json.dumps(payload,indent=2,ensure_ascii=False))
                self.status.set('Search plan exported')
            except OSError as exc:messagebox.showerror('Export failed',str(exc))
        controls=line(p)
        button(controls,'Open selected search',launch,True)
        button(controls,'Copy selected',copy_selected)
        button(controls,'Copy all',copy_all)
        controls2=line(p)
        button(controls2,'Save reusable recipe',save_recipe)
        button(controls2,'Export plan (.json)',export_plan)
        saved=self.db.execute('SELECT name,settings FROM dork_recipes WHERE c=? ORDER BY name',(self.case,)).fetchall()
        if saved:
            def load_saved(*unused):
                raw=dict(saved).get(saved_combo.get())
                if not raw:return
                try:settings=json.loads(raw)
                except ValueError:return messagebox.showerror('Recipe','Saved recipe has invalid JSON.')
                for key,var in opts.items():var.set(settings.get('fields',{}).get(key,''))
                engine.set(settings.get('engine','Google'))
                new_group=settings.get('pack','')
                group.set(new_group if new_group in packs else '')
                advanced.set(settings.get('advanced','0'))
                self.show('Google dorking')
                if new_group and new_group not in packs:self.status.set('Recipe loaded, but its source pack is not installed/enabled.')
            label(p,'Saved search recipes for this case',11,MINT,True).pack_configure(pady=(12,4))
            saved_combo=ttk.Combobox(p,values=[x[0] for x in saved],state='readonly',width=60);saved_combo.pack(anchor='w')
            saved_combo.bind('<<ComboboxSelected>>',load_saved)
        count_recent=self.db.execute("SELECT COUNT(*) FROM records WHERE c=? AND source LIKE 'Dork / %'",(self.case,)).fetchone()[0]
        label(p,f'{count_recent} previously opened dork searches are recorded in Evidence for this case.',9,MUTED).pack_configure(pady=(14,3))
        refresh()

    def builder(self,p):
        mode=self.var("mode","Basic");r=line(p)
        for i,n in enumerate(e.MODES):
            def select(n=n):mode.set(n);self.show("Google builder")
            button(r,n,select,n==mode.get())
        m=e.MODES.index(mode.get());label(p,["Choose your subject.","Add the wording and publisher you trust.","Narrow results by date, document format and exclusions.","Compare name variants and exclude irrelevant publishers. Review each generated search."][m],10,MUTED)
        actions=line(p)
        fields={}; preview=tk.StringVar()
        def update(*a):
            try:preview.set("\n".join(e.queries({k:v.get() for k,v in fields.items()},m)))
            except ValueError as ex:preview.set(str(ex))
        for k,title,tip,level in e.FIELDS:
            if level>m:continue
            seed={"terms":self.get("subject") or self.get("org") or self.get("email"),"phrase":self.get("phrase"),"site":self.get("site")}.get(k,"")
            v=self.var("g."+k,seed);fields[k]=v
            label(p,title,11,INK,True);label(p,tip,9,MUTED);w=entry(p,v);w.bind("<KeyRelease>",update)
        def sync():
            for k,source in [("terms",self.get("subject") or self.get("org") or self.get("email")),("phrase",self.get("phrase")),("site",self.get("site"))]:
                if k in fields and source:fields[k].set(source)
            update()
        def walkthrough():
            steps=[item for item in e.FIELDS if item[3]<=m]
            win=tk.Toplevel(self.root);win.title("Guided query interview");win.geometry("650x350");win.configure(bg=BG)
            win.transient(self.root);win.grab_set()
            box=frame(win);box.pack(fill="both",expand=True,padx=20,pady=18)
            def step(i):
                for widget in box.winfo_children():widget.destroy()
                label(box,f"{mode.get()}   /   Step {i+1} of {len(steps)+1}",10,MINT,True)
                if i==len(steps):
                    update();label(box,"Review the compiled search",17,INK,True);label(box,preview.get(),11)
                    r=line(box);button(r,"Back",lambda:step(i-1))
                    def finish():
                        try:e.queries({k:v.get() for k,v in fields.items()},m)
                        except ValueError as ex:return messagebox.showinfo("Check query",str(ex),parent=win)
                        win.destroy();review()
                    button(r,"Choose a query",finish,True);return
                k,title,tip,_=steps[i]
                label(box,title,18,INK,True);label(box,tip,11,MUTED)
                control=entry(box,fields[k]);control.focus_set()
                label(box,"Leave this field blank if it does not apply.",9,MUTED)
                r=line(box)
                if i:button(r,"Back",lambda:step(i-1))
                button(r,"Continue",lambda:step(i+1),True)
                control.bind("<Return>",lambda ev:step(i+1))
            win.bind("<Destroy>",lambda ev:update() if ev.widget==win else None)
            step(0)
        button(actions,"Walk me through it",walkthrough,True);button(actions,"Use current intake",sync)
        saved=dict(self.db.execute("SELECT name,settings FROM recipes WHERE c=? ORDER BY name",(self.case,)))
        def save_recipe():
            try:e.queries({k:v.get() for k,v in fields.items()},m)
            except ValueError as exc:return messagebox.showinfo("Recipe",str(exc))
            name=simpledialog.askstring("Save query recipe","New recipe name")
            if not name or not name.strip():return
            name=name.strip()
            settings={k:self.get("g."+k) for k,_,_,_ in e.FIELDS};settings["mode"]=mode.get()
            try:
                with self.db:self.db.execute("INSERT INTO recipes VALUES(?,?,?)",(self.case,name,json.dumps(settings)))
            except sqlite3.IntegrityError:return messagebox.showinfo("Recipe","Choose a new name for this variation.")
            self.show("Google builder")
        button(actions,"Save recipe",save_recipe)
        if saved:
            label(p,"Saved recipes",11,MINT)
            pick=ttk.Combobox(p,values=list(saved),state="readonly");pick.pack(anchor="w")
            def load_recipe(*args):
                settings=json.loads(saved[pick.get()])
                for k,_,_,_ in e.FIELDS:self.var("g."+k).set(settings.get(k,""))
                mode.set(settings["mode"]);self.show("Google builder")
            pick.bind("<<ComboboxSelected>>",load_recipe)
        label(p,"Query preview",13,MINT,True);tk.Label(p,textvariable=preview,bg=PANEL,fg=INK,padx=8,pady=8,wraplength=680,justify="left",anchor="w").pack(fill="x")
        def review():
            spec={k:v.get() for k,v in fields.items()}
            try:qs=e.queries(spec,m)
            except ValueError as ex:return messagebox.showinfo("Check query",str(ex))
            win=tk.Toplevel(self.root);win.title("Choose a query");win.geometry("690x440");win.configure(bg=BG)
            label(win,"Select a query",15,INK,True)
            provider=tk.StringVar(value="Google")
            provider_box=ttk.Combobox(win,textvariable=provider,values=["Google","DuckDuckGo"],state="readonly")
            provider_box.pack(anchor="w")
            explanation=tk.StringVar(value=f"{len(qs)} queries prepared.")
            tk.Label(win,textvariable=explanation,bg=BG,fg=MUTED,wraplength=640,justify="left").pack(fill="x")
            box=tk.Listbox(win,font=("Segoe UI",11));box.pack(fill="both",expand=True)
            for s in qs:box.insert("end",s)
            box.selection_set(0)
            sel=tk.StringVar(value=qs[0]);labeltext=tk.Label(win,textvariable=sel,wraplength=640,bg=PANEL,fg=INK,justify="left");labeltext.pack(fill="x",ipady=6)
            box.bind("<<ListboxSelect>>",lambda ev:sel.set(qs[box.curselection()[0]]) if box.curselection() else None)
            def change_provider(*args):
                new_queries,notes=e.provider_queries(spec,m,provider.get())
                qs[:]=new_queries;box.delete(0,"end")
                for query in qs:box.insert("end",query)
                box.selection_set(0);sel.set(qs[0])
                explanation.set(f"{len(qs)} queries prepared. "+" ".join(notes))
            provider_box.bind("<<ComboboxSelected>>",change_provider)
            c=self.case
            def send():
                q=sel.get();url=e.ENGINES[provider.get()]+quote(q,safe="");self.record(c,provider.get()+" builder",q,"Query opened",url);browser(url)
            def copy():self.root.clipboard_clear();self.root.clipboard_append(sel.get())
            def export_plan():
                path=filedialog.asksaveasfilename(defaultextension=".json",filetypes=[("Query plan","*.json")],parent=win)
                if not path:return
                branches=[{"provider":provider.get(),"query":q,"url":e.ENGINES[provider.get()]+quote(q,safe="")} for q in qs]
                try:
                    storage.atomic_write_text(path, json.dumps({"mode":e.MODES[m],"spec":spec,"notes":explanation.get(),"branches":branches},ensure_ascii=False,indent=2))
                except OSError as exc:messagebox.showerror("Export plan",str(exc),parent=win)
            r=line(win);button(r,"Open selected search",send,True);button(r,"Copy query",copy);button(r,"Export query plan",export_plan)
        update();button(line(p),"Review and send",review,True)

    def catalog(self,p,n):
        seed={"Organizations":"org","Places & maps":"place"}.get(n,"subject")
        v=self.var("topic."+n,self.get(seed) or self.get("phrase") or self.get("subject"))
        label(p,"Search terms");entry(p,v)
        def sync():v.set(self.get(seed) or self.get("subject") or self.get("phrase"))
        button(line(p),"Use current intake",sync)
        if n in e.CATALOG_PROVIDERS:
            src=e.CATALOG_PROVIDERS[n]
            def run(src=src):
                q=v.get().strip()
                if not q:return messagebox.showinfo("Search terms","Enter a topic first.")
                self.background(src,lambda:e.run_source((src,q,"Catalogue API",True)))
            button(line(p),"Retrieve 10 records from "+src,run,True)
        label(p,"Open a source",13,INK,True);label(p,"Opens the provider in your browser and records the search in this case.",9,MUTED)
        def launch(source,url):
            q=v.get().strip()
            if not q:return messagebox.showinfo("Search terms","Enter a topic first.")
            dest=url+quote(q,safe="");self.record(self.case,source,q,"Query opened",dest);browser(dest)
        for src,url in e.CATALOG[n].items():button(line(p),src+"   ↗",lambda s=src,u=url:launch(s,u))
        if n in e.CATALOG_PROVIDERS:self.table(p,"r.source=?",[e.CATALOG_PROVIDERS[n]])

    def table(self,p,where="1",args=()):
        label(p,"Case entries",13,INK,True).pack_configure(pady=(12,4))
        tree=ttk.Treeview(p,columns=("source","status","review","item"),show="headings",height=9,selectmode="browse")
        for col,title,w in [("source","Source",120),("status","Outcome",145),("review","Review decision",155),("item","Record or query",230)]:
            tree.heading(col,text=title);tree.column(col,width=w,minwidth=45)
        tree.pack(fill="both",expand=True)
        tree.bind("<MouseWheel>",lambda ev:(tree.yview_scroll(-int(ev.delta/120) if abs(ev.delta)>=120 else (-1 if ev.delta>0 else 1),"units"),"break")[1])
        rows=self.db.execute(
            "SELECT r.id,r.source,r.status,coalesce(ev.decision,'Unreviewed'),r.query,r.note "
            "FROM records r LEFT JOIN evidence_reviews ev ON ev.record=r.id "
            "WHERE r.c=? AND ("+where+") ORDER BY r.id DESC",
            (self.case,*args),
        )
        for ident,s,status,decision,q,note in rows:tree.insert("",tk.END,iid=str(ident),values=(s,status,decision,note or q))
        def detail(*a):
            if not tree.selection():return
            ident=int(tree.selection()[0]);stamp,s,q,status,url,note=self.db.execute("SELECT time,source,query,status,url,note FROM records WHERE id=?",(ident,)).fetchone()
            rev=storage.get_review(self.db,ident)
            w=tk.Toplevel(self.root);w.title("Evidence record (immutable original + review)");w.configure(bg=BG);w.geometry("700x620")
            box=frame(w);box.pack(fill="both",expand=True,padx=16,pady=14)
            label(box,s+"   /   "+status,14,MINT,True);label(box,"Collected (UTC): "+stamp,9,MUTED);label(box,"Query: "+q);label(box,url,9,MUTED)
            label(box,"Original observation: "+note,9,MUTED)
            label(box,"Attribution / Review Decision (original observation stays immutable)",10,MINT,True).pack_configure(pady=(8,2))
            dec_v=tk.StringVar(value=rev["decision"])
            ttk.Combobox(box,textvariable=dec_v,values=list(storage.REVIEW_DECISIONS),state="readonly",width=48).pack(anchor="w",pady=2)
            dates=frame(box);dates.pack(fill="x",pady=4)
            pub_v=tk.StringVar(value=rev["published_date"]); evt_v=tk.StringVar(value=rev["event_date"])
            tk.Label(dates,text="Published date (YYYY-MM-DD):",bg=BG,fg=INK,font=("Segoe UI",9)).pack(side="left")
            tk.Entry(dates,textvariable=pub_v,bg=PANEL,fg=INK,width=14,relief="flat").pack(side="left",padx=(4,12))
            tk.Label(dates,text="Claimed event date:",bg=BG,fg=INK,font=("Segoe UI",9)).pack(side="left")
            tk.Entry(dates,textvariable=evt_v,bg=PANEL,fg=INK,width=14,relief="flat").pack(side="left",padx=4)
            label(box,"Research notes",10,INK,True);t=tk.Text(box,height=5,wrap="word",bg=PANEL,fg=INK,insertbackground=INK,relief="flat");t.pack(fill="both",expand=True,pady=3)
            annotation=self.db.execute("SELECT body FROM annotations WHERE record=?",(ident,)).fetchone()
            if annotation:t.insert("1.0",annotation[0])
            label(box,"Counterevidence / alternative explanations",10,INK,True);cbox=tk.Text(box,height=4,wrap="word",bg=PANEL,fg=INK,insertbackground=INK,relief="flat");cbox.pack(fill="both",expand=True,pady=3)
            if rev["counterevidence"]:cbox.insert("1.0",rev["counterevidence"])
            def save():
                with self.db:self.db.execute("INSERT OR REPLACE INTO annotations VALUES(?,?)",(ident,t.get("1.0","end-1c")))
                storage.save_review(self.db,ident,dec_v.get(),pub_v.get(),evt_v.get(),cbox.get("1.0","end-1c"))
                w.destroy();self.show(self.view)
            r=line(box);button(r,"Save review & notes",save,True)
            if url:button(r,"Open source",lambda:browser(url))
        tree.bind("<Double-1>",detail);tree.bind("<Return>",detail);button(line(p),"Review selected entry",detail)

    def discovery(self,p):
        label(p,"Search web indexes or look for a literal mention in saved files. Returned records go into the current case.",10,MUTED)
        v=self.var("web.query",self.get("subject") or self.get("user"))
        entry(p,v)
        r=line(p)
        if self.get("email"):
            button(r,"Use complete email",lambda:v.set('"'+self.get("email")+'"'))
        if self.get("user"):button(r,"Use handle",lambda:v.set(self.get("user")))
        def search(provider):
            q=v.get().strip()
            if not q:return messagebox.showinfo("Web discovery","Enter a search phrase first.")
            if provider=="Brave Search" and not self.search_key:
                key=simpledialog.askstring("Brave Search","Enter your Brave Search API key. It stays in memory for this session.",show="*")
                if not key:return
                self.search_key=key.strip()
            key=self.search_key
            self.background(provider,lambda:d.web_results(q,provider,key))
        r=line(p);button(r,"Retrieve DuckDuckGo results",lambda:search("DuckDuckGo"),True)
        button(r,"Retrieve Brave results",lambda:search("Brave Search"))
        def connectivity():
            def check():
                rows=[]
                for name,url in (("GitHub","https://api.github.com/zen"),("Crossref","https://api.crossref.org/works?rows=0"),("DuckDuckGo","https://html.duckduckgo.com/html/?q=library")):
                    try:
                        raw=d.read(url)
                        state="Provider challenge" if "challenge-form" in raw else "Response received"
                        rows.append(("Connectivity",name,state,url,f"{len(raw)} characters returned"))
                    except (OSError,ValueError) as exc:rows.append(("Connectivity",name,d.network_error(exc),url,str(exc)[:240]))
                return rows
            self.background("Connectivity",check)
        button(line(p),"Check provider connections",connectivity)
        label(p,"Search saved material & browser captures",14,MINT,True)
        label(p,"Select saved HTML, text, CSV, or JSON files. Each match records a passage, filename and SHA-256 digest. Browser capture extension files live in source/capture/.",10,MUTED)
        def files():
            q=v.get().strip().strip('"')
            if not q:return messagebox.showinfo("Local search","Enter the literal text you want to find.")
            paths=filedialog.askopenfilenames(filetypes=[("Research files","*.html *.htm *.txt *.csv *.json"),("All files","*.*")])
            if paths:self.background("Saved files",lambda:[d.search_file(path,q) for path in paths])
        r2=line(p)
        button(r2,"Search selected files",files)
        button(r2,"Import browser capture",self.import_capture)
        self.table(p,"(r.source IN ('DuckDuckGo','Brave Search','Saved files','Connectivity') OR r.status='Browser capture')")

    def import_capture(self):
        path=filedialog.askopenfilename(filetypes=[("Field Index browser capture","*.json")])
        if not path:return
        try:
            digest,rows=d.captured_rows(path)
            with self.db:
                inserted=self.db.execute("INSERT OR IGNORE INTO captures VALUES(?,?)",(self.case,digest)).rowcount
                if inserted:self.db.executemany("INSERT INTO records(c,time,source,query,status,url,note) VALUES(?,?,?,?,?,?,?)",[(self.case,now(),*row) for row in rows])
            self.status.set(f"Imported {len(rows)} captured results" if inserted else "This capture is already in this case.")
            self.show(self.view)
        except (OSError,ValueError) as exc:messagebox.showerror("Import capture",str(exc))

    def communities(self,p):
        label(p,"Browse clubs, platforms, events, travel and research sources. Region describes the source's focus. Membership and admission details are published by each provider.",10,MUTED)
        cat=self.var("community.group","All collections")
        pack_sources, pack_info = self.extensions.sources()
        info_by_url = {**d.SOURCE_INFO, **pack_info}
        known = {row[2] for row in d.SOURCES}
        catalog = list(d.SOURCES)
        for item in pack_sources:
            if item[2] not in known:
                catalog.append(item)
                known.add(item[2])
        catalog += [("My publishers",name,url,"User-added publisher. Search its public index or open the site.") for name,url in self.db.execute("SELECT name,url FROM publishers WHERE c=? ORDER BY name",(self.case,))]
        box=ttk.Combobox(p,textvariable=cat,values=["All collections",*dict.fromkeys(x[0] for x in catalog)],state="readonly")
        box.pack(anchor="w",pady=6);box.bind("<<ComboboxSelected>>",lambda ev:self.show("Community sources"))
        region=self.var("community.region","All regions")
        regions=ttk.Combobox(p,textvariable=region,values=["All regions",*sorted({info_by_url.get(s[2],{}).get("country","User added") for s in catalog})],state="readonly")
        regions.pack(anchor="w",pady=4);regions.bind("<<ComboboxSelected>>",lambda ev:self.show("Community sources"))
        words=self.var("community.filter")
        label(p,"Filter by name, place, locality, category or description")
        search=entry(p,words);search.bind("<Return>",lambda ev:self.show("Community sources"))
        r=line(p);button(r,"Apply filters",lambda:self.show("Community sources"))
        def clear():
            cat.set("All collections");region.set("All regions");words.set("");self.show("Community sources")
        button(r,"Clear filters",clear)
        sources=d.filter_sources(catalog,cat.get(),region.get(),words.get(),info_by_url)
        label(p,f"{len(sources)} of {len(catalog)} entries displayed",11,MINT)
        def export_directory():
            path=filedialog.asksaveasfilename(defaultextension=".csv",filetypes=[("Directory CSV","*.csv")])
            if not path:return
            try:
                buf=io.StringIO()
                writer=csv.writer(buf);writer.writerow(["Name","Category","Region","Locality","Type","URL","Login","Age Gate","Description","Source reviewed","Caveats"])
                for category,name,url,desc in sources:
                    info=info_by_url.get(url,{})
                    row=[name,category,info.get("country","User added"),info.get("locality",""),info.get("kind","Reference"),url,info.get("login_required",""),info.get("age_gate",""),desc,info.get("reviewed",""),info.get("caveats","")]
                    writer.writerow(["'"+x if x.lstrip().startswith(("=","+","-","@")) else x for x in row])
                storage.atomic_write_text(path, buf.getvalue(), encoding="utf-8-sig")
                self.status.set(f"Exported {len(sources)} directory entries")
            except OSError as exc:messagebox.showerror("Export directory",str(exc))
        button(r,"Export filtered directory",export_directory)
        if not sources:
            label(p,"No entries match these filters. Clear filters to browse the full catalogue.");return
        table_box=frame(p);table_box.pack(fill="x")
        tree=ttk.Treeview(table_box,columns=("name","category","country","kind"),show="headings",height=min(12,len(sources)))
        for key,title,width in [("name","Name",240),("category","Collection",175),("country","Region",140),("kind","Type",95)]:
            tree.heading(key,text=title);tree.column(key,width=width,minwidth=65)
        tree.pack(side="left",fill="both",expand=True)
        scroll=ttk.Scrollbar(table_box,orient="vertical",command=tree.yview);scroll.pack(side="right",fill="y")
        tree.configure(yscrollcommand=scroll.set)
        tree.bind("<MouseWheel>",lambda ev:(tree.yview_scroll(-int(ev.delta/120) if abs(ev.delta)>=120 else (-1 if ev.delta>0 else 1),"units"),"break")[1])
        for i,(category,name,url,description) in enumerate(sources):
            info=info_by_url.get(url,{})
            tree.insert("","end",iid=str(i),values=(name,category,info.get("country","User added"),info.get("kind","Reference")))
        tree.selection_set("0")
        summary=tk.StringVar()
        def current():return sources[int(tree.selection()[0])] if tree.selection() else sources[0]
        def detail(*args):
            item=current();info=info_by_url.get(item[2],{})
            extra=[]
            if info.get("locality"):extra.append("Locality: "+info["locality"])
            if info.get("age_gate") and info["age_gate"]!="none":extra.append("Age gate: "+info["age_gate"])
            if info.get("login_required") and info["login_required"]!="none":extra.append("Login: "+info["login_required"])
            text=item[3]+"\n"+item[2]+"\nSource review "+info.get("reviewed","pending")+" | "+info.get("status","User-added entry")
            if extra:text+="\n"+" | ".join(extra)
            if info.get("caveats"):text+="\nCaveat: "+info["caveats"]
            summary.set(text)
        tree.bind("<<TreeviewSelect>>",detail);detail()
        tk.Label(p,textvariable=summary,bg=BG,fg=MUTED,wraplength=670,justify="left").pack(anchor="w",pady=6)
        term=self.var("community.topic")
        label(p,"Topic or phrase (optional for reading a page)")
        entry(p,term)
        def read_page():
            s=current();q=term.get().strip()
            if s[0]=="My publishers":
                browser(s[2]);return
            self.background(s[1],lambda:[d.read_catalogue(s,q)])
        def search_collection():
            q=term.get().strip()
            if not q:return messagebox.showinfo("Collection search","Enter a topic, event, organization or publication title.")
            domains=list(dict.fromkeys(urlsplit(s[2]).hostname for s in sources if urlsplit(s[2]).hostname))
            if len(domains) > 15:
                if not messagebox.askyesno("Confirm large collection search",f"This will queue {len(domains)} DuckDuckGo queries and may trigger rate limits. Narrow the collection filter first, or proceed?",parent=self.root):
                    return
            self.start_plan([("DuckDuckGo",q+" site:"+host,"Web results",True) for host in domains])
            self.show("Investigation plan")
        def find_in_pages():
            q=term.get().strip()
            if not q:return messagebox.showinfo("Read collection","Enter the literal wording to look for in these public pages.")
            builtins=[s for s in sources if s[0] != "My publishers"]
            if not builtins:return messagebox.showinfo("Read collection","Use Search collection for user-added domains.")
            cancel=threading.Event()
            def work():
                rows=[]
                with ThreadPoolExecutor(max_workers=2) as pool:
                    for item in builtins:
                        if cancel.is_set():
                            rows.append((item[1],q,"Cancelled",item[2],""))
                        else:
                            rows.append(pool.submit(d.read_catalogue,item,q).result())
                return rows
            self.background("Read public pages",work,cancel=cancel)
        def save():
            cat_name,name,url,desc=current()
            info=info_by_url.get(url,{})
            self.record(self.case,name,"","Catalogue reference",url,desc+" | Source review "+info.get("reviewed","pending"));self.show("Community sources")
        r=line(p);button(r,"Read selected page",read_page,True);button(r,"Search collection",search_collection)
        button(r,"Find text across pages",find_in_pages)
        r=line(p);button(r,"Open publisher",lambda:browser(current()[2]));button(r,"Save reference",save)
        def add_publisher():
            url=simpledialog.askstring("Add a publisher","Public website URL, including https://")
            if not url:return
            try:
                url=d.canonical(url.strip());host=urlsplit(url).hostname
                if not url or not host:raise ValueError("Enter a public website URL.")
                e.domain(host)
            except ValueError as exc:return messagebox.showinfo("Publisher",str(exc))
            name=simpledialog.askstring("Add a publisher","Publisher name",initialvalue=host)
            if not name or not name.strip():return
            with self.db:self.db.execute("INSERT OR REPLACE INTO publishers VALUES(?,?,?)",(self.case,name.strip(),url))
            cat.set("My publishers");region.set("All regions");words.set("");self.show("Community sources")
        button(r,"Add publisher",add_publisher)
        button(r,"Manage extension packs",lambda:self.show("Extensions"))
        self.table(p,"r.source IN ("+",".join("?" for _ in catalog)+")",[s[1] for s in catalog])

    def extensions_page(self,p):
        label(p,"Optional modules are data-only packs. They cannot run scripts, fetch private account data or bypass sign-in requirements.",10,MUTED)
        label(p,"Installed research modules",15,MINT,True).pack_configure(pady=(14,6))
        modules=self.extensions.installed()
        if not modules:
            label(p,"No extensions installed. Your built-in workspaces and Community Sources are still available.",10,MUTED)
        for obj,enabled,error in modules:
            card=frame(p,PANEL);card.pack(fill="x",pady=4,ipadx=12,ipady=8)
            filters=self.extensions.get_filters(obj["id"]) if not error else {"disabled_categories":[],"disabled_regions":[]}
            filter_note=""
            if filters["disabled_categories"] or filters["disabled_regions"]:
                filter_note=f"  (filtered: -{len(filters['disabled_categories'])} cats, -{len(filters['disabled_regions'])} regions)"
            label(card,obj["name"]+"   v"+obj["version"]+("  [enabled]" if enabled else "  [disabled]")+filter_note,12,MINT,True)
            label(card,error or obj.get("description", ""),10,MUTED)
            buttons=line(card)
            ident=obj["id"]
            def toggle(x=ident,active=enabled):
                try:
                    self.extensions.enable(x,not active)
                    self.show("Extensions")
                except (OSError,PackError) as exc:messagebox.showerror("Module",str(exc))
            button(buttons,"Disable" if enabled else "Enable",toggle)
            def uninstall(x=ident,caption=obj["name"]):
                if not messagebox.askyesno("Remove module", "Remove " + caption + "? Cases and evidence remain untouched."):return
                try:self.extensions.remove(x);self.show("Extensions")
                except (OSError,PackError) as exc:messagebox.showerror("Module",str(exc))
            button(buttons,"Remove",uninstall)
            if not error:
                def edit_filters(pack_obj=obj):
                    win=tk.Toplevel(self.root);win.title("Filter regions & categories: "+pack_obj["name"]);win.geometry("620x500");win.configure(bg=BG)
                    box=frame(win);box.pack(fill="both",expand=True,padx=16,pady=14)
                    cur=self.extensions.get_filters(pack_obj["id"])
                    cats=sorted({s["category"] for s in pack_obj.get("sources",[])})
                    regs=sorted({s["region"] for s in pack_obj.get("sources",[])})
                    label(box,"Uncheck categories or regions to hide them without rebuilding the pack:",10,MINT,True)
                    cat_vars={}; reg_vars={}
                    label(box,"Categories",10,INK,True).pack_configure(pady=(8,2))
                    for c_name in cats:
                        v=tk.BooleanVar(value=c_name not in cur["disabled_categories"]);cat_vars[c_name]=v
                        tk.Checkbutton(box,text=c_name,variable=v,bg=BG,fg=INK,selectcolor=PANEL,activebackground=BG).pack(anchor="w")
                    label(box,"Regions",10,INK,True).pack_configure(pady=(8,2))
                    for r_name in regs:
                        v=tk.BooleanVar(value=r_name not in cur["disabled_regions"]);reg_vars[r_name]=v
                        tk.Checkbutton(box,text=r_name,variable=v,bg=BG,fg=INK,selectcolor=PANEL,activebackground=BG).pack(anchor="w")
                    def apply_f():
                        off_c=[k for k,v in cat_vars.items() if not v.get()]
                        off_r=[k for k,v in reg_vars.items() if not v.get()]
                        self.extensions.set_filters(pack_obj["id"],off_c,off_r)
                        win.destroy();self.show("Extensions")
                    button(line(box),"Save filters",apply_f,True)
                button(buttons,"Filter regions/categories",edit_filters)
                def export_module(x=ident):
                    file=filedialog.asksaveasfilename(title="Export research module",defaultextension=".fipack",initialfile=x+".fipack",filetypes=[("Field Index module","*.fipack")])
                    if not file:return
                    try:self.extensions.export(x,file);self.status.set("Exported "+x)
                    except (OSError,ValueError) as exc:messagebox.showerror("Export module",str(exc))
                button(buttons,"Export pack",export_module)
        def install_file(path=None):
            path = path or filedialog.askopenfilename(title="Install Field Index research pack",filetypes=[("Field Index module", "*.fipack *.zip")])
            if not path:return
            try:
                obj=self.extensions.install(path)
                self.status.set("Installed module: " + obj["name"])
                self.show("Extensions")
            except (OSError,ValueError,zipfile.BadZipFile) as exc:
                messagebox.showerror("Module installation failed",str(exc))
        act_row=line(p)
        button(act_row,"Install module from file",install_file,True)
        def csv_import():
            filename=filedialog.askopenfilename(title="Import a public website directory",filetypes=[("Comma-separated directory", "*.csv")])
            if not filename:return
            name=simpledialog.askstring("CSV source pack", "Name for the new research module", parent=self.root)
            if not name:return
            try:
                item=self.extensions.import_csv(filename,name)
                self.status.set(f"Imported {len(item['sources'])} sources to module {item['name']}")
                self.show("Extensions")
            except (OSError,ValueError,csv.Error) as exc:messagebox.showerror("CSV import",str(exc))
        def json_import():
            filename=filedialog.askopenfilename(title="Import a reviewed JSON directory",filetypes=[("JSON source directory", "*.json")])
            if not filename:return
            name=simpledialog.askstring("JSON source pack", "Optional override name (leave blank to use file name)", parent=self.root)
            try:
                item=self.extensions.import_json(filename,name or None)
                self.status.set(f"Imported {len(item['sources'])} sources to module {item['name']}")
                self.show("Extensions")
            except (OSError,ValueError) as exc:messagebox.showerror("JSON import",str(exc))
        button(act_row,"Import website list from CSV",csv_import)
        button(act_row,"Import JSON directory",json_import)
        def save_template():
            path=filedialog.asksaveasfilename(title="Save module CSV template",defaultextension=".csv",filetypes=[("CSV", "*.csv")])
            if not path:return
            try:
                buf=io.StringIO();out=csv.writer(buf)
                out.writerow(["name","url","category","region","locality","type","search_method","login_required","age_gate","visibility","last_reviewed","description","caveats"])
                out.writerow(["Example Archive","https://www.loc.gov/","Historical archives","United States - National","Washington, DC","Archive","site_dork","none","none","public_open","2026-11-21","Public catalogue entry","Public records only."])
                storage.atomic_write_text(path, buf.getvalue(), encoding="utf-8-sig")
                self.status.set("Saved CSV module template")
            except OSError as exc:messagebox.showerror("CSV template",str(exc))
        button(line(p),"Save CSV template",save_template)
        pack_dir = (Path(getattr(sys,"_MEIPASS",Path(sys.executable).resolve().parent)) if getattr(sys,"frozen",False) else Path(__file__).resolve().parent.parent) / "ExtensionPacks"
        if not pack_dir.is_dir() and getattr(sys,"frozen",False):
            pack_dir = Path(sys.executable).resolve().parent / "ExtensionPacks"
        if pack_dir.is_dir():
            label(p,"Included optional packs",13,MINT,True).pack_configure(pady=(14,4))
            for path in sorted(pack_dir.glob("*.fipack")):
                try:
                    item,_ = pack_bytes(path)
                except (OSError,ValueError,zipfile.BadZipFile):continue
                if any(row[0]["id"]==item["id"] for row in modules):continue
                row=line(p)
                button(row,"Install: "+item["name"],lambda q=str(path):install_file(q))
        label(p,"Reusable research recipes",14,MINT,True).pack_configure(pady=(18,5))
        recipes=self.extensions.recipes()
        if not recipes:
            label(p,"Install a pack with search recipes to see them here.",10,MUTED)
            return
        choices={f"{group}  /  {title}":(template,desc) for group,title,template,desc in recipes}
        current=tk.StringVar(value=next(iter(choices)))
        picker=ttk.Combobox(p,textvariable=current,values=list(choices),state="readonly",width=70)
        picker.pack(anchor="w",pady=4)
        notes=tk.StringVar()
        def change(*unused):notes.set(choices[current.get()][1])
        picker.bind("<<ComboboxSelected>>",change);change()
        tk.Label(p,textvariable=notes,fg=MUTED,bg=BG,justify="left",wraplength=650).pack(anchor="w")
        topic=self.var("extension.topic")
        place=self.var("extension.region")
        label(p,"Public research topic, venue, publication or event (required)")
        entry(p,topic)
        label(p,"Place or region (optional)")
        entry(p,place)
        def preview():
            try:q=make_query(choices[current.get()][0],topic.get(),place.get())
            except ValueError as exc:return messagebox.showinfo("Research recipe",str(exc))
            popup=tk.Toplevel(self.root);popup.title("Review module query");popup.geometry("785x365");popup.configure(bg=BG)
            wrapper=frame(popup);wrapper.pack(fill="both",expand=True,padx=20,pady=15)
            label(wrapper,"Review the exact words before sending them to a search provider",11,MINT,True)
            text=tk.Text(wrapper,height=4,wrap="word",bg=PANEL,fg=INK,font=("Consolas",10));text.pack(fill="both",expand=True,pady=7)
            text.insert("1.0",q);text.configure(state="disabled")
            def open_search(engine):
                self.record(self.case,"Module recipe / "+engine,q,"Query opened",e.ENGINES[engine]+quote(q,safe=""),current.get())
                browser(e.ENGINES[engine]+quote(q,safe=""))
            actions=line(wrapper)
            for n in ("Google","Bing","DuckDuckGo","Yahoo"):
                button(actions,"Open "+n,lambda engine=n:open_search(engine),n=="Google")
            other=line(wrapper)
            for n in ("Ecosia","Yandex","Baidu"):
                button(other,"Open "+n,lambda engine=n:open_search(engine))
            def retrieve():
                self.start_plan([("DuckDuckGo",q,"Web results",True)])
                popup.destroy()
                self.show("Investigation plan")
            last=line(wrapper)
            button(last,"Retrieve DuckDuckGo results",retrieve,True)
            button(last,"Save query",lambda:(self.record(self.case,"Module recipe",q,"Prepared browser search","",current.get()),self.status.set("Module query saved to evidence")))
        button(line(p),"Preview and open search",preview,True)

    def hypotheses_window(self):
        win=tk.Toplevel(self.root);win.title("Case Hypothesis Board & Counterevidence");win.geometry("760x560");win.configure(bg=BG)
        box=frame(win);box.pack(fill="both",expand=True,padx=16,pady=14)
        label(box,"Track competing explanations separately from raw observations. Never substantiate a claim without reviewed primary evidence.",9,MUTED)
        tree=ttk.Treeview(box,columns=("status","claim"),show="headings",height=7)
        tree.heading("status",text="Status");tree.column("status",width=220)
        tree.heading("claim",text="Claim / Hypothesis");tree.column("claim",width=460)
        tree.pack(fill="x",pady=6)
        def load():
            for row_id in tree.get_children():tree.delete(row_id)
            for hid,claim,status in self.db.execute("SELECT id,claim,status FROM case_hypotheses WHERE c=? ORDER BY id DESC",(self.case,)):
                tree.insert("","end",iid=str(hid),values=(status,claim))
        load()
        claim_v=tk.StringVar(); status_v=tk.StringVar(value=storage.HYPOTHESIS_STATUSES[0])
        label(box,"Claim / hypothesis");entry(box,claim_v)
        ttk.Combobox(box,textvariable=status_v,values=list(storage.HYPOTHESIS_STATUSES),state="readonly",width=45).pack(anchor="w",pady=3)
        label(box,"Supporting observations",9,INK,True);sup_t=tk.Text(box,height=3,wrap="word",bg=PANEL,fg=INK,relief="flat");sup_t.pack(fill="x",pady=2)
        label(box,"Contradicting / alternative explanations",9,INK,True);con_t=tk.Text(box,height=3,wrap="word",bg=PANEL,fg=INK,relief="flat");con_t.pack(fill="x",pady=2)
        label(box,"Missing evidence required",9,INK,True);mis_t=tk.Text(box,height=2,wrap="word",bg=PANEL,fg=INK,relief="flat");mis_t.pack(fill="x",pady=2)
        def add_hyp():
            if not claim_v.get().strip():return messagebox.showinfo("Hypothesis","Enter a claim first.",parent=win)
            with self.db:
                self.db.execute(
                    "INSERT INTO case_hypotheses(c,claim,status,supporting,contradicting,missing_evidence,updated_utc) VALUES(?,?,?,?,?,?,?)",
                    (self.case,claim_v.get().strip(),status_v.get(),sup_t.get("1.0","end-1c").strip(),con_t.get("1.0","end-1c").strip(),mis_t.get("1.0","end-1c").strip(),now()),
                )
            claim_v.set("");sup_t.delete("1.0","end");con_t.delete("1.0","end");mis_t.delete("1.0","end");load()
        button(line(box),"Save hypothesis",add_hyp,True)

    def evidence(self,p):
        r=line(p)
        def manual():
            url=simpledialog.askstring("Add evidence","Public source URL",parent=self.root)
            if not url:return
            if urlsplit(url).scheme not in ("https","http") or not urlsplit(url).hostname:return messagebox.showinfo("URL","Enter a full http or https URL.")
            note=simpledialog.askstring("Add evidence","What does this source establish?",parent=self.root)
            if note is None:return
            self.record(self.case,"Researcher","","Manual observation",url,note);self.show("Evidence")
        def export_report():
            path=filedialog.asksaveasfilename(defaultextension=".md",filetypes=[("Markdown report","*.md")])
            if not path:return
            try:
                md=storage.generate_report_markdown(self.db,self.case)
                storage.atomic_write_text(path, md, encoding="utf-8")
                self.status.set("Exported defensible Markdown investigation report")
            except OSError as exc:messagebox.showerror("Export report",str(exc))
        button(r,"Add observation",manual,True);button(r,"Export JSON",lambda:self.export("json"));button(r,"Export CSV",lambda:self.export("csv"));button(r,"Export Markdown report",export_report)
        def backup():
            path=filedialog.asksaveasfilename(defaultextension=".sqlite3",filetypes=[("Complete case database","*.sqlite3")])
            if not path:return
            live=self.db.execute("PRAGMA database_list").fetchone()[2]
            if Path(path).resolve()==Path(live).resolve():return messagebox.showinfo("Backup","Choose a new backup filename.")
            try:
                storage.atomic_backup(self.db, path)
                self.status.set("All cases backed up and integrity-verified")
            except (sqlite3.Error, OSError) as exc:messagebox.showerror("Backup",str(exc))
        r2=line(p);button(r2,"Back up all cases",backup)
        button(r2,"Group findings by URL",self.grouped)
        button(r2,"Case hypotheses",self.hypotheses_window)
        button(r2,"Import case JSON",self.import_case)
        search=self.var("ledger.filter")
        label(p,"Filter records by source, query, outcome, URL or excerpt");entry(p,search)
        rows=frame(p);rows.pack(fill="x")
        def refresh():
            for child in rows.winfo_children():child.destroy()
            needle=search.get().strip().lower()
            self.table(rows,"instr(lower(r.source||' '||r.query||' '||r.status||' '||r.url||' '||r.note),?)>0",[needle])
        button(r2,"Apply filter",refresh);refresh()

    def grouped(self):
        window=tk.Toplevel(self.root);window.title("Findings grouped by URL (with source-overlap check)");window.geometry("940x560")
        tree=ttk.Treeview(window,columns=("status","source","overlap"),show="tree headings")
        for key,title,size in [("#0","Page / recorded query",420),("status","Observation",160),("source","Source(s)",170),("overlap","Independence",160)]:
            tree.heading(key,text=title);tree.column(key,width=size)
        tree.pack(fill="both",expand=True)
        records=self.db.execute("SELECT time,source,query,status,url,note FROM records WHERE c=? ORDER BY id DESC",(self.case,))
        findings=d.grouped_records(records);urls={}
        for finding in findings:
            overlap_label="Overlapping tools (1 page)" if finding.get("overlapping_tools") else "Single source"
            parent=tree.insert("","end",text=finding["canonical_url"],values=(str(len(finding["observations"]))+" observations",", ".join(finding["sources"]),overlap_label))
            urls[parent]=finding["canonical_url"]
            for item in finding["observations"]:
                child=tree.insert(parent,"end",text=item["utc"]+"  "+item["query"],values=(item["outcome"],item["source"],""))
                urls[child]=item["url"]
        def open_selected(*args):
            if tree.selection():browser(urls[tree.selection()[0]])
        tree.bind("<Double-1>",open_selected)
        ttk.Label(window,text=f"{len(findings)} distinct URLs. Multiple tools hitting the same URL count as ONE public page observation, not independent identity proofs.").pack(anchor="w")
        case_name=self.casebox.get()
        def export_findings():
            path=filedialog.asksaveasfilename(defaultextension=".json",filetypes=[("Grouped findings","*.json")],parent=window)
            if not path:return
            try:
                storage.atomic_write_text(path, json.dumps({"case":case_name,"findings":findings},ensure_ascii=False,indent=2))
            except OSError as exc:messagebox.showerror("Export findings",str(exc),parent=window)
        ttk.Button(window,text="Export grouped findings",command=export_findings).pack(anchor="w")

    def export(self,ext):
        path=filedialog.asksaveasfilename(defaultextension="."+ext,filetypes=[(ext.upper(),"*."+ext)])
        if not path:return
        keys=["utc","source","query","outcome","url","original_record","research_notes","review_decision","published_date","event_date","counterevidence"]
        rows=[
            dict(zip(keys,row))
            for row in self.db.execute(
                "SELECT r.time,r.source,r.query,r.status,r.url,r.note,coalesce(a.body,''),"
                "coalesce(ev.decision,'Unreviewed'),coalesce(ev.published_date,''),coalesce(ev.event_date,''),coalesce(ev.counterevidence,'') "
                "FROM records r LEFT JOIN annotations a ON a.record=r.id LEFT JOIN evidence_reviews ev ON ev.record=r.id "
                "WHERE r.c=? ORDER BY r.id",
                (self.case,),
            )
        ]
        try:
            if ext=="json":
                payload={
                    "format":"fieldindex.case.v3",
                    "case":self.casebox.get(),
                    "settings":dict(self.db.execute("SELECT k,v FROM fields WHERE c=?",(self.case,))),
                    "entries":rows,
                    "publishers":list(self.db.execute("SELECT name,url FROM publishers WHERE c=?",(self.case,))),
                    "recipes":list(self.db.execute("SELECT name,settings FROM recipes WHERE c=?",(self.case,))),
                    "dork_recipes":list(self.db.execute("SELECT name,settings,created FROM dork_recipes WHERE c=?",(self.case,))),
                    "hypotheses":list(self.db.execute("SELECT claim,status,supporting,contradicting,missing_evidence,updated_utc FROM case_hypotheses WHERE c=?",(self.case,))),
                }
                storage.atomic_write_text(path, json.dumps(payload,ensure_ascii=False,indent=2), encoding="utf-8")
            else:
                buf=io.StringIO()
                writer=csv.DictWriter(buf,fieldnames=keys);writer.writeheader()
                for row in rows:writer.writerow({k:("'"+v if v.lstrip().startswith(("=","+","-","@")) else v) for k,v in row.items()})
                storage.atomic_write_text(path, buf.getvalue(), encoding="utf-8-sig")
        except OSError as ex:return messagebox.showerror("Export",str(ex))
        self.status.set(f"Exported {len(rows)} entries")

    def import_case(self):
        path=filedialog.askopenfilename(filetypes=[("Field Index case","*.json")])
        if not path:return
        try:
            with open(path,"rb") as stream:raw=stream.read(32_000_001)
            if len(raw)>32_000_000:raise ValueError("Case exceeds 32 MB. Use a database backup.")
            data=json.loads(raw)
            if not isinstance(data,dict) or not isinstance(data.get("case"),str) or not isinstance(data.get("entries"),list):raise ValueError("Select an exported Field Index case.")
            fields=data.get("settings",{})
            if not isinstance(fields,dict) or any(not isinstance(v,str) for v in fields.values()):raise ValueError("Invalid settings")
            if fields.get("mode","Basic") not in e.MODES:raise ValueError("Unknown query mode")
            case_name=simpledialog.askstring("Import case","Name of the new case",initialvalue=data["case"]+" (imported)")
            if not case_name or not case_name.strip():return
            case_name=case_name.strip()
            with self.db:
                new=self.db.execute("INSERT INTO cases(name) VALUES(?)",(case_name,)).lastrowid
                self.db.executemany("INSERT INTO fields VALUES(?,?,?)",[(new,k,v) for k,v in fields.items()])
                for item in data["entries"]:
                    values=[item[k] for k in ("utc","source","query","outcome","url","original_record")]
                    if not all(isinstance(x,str) for x in values):raise ValueError("Invalid case entry")
                    if not isinstance(item.get("research_notes",""),str):raise ValueError("Research notes must be text.")
                    ident=self.db.execute("INSERT INTO records(c,time,source,query,status,url,note) VALUES(?,?,?,?,?,?,?)",(new,*values)).lastrowid
                    self.db.execute("INSERT INTO annotations VALUES(?,?)",(ident,item.get("research_notes","")))
                    if any(item.get(k) for k in ("review_decision","published_date","event_date","counterevidence")):
                        dec=item.get("review_decision") or "Unreviewed"
                        if dec not in storage.REVIEW_DECISIONS:dec="Unreviewed"
                        self.db.execute(
                            "INSERT INTO evidence_reviews(record,decision,published_date,event_date,counterevidence,reviewed_utc) VALUES(?,?,?,?,?,?)",
                            (ident,dec,str(item.get("published_date",""))[:40],str(item.get("event_date",""))[:40],str(item.get("counterevidence",""))[:2000],now()),
                        )
                for publisher,url in data.get("publishers",[]):
                    if not d.canonical(url):raise ValueError("Invalid publisher")
                    self.db.execute("INSERT INTO publishers VALUES(?,?,?)",(new,publisher,url))
                for recipe,settings in data.get("recipes",[]):
                    parsed=json.loads(settings)
                    if not isinstance(parsed,dict) or parsed.get("mode") not in e.MODES or not all(isinstance(v,str) for v in parsed.values()):raise ValueError("Invalid recipe")
                    self.db.execute("INSERT INTO recipes VALUES(?,?,?)",(new,recipe,settings))
                for rec_name,settings,created in data.get("dork_recipes",[]):
                    parsed=json.loads(settings)
                    if not isinstance(rec_name,str) or not 0<len(rec_name)<=100 or not isinstance(created,str) or len(created)>50:
                        raise ValueError("Invalid saved dork recipe")
                    if not isinstance(parsed,dict) or parsed.get("engine") not in ds.ENGINE_URLS or parsed.get("advanced") not in ("0","1") or not isinstance(parsed.get("pack"),str):
                        raise ValueError("Invalid saved dork recipe settings")
                    values=parsed.get("fields")
                    if not isinstance(values,dict) or any(not isinstance(key,str) or not isinstance(value,str) or len(value)>500 for key,value in values.items()):
                        raise ValueError("Invalid saved dork query fields")
                    self.db.execute("INSERT INTO dork_recipes(c,name,settings,created) VALUES(?,?,?,?)",(new,rec_name,settings,created))
                for hyp in data.get("hypotheses",[]):
                    if isinstance(hyp,(list,tuple)) and len(hyp)==6 and all(isinstance(x,str) for x in hyp):
                        self.db.execute(
                            "INSERT INTO case_hypotheses(c,claim,status,supporting,contradicting,missing_evidence,updated_utc) VALUES(?,?,?,?,?,?,?)",
                            (new,*hyp),
                        )
            self.case=new;self.values={};self.refresh_cases();self.show("Evidence")
            self.status.set("Imported case into "+case_name)
        except (sqlite3.Error,OSError,KeyError,TypeError,ValueError,AttributeError) as exc:messagebox.showerror("Import case",str(exc))

def _installer_smoke_test(result_file):
    """Offline GUI/package smoke check; only writes to disposable test storage."""
    from tempfile import TemporaryDirectory
    from traceback import format_exc
    output = Path(result_file)
    try:
        with TemporaryDirectory(prefix="fieldindex_package_check_") as directory:
            root = tk.Tk()
            root.withdraw()
            app = Workspace(root, directory)
            root.update_idletasks()
            assert app.db.execute("PRAGMA quick_check").fetchone()[0] == "ok"
            assert "Extensions" in NAV and "Google dorking" in NAV
            app.close()
        output.write_text("OK: GUI, SQLite, and modules loaded\n", encoding="utf-8")
        return 0
    except Exception:
        output.write_text("FAILED:\n" + format_exc(), encoding="utf-8")
        return 1

if __name__=="__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--installer-smoke-test":
        sys.exit(_installer_smoke_test(sys.argv[2]))
    root=tk.Tk();app=Workspace(root);root.mainloop()
