"""Helpers for optional Holehe web research portal access.

The website and original Holehe CLI are separate projects. Field Index does
not submit lookup values to a third-party service automatically and does not
claim to have a Holehe API integration.
"""
from __future__ import annotations

import ipaddress
import re

WEB_PORTAL = "https://holehe.org/"
ORIGINAL_CLI = "https://github.com/megadose/holehe"
PYPI_PAGE = "https://pypi.org/project/holehe/"
LOOKUP_TYPES = ("Username", "Email", "Phone", "IP address")


def validate_lookup(kind: str, value: str) -> str:
    """Validate a manually chosen lookup. Never send it to a provider."""
    if kind not in LOOKUP_TYPES:
        raise ValueError("Choose a valid lookup type")
    if not isinstance(value, str):
        raise ValueError("Enter a search value")
    value = value.strip()
    if not value or len(value) > 254 or any(ord(ch) < 32 for ch in value):
        raise ValueError("Enter one valid search value")
    if kind == "Email":
        if not re.fullmatch(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]{1,64}@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+", value):
            raise ValueError("Enter a valid email address")
        return value
    if kind == "Username":
        if value.startswith('@'):
            value = value[1:]
        if not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}", value):
            raise ValueError("Enter a username with letters, digits, dots, underscores or hyphens")
        return value
    if kind == "Phone":
        digits = re.sub(r"[^0-9]", "", value)
        if not re.fullmatch(r"\+?[\d() .-]+", value) or not 7 <= len(digits) <= 15:
            raise ValueError("Enter a telephone number including the country code when possible")
        return value
    try:
        return str(ipaddress.ip_address(value))
    except ValueError as exc:
        raise ValueError("Enter a valid IPv4 or IPv6 address") from exc
