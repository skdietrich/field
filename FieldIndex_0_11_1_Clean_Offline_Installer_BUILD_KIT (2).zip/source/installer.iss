[Setup]
AppId=FieldIndexResearchWorkbench
AppName=Field Index
AppVersion=0.11.0
VersionInfoVersion=0.11.0.0
DefaultDirName={localappdata}\Programs\FieldIndex
DefaultGroupName=Field Index
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=outputs
OutputBaseFilename=FieldIndex_Setup_0_11_x64
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\FieldIndex011.exe

[Files]
Source: "..\compiled\FieldIndex011.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "Read_Me.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "capture\*"; DestDir: "{app}\capture"; Flags: ignoreversion recursesubdirs
Source: "..\ExtensionPacks\*.fipack"; DestDir: "{app}\ExtensionPacks"; Flags: ignoreversion
Source: "..\INSTALL_SHERLOCK_FOR_FIELDINDEX.cmd"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\INSTALL_SHERLOCK_FOR_FIELDINDEX.ps1"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\SHERLOCK_QUICK_START.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\INSTALL_MAIGRET_FOR_FIELDINDEX.cmd"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\INSTALL_MAIGRET_FOR_FIELDINDEX.ps1"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\MAIGRET_QUICK_START.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\MIGRATION_AND_ROLLBACK.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\RELEASE_NOTES_0_11.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\MANUAL.md"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Field Index"; Filename: "{app}\FieldIndex011.exe"
Name: "{group}\Field Index guide"; Filename: "{app}\Read_Me.txt"

[Run]
Filename: "{app}\FieldIndex011.exe"; Description: "Open Field Index"; Flags: nowait postinstall skipifsilent
