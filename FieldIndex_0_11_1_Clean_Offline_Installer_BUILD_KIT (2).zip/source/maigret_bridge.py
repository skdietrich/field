"""FieldIndex full Maigret CLI adapter (no artificial 3-site cap).

Supports Windows standalone executables and isolated Python venv installations,
capability probing, structured JSON report parsing (simple and ndjson) with
graceful text fallback, explicit blocked/rate-limited/timeout/not-found
classification, cancellation, and clearly labeled legacy 3-site compatibility.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import sys
import tempfile
from pathlib import Path
from urllib.parse import urlsplit

from process_runner import run_command, ToolCancelled

LEGACY_THREE_SITES = ("GitHub", "Reddit", "GitLab")
DEFAULT_TOP_SITES = 500
VALID_TAG_RE = re.compile(r"[A-Za-z0-9_-]{1,32}")
VALID_SITE_RE = re.compile(r"[A-Za-z0-9][\w .&+\-]{0,79}")


def validate_username(value: str) -> str:
    if not isinstance(value, str):
        raise ValueError("Enter a public username.")
    name = value.strip().removeprefix("@")
    if not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}", name):
        raise ValueError(
            "Enter one public username, 1-64 letters, digits, dots, underscores or hyphens. Do not enter an email address."
        )
    return name


def find_executable(base=None, which=None) -> str | None:
    """Locate FieldIndex-managed Maigret venv, standalone Windows binary, or PATH executable."""
    which = which or shutil.which
    home = Path(base or (Path(os.getenv("LOCALAPPDATA") or Path.home()) / "FieldIndex"))
    candidates = [
        home / "tools" / "maigret" / ".venv" / "Scripts" / "maigret.exe",
        home / "tools" / "maigret" / ".venv" / "bin" / "maigret",
        home / "tools" / "maigret" / "maigret_standalone.exe",
        home / "tools" / "maigret" / "maigret.exe",
        Path(sys.executable).parent / "Scripts" / "maigret.exe",
        Path(sys.executable).parent / "maigret.exe",
    ]
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)
    return which("maigret") or which("maigret_standalone")


def probe_capabilities(executable=None, runner=run_command) -> dict:
    """Inspect installed Maigret version and supported CLI flags without guessing."""
    exe = executable or find_executable()
    if not exe:
        return {
            "installed": False,
            "executable": "",
            "version": "",
            "flags": {},
            "error": "Maigret executable not found.",
        }
    version = ""
    flags = {
        "json": False,
        "tags": False,
        "site": False,
        "top_sites": False,
        "all_sites": False,
        "folderoutput": False,
        "no_recursion": False,
        "timeout": False,
        "txt": False,
        "no_color": False,
    }
    try:
        v_code, v_out = runner([str(exe), "--version"], timeout=10)
        if v_code == 0:
            version = v_out.strip().splitlines()[-1][:120] if v_out.strip() else "unknown"
        h_code, h_out = runner([str(exe), "--help"], timeout=10)
        help_text = h_out if h_code == 0 else ""
        flags["json"] = "--json" in help_text
        flags["tags"] = "--tags" in help_text
        flags["site"] = "--site" in help_text
        flags["top_sites"] = "--top-sites" in help_text
        flags["all_sites"] = ("--all-sites" in help_text) or (" -a," in help_text) or ("-a," in help_text)
        flags["folderoutput"] = "--folderoutput" in help_text
        flags["no_recursion"] = "--no-recursion" in help_text
        flags["timeout"] = "--timeout" in help_text
        flags["txt"] = "--txt" in help_text
        flags["no_color"] = "--no-color" in help_text
        return {
            "installed": True,
            "executable": str(exe),
            "version": version or f"exit {v_code}",
            "flags": flags,
            "error": "",
        }
    except (OSError, ValueError, TimeoutError, ToolCancelled) as exc:
        return {
            "installed": True,
            "executable": str(exe),
            "version": version,
            "flags": flags,
            "error": str(exc)[:300],
        }


def _classify_item(raw_status: str, http_code, error_text: str) -> str:
    """Never call a blocked, WAF, CAPTCHA, rate-limited, or timed-out site 'no account'."""
    st = (raw_status or "").strip().upper().split(".")[-1]
    err = (error_text or "").strip().lower()
    code_str = str(http_code or "").strip()

    if code_str == "429" or "rate limit" in err or "too many requests" in err or "throttl" in err:
        return "Rate limited"
    if (
        code_str in ("401", "403")
        or st in ("WAF", "BLOCKED", "CAPTCHA", "FORBIDDEN")
        or any(tok in err for tok in ("captcha", "cloudflare", "waf", "access denied", "forbidden", "blocked", "login required"))
    ):
        return "Blocked / auth required"
    if "timeout" in err or "timed out" in err or st == "TIMEOUT":
        return "Timed out"
    if st == "CLAIMED":
        return "Maigret-reported public profile"
    if st == "AVAILABLE":
        return "No profile reported"
    return "Maigret inconclusive"


def _extract_records_from_json_payload(payload):
    """Normalize both Maigret `--json simple` dict and `--json ndjson` list/lines."""
    items = []
    if isinstance(payload, dict):
        for site_key, entry in payload.items():
            if not isinstance(entry, dict):
                continue
            status_obj = entry.get("status")
            if isinstance(status_obj, dict):
                raw_status = status_obj.get("status") or ""
                url = entry.get("url_user") or status_obj.get("url") or ""
                http_code = entry.get("http_status") or status_obj.get("http_status") or ""
                elapsed = status_obj.get("query_time") or entry.get("response_time_s") or ""
                err = status_obj.get("context") or status_obj.get("error") or entry.get("error") or ""
                tags = status_obj.get("tags") or entry.get("tags") or []
                site_name = status_obj.get("site_name") or entry.get("site_name") or site_key
            else:
                raw_status = str(status_obj or entry.get("exists") or "")
                url = entry.get("url_user") or entry.get("url") or ""
                http_code = entry.get("http_status") or ""
                elapsed = entry.get("response_time_s") or entry.get("query_time") or ""
                err = entry.get("error") or entry.get("context") or ""
                tags = entry.get("tags") or []
                site_name = entry.get("site_name") or entry.get("name") or site_key
            items.append((str(site_name), str(raw_status), str(url), http_code, elapsed, str(err), tags))
    elif isinstance(payload, list):
        for entry in payload:
            if not isinstance(entry, dict):
                continue
            status_obj = entry.get("status")
            if isinstance(status_obj, dict):
                raw_status = status_obj.get("status") or ""
                url = entry.get("url_user") or status_obj.get("url") or ""
                http_code = entry.get("http_status") or status_obj.get("http_status") or ""
                elapsed = status_obj.get("query_time") or entry.get("response_time_s") or ""
                err = status_obj.get("context") or status_obj.get("error") or entry.get("error") or ""
                tags = status_obj.get("tags") or entry.get("tags") or []
                site_name = entry.get("sitename") or status_obj.get("site_name") or entry.get("site_name") or ""
            else:
                raw_status = str(status_obj or entry.get("exists") or "")
                url = entry.get("url_user") or entry.get("url") or ""
                http_code = entry.get("http_status") or ""
                elapsed = entry.get("response_time_s") or ""
                err = entry.get("error") or ""
                tags = entry.get("tags") or []
                site_name = entry.get("sitename") or entry.get("site_name") or entry.get("name") or ""
            items.append((str(site_name), str(raw_status), str(url), http_code, elapsed, str(err), tags))
    return items


def parse_json_report(path: Path, username: str, include_unconfirmed=False, limit=2500):
    """Parse Maigret simple JSON or NDJSON report into normalized observations + coverage counts."""
    raw_text = path.read_text(encoding="utf-8-sig", errors="replace").strip()
    if not raw_text:
        raise ValueError("Maigret produced an empty JSON report.")
    payload = None
    try:
        payload = json.loads(raw_text)
    except ValueError:
        lines = [line.strip() for line in raw_text.splitlines() if line.strip()]
        parsed_lines = []
        for line in lines:
            try:
                obj = json.loads(line)
            except ValueError as exc:
                raise ValueError("Maigret returned malformed JSON/NDJSON.") from exc
            if isinstance(obj, dict):
                parsed_lines.append(obj)
        if not parsed_lines:
            raise ValueError("Maigret returned malformed JSON/NDJSON.")
        payload = parsed_lines

    items = _extract_records_from_json_payload(payload)
    if not items and isinstance(payload, dict) and payload:
        raise ValueError("Maigret returned an unrecognized JSON structure.")

    counts = {
        "attempted": 0,
        "claimed": 0,
        "not_found": 0,
        "blocked": 0,
        "rate_limited": 0,
        "timed_out": 0,
        "inconclusive": 0,
    }
    results = []
    for i, (site_name, raw_status, url, http_code, elapsed, err, tags) in enumerate(items):
        if i >= 20_000:
            raise ValueError("Maigret returned an unexpectedly large report.")
        counts["attempted"] += 1
        status = _classify_item(raw_status, http_code, err)
        if status == "Maigret-reported public profile":
            counts["claimed"] += 1
        elif status == "No profile reported":
            counts["not_found"] += 1
        elif status == "Blocked / auth required":
            counts["blocked"] += 1
        elif status == "Rate limited":
            counts["rate_limited"] += 1
        elif status == "Timed out":
            counts["timed_out"] += 1
        else:
            counts["inconclusive"] += 1

        if status != "Maigret-reported public profile" and not include_unconfirmed:
            continue

        parsed = urlsplit(url.strip())
        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            if status == "Maigret-reported public profile":
                continue
            clean_url = ""
        else:
            clean_url = url.strip()

        site_label = (site_name or parsed.hostname or "unknown").strip()[:120]
        tag_str = ", ".join(str(t) for t in tags[:6]) if isinstance(tags, list) and tags else ""
        note_parts = [
            f"Site: {site_label}",
            f"HTTP: {http_code or 'unknown'}",
        ]
        if elapsed != "":
            note_parts.append(f"response: {elapsed}s")
        if tag_str:
            note_parts.append(f"tags: {tag_str}")
        if err:
            note_parts.append(f"detail: {err[:160]}")
        note_parts.append(
            "third-party automated check, independently verify; does not establish account ownership or private membership."
        )
        results.append(("Maigret", username, status, clean_url, "; ".join(note_parts)))
        if len(results) >= limit:
            break

    deduped = list({(row[2], row[3] or row[4]): row for row in results}.values())
    return deduped, counts


def parse_txt_report(path: Path, username: str, limit=2500):
    """Graceful fallback when an older Maigret build emits TXT reports instead of JSON."""
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    urls = []
    for link in re.findall(r'https?://[^\s<>"\]]+', text):
        parsed = urlsplit(link)
        if parsed.scheme in ("http", "https") and parsed.hostname:
            urls.append(link)
    unique = list(dict.fromkeys(urls))[:limit]
    rows = [
        (
            "Maigret",
            username,
            "Maigret-reported public profile",
            u,
            f"Site: {urlsplit(u).hostname}; parsed from Maigret TXT fallback; third-party automated check, independently verify; does not establish account ownership.",
        )
        for u in unique
    ]
    counts = {
        "attempted": len(unique),
        "claimed": len(unique),
        "not_found": 0,
        "blocked": 0,
        "rate_limited": 0,
        "timed_out": 0,
        "inconclusive": 0,
    }
    return rows, counts


def scan(
    username: str,
    *,
    all_sites: bool = False,
    top_sites: int = DEFAULT_TOP_SITES,
    tags=None,
    sites=None,
    legacy_three_sites: bool = False,
    timeout_per_site: int = 12,
    cancel=None,
    executable=None,
    include_unconfirmed: bool = False,
    check_capabilities: bool = False,
    runner=run_command,
    on_output=None,
):
    """Run Maigret in full-scan mode (or optional scoped/legacy mode) and return normalized rows."""
    name = validate_username(username)
    exe = executable or find_executable()
    if not exe:
        return [(
            "Maigret",
            name,
            "Source unavailable",
            "",
            "Maigret is not installed. Use Install / repair Maigret on the Maigret screen or place maigret_standalone.exe in %LOCALAPPDATA%\\FieldIndex\\tools\\maigret.",
        )]

    if not 3 <= int(timeout_per_site) <= 60:
        raise ValueError("Timeout per site must be between 3 and 60 seconds.")

    selected_sites = list(dict.fromkeys(s.strip() for s in (sites or []) if s.strip()))
    if legacy_three_sites:
        selected_sites = list(LEGACY_THREE_SITES)
    if len(selected_sites) > 150:
        raise ValueError("Too many custom sites selected (limit 150).")
    if any(not VALID_SITE_RE.fullmatch(item) for item in selected_sites):
        raise ValueError("Use only valid Maigret site names in the optional site filter.")

    selected_tags = list(dict.fromkeys(t.strip().lower() for t in (tags or []) if t.strip()))
    if len(selected_tags) > 20:
        raise ValueError("Too many tags selected (limit 20).")
    if any(not VALID_TAG_RE.fullmatch(t) for t in selected_tags):
        raise ValueError("Tags may only contain letters, digits, hyphens, and underscores.")

    caps = probe_capabilities(exe, runner=runner) if check_capabilities else None
    flags = caps["flags"] if caps else {
        "json": True,
        "tags": True,
        "site": True,
        "top_sites": True,
        "all_sites": True,
        "folderoutput": True,
        "no_recursion": True,
        "timeout": True,
        "txt": True,
        "no_color": True,
    }
    tool_version = caps["version"] if caps and caps.get("version") else "unprobed"

    with tempfile.TemporaryDirectory(prefix="fieldindex_maigret_") as tmp:
        args = [str(exe), name]
        if flags.get("no_recursion", True):
            args.append("--no-recursion")
        if flags.get("no_color", True):
            args.append("--no-color")
        if flags.get("timeout", True):
            args += ["--timeout", str(int(timeout_per_site))]
        if flags.get("folderoutput", True):
            args += ["--folderoutput", tmp]
        if flags.get("json", True):
            args += ["--json", "simple"]
        elif flags.get("txt", True):
            args.append("--txt")

        if selected_sites:
            for site in selected_sites:
                args += ["--site", site]
        elif selected_tags:
            if not flags.get("tags", True):
                raise ValueError("The installed Maigret version does not advertise --tags support.")
            args += ["--tags", ",".join(selected_tags)]
        elif all_sites:
            if flags.get("all_sites", True):
                args.append("-a")
        else:
            if flags.get("top_sites", True) and top_sites:
                args += ["--top-sites", str(max(10, min(int(top_sites), 10_000)))]

        run_timeout = 900 if all_sites else 480
        try:
            run_kwargs = {"cwd": tmp, "cancel": cancel, "timeout": run_timeout}
            if on_output is not None:
                run_kwargs["on_output"] = on_output
            code, output = runner(args, **run_kwargs)
        except ToolCancelled:
            return [("Maigret", name, "Cancelled", "", "Maigret scan cancelled; no incomplete findings saved.")]
        except TimeoutError as exc:
            return [("Maigret", name, "Timed out", "", "Maigret exceeded total scan deadline: " + str(exc)[:240])]
        except (OSError, ValueError) as exc:
            return [("Maigret", name, "Source unavailable", "", "Could not complete Maigret: " + str(exc)[:300])]

        json_reports = sorted(Path(tmp).rglob("*.json"))
        txt_reports = sorted(Path(tmp).rglob("*.txt"))

        rows = []
        counts = None
        try:
            if json_reports:
                rows, counts = parse_json_report(json_reports[0], name, include_unconfirmed=include_unconfirmed)
            elif txt_reports:
                rows, counts = parse_txt_report(txt_reports[0], name)
            else:
                note = f"Exit code {code}. No structured report file produced. " + output[-350:]
                return [("Maigret", name, "Source unavailable", "", note.strip())]
        except (ValueError, OSError) as exc:
            return [("Maigret", name, "Malformed tool report", "", str(exc)[:350])]

        mode_label = (
            "legacy 3-site mode"
            if legacy_three_sites
            else f"sites={','.join(selected_sites)}"
            if selected_sites
            else f"tags={','.join(selected_tags)}"
            if selected_tags
            else "all sites (-a)"
            if all_sites
            else f"top {top_sites} sites"
        )
        summary_note = (
            f"Maigret ({tool_version}, {mode_label}) coverage: attempted={counts['attempted']}, "
            f"claimed={counts['claimed']}, not_found={counts['not_found']}, "
            f"blocked={counts['blocked']}, rate_limited={counts['rate_limited']}, "
            f"timed_out={counts['timed_out']}, inconclusive={counts['inconclusive']}. "
            "Blocked/rate-limited/timed-out sites are NOT evidence of absence."
        )

        if code:
            rows.append(("Maigret", name, "Incomplete scan", "", f"Exit {code}; partial results only. {summary_note} " + output[-180:]))
        elif not rows:
            rows.append(("Maigret", name, "No profile leads reported", "", summary_note))
        else:
            rows.append(("Maigret", name, "Scan coverage summary", "", summary_note))
        return rows
