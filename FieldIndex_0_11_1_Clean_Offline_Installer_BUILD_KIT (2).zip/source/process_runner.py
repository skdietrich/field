"""Bounded subprocess execution for reviewed local tool commands."""
from __future__ import annotations

import os
import subprocess
import tempfile
import time


class ToolCancelled(Exception):
    pass


def _kill_process_tree(process):
    """Terminate process and (on Windows) any spawned child processes."""
    if process.poll() is not None:
        return
    if os.name == "nt":
        try:
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(process.pid)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                timeout=5,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except (OSError, subprocess.SubprocessError):
            pass
    if process.poll() is None:
        try:
            process.terminate()
            process.wait(timeout=3)
        except (OSError, subprocess.TimeoutExpired):
            try:
                process.kill()
                process.wait(timeout=3)
            except (OSError, subprocess.TimeoutExpired):
                pass


def run_command(args, cwd=None, cancel=None, timeout=90, output_limit=8_000_000, on_output=None):
    """Execute a subprocess using argument arrays (never shell=True)."""
    if cancel is not None and cancel.is_set():
        raise ToolCancelled("Cancelled before launch")
    with tempfile.TemporaryFile() as output:
        process = subprocess.Popen(
            args,
            cwd=cwd,
            stdout=output,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        deadline = time.monotonic() + timeout
        last_pos = 0
        try:
            while process.poll() is None:
                if cancel is not None and cancel.is_set():
                    raise ToolCancelled("Cancelled by researcher")
                if time.monotonic() >= deadline:
                    raise TimeoutError("Local tool exceeded its execution deadline")
                size = output.seek(0, 2)
                if size > output_limit:
                    raise ValueError("Local tool exceeded the output limit")
                if on_output is not None and size > last_pos:
                    output.seek(last_pos)
                    chunk = output.read(min(size - last_pos, 16_384))
                    last_pos += len(chunk)
                    try:
                        on_output(chunk.decode("utf-8", errors="replace"))
                    except Exception:
                        pass
                time.sleep(0.05)
            size = output.seek(0, 2)
            if size > output_limit:
                raise ValueError("Local tool exceeded the output limit")
            if on_output is not None and size > last_pos:
                output.seek(last_pos)
                chunk = output.read(min(size - last_pos, 32_000))
                try:
                    on_output(chunk.decode("utf-8", errors="replace"))
                except Exception:
                    pass
            output.seek(max(0, size - 32_000))
            text = output.read().decode("utf-8", errors="replace")
            return process.returncode, text
        finally:
            _kill_process_tree(process)
