"""FieldIndex Sherlock CLI integration. Does not bundle third-party source code.

Uses Sherlock's documented CSV format and records reported public profile leads as
unverified. A run happens only after the operator presses the Run control.
"""
from __future__ import annotations

import csv
import os
import re
import shutil
import sys
import tempfile
from pathlib import Path
from urllib.parse import urlsplit

from process_runner import run_command, ToolCancelled


def validate_username(value: str) -> str:
    if not isinstance(value, str):
        raise ValueError("Enter a public username.")
    name = value.strip().removeprefix("@")
    if not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}", name):
        raise ValueError(
            "Enter one public username, 1-64 letters, digits, dots, underscores or hyphens. Do not enter an email address."
        )
    return name


def find_executable(base=None, which=None) -> str | None:
    """Check FieldIndex-managed installation, regular PATH and sibling Scripts folders."""
    which = which or shutil.which
    home = Path(base or (Path(os.getenv("LOCALAPPDATA") or Path.home()) / "FieldIndex"))
    candidates = [
        home / "tools" / "sherlock" / ".venv" / "Scripts" / "sherlock.exe",
        home / "tools" / "sherlock" / ".venv" / "bin" / "sherlock",
        Path(sys.executable).parent / "Scripts" / "sherlock.exe",
        Path(sys.executable).parent / "sherlock.exe",
    ]
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)
    return which("sherlock")


def probe_capabilities(executable=None, runner=run_command) -> dict:
    """Detect installed Sherlock version and actual CLI flag availability (--nsfw, --csv, etc.)."""
    exe = executable or find_executable()
    if not exe:
        return {
            "installed": False,
            "executable": "",
            "version": "",
            "flags": {},
            "error": "Sherlock executable not found.",
        }
    version = ""
    flags = {"csv": False, "nsfw": False, "site": False, "timeout": False, "folderoutput": False, "no_color": False}
    try:
        v_code, v_out = runner([str(exe), "--version"], timeout=10)
        if v_code == 0:
            version = v_out.strip().splitlines()[-1][:120] if v_out.strip() else "unknown"
        h_code, h_out = runner([str(exe), "--help"], timeout=10)
        help_text = h_out if h_code == 0 else ""
        flags["csv"] = "--csv" in help_text
        flags["nsfw"] = "--nsfw" in help_text
        flags["site"] = "--site" in help_text
        flags["timeout"] = "--timeout" in help_text
        flags["folderoutput"] = "--folderoutput" in help_text
        flags["no_color"] = "--no-color" in help_text
        return {
            "installed": True,
            "executable": str(exe),
            "version": version or f"exit {v_code}",
            "flags": flags,
            "error": "",
        }
    except (OSError, ValueError, TimeoutError, ToolCancelled) as exc:
        return {
            "installed": True,
            "executable": str(exe),
            "version": version,
            "flags": flags,
            "error": str(exc)[:300],
        }


def _classify_csv_row(raw_exists: str, http_code: str) -> str:
    raw = (raw_exists or "").strip().upper().split(".")[-1]
    code = (http_code or "").strip()
    if raw == "CLAIMED":
        return "Sherlock-reported public profile"
    if code == "429":
        return "Rate limited"
    if code in ("401", "403"):
        return "Blocked / auth required"
    if raw == "AVAILABLE":
        return "No profile reported"
    return "Sherlock inconclusive"


def summarize_report(path: Path) -> dict:
    """Compute attempted, claimed, available, blocked, rate-limited, and inconclusive counts."""
    counts = {
        "attempted": 0,
        "claimed": 0,
        "available": 0,
        "blocked": 0,
        "rate_limited": 0,
        "inconclusive": 0,
    }
    with path.open("r", encoding="utf-8-sig", errors="replace", newline="") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or not {"name", "url_user", "exists"}.issubset(set(reader.fieldnames)):
            raise ValueError("Sherlock returned an unexpected CSV report format.")
        for i, row in enumerate(reader):
            if i >= 15000:
                raise ValueError("Sherlock returned an unexpectedly large report.")
            counts["attempted"] += 1
            st = _classify_csv_row(row.get("exists") or "", row.get("http_status") or "")
            if st == "Sherlock-reported public profile":
                counts["claimed"] += 1
            elif st == "No profile reported":
                counts["available"] += 1
            elif st == "Blocked / auth required":
                counts["blocked"] += 1
            elif st == "Rate limited":
                counts["rate_limited"] += 1
            else:
                counts["inconclusive"] += 1
    return counts


def parse_report(path: Path, username: str, include_unconfirmed=False, limit=2000):
    """Map Sherlock's CSV statuses without treating a public match as ownership proof."""
    results = []
    with path.open("r", encoding="utf-8-sig", errors="replace", newline="") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or not {"name", "url_user", "exists"}.issubset(set(reader.fieldnames)):
            raise ValueError("Sherlock returned an unexpected CSV report format.")
        for i, row in enumerate(reader):
            if i >= 15000:
                raise ValueError("Sherlock returned an unexpectedly large report.")
            http_code = (row.get("http_status") or "").strip()[:20]
            status = _classify_csv_row(row.get("exists") or "", http_code)
            if status != "Sherlock-reported public profile" and not include_unconfirmed:
                continue
            url = (row.get("url_user") or "").strip()
            parsed = urlsplit(url)
            if parsed.scheme not in ("http", "https") or not parsed.hostname:
                continue
            site = (row.get("name") or parsed.hostname).strip()[:120]
            elapsed = (row.get("response_time_s") or "").strip()[:25]
            note = (
                f"Site: {site}; HTTP: {http_code or 'unknown'}; response: {elapsed or 'unknown'}s; "
                "third-party automated check, independently verify; does not establish account ownership or private membership."
            )
            results.append(("Sherlock", username, status, url, note))
            if len(results) >= limit:
                break
    return list({(row[2], row[3]): row for row in results}.values())


def scan(
    username,
    *,
    nsfw=False,
    sites=None,
    timeout_per_site=12,
    cancel=None,
    executable=None,
    include_unconfirmed=False,
    check_capabilities=False,
    runner=run_command,
    on_output=None,
):
    name = validate_username(username)
    exe = executable or find_executable()
    if not exe:
        return [(
            "Sherlock",
            name,
            "Source unavailable",
            "",
            "Sherlock is not installed. Use Install Sherlock on the Sherlock screen; it is optional and requires an explicit install.",
        )]
    if not 3 <= int(timeout_per_site) <= 60:
        raise ValueError("Timeout per site must be between 3 and 60 seconds.")
    selected = list(dict.fromkeys(s.strip() for s in (sites or []) if s.strip()))
    if len(selected) > 150:
        raise ValueError("Too many custom sites selected.")
    if any(not re.fullmatch(r"[A-Za-z0-9][\w .&+\-]{0,79}", item) for item in selected):
        raise ValueError("Use only the official site names in the optional site filter.")

    use_nsfw = bool(nsfw)
    if check_capabilities:
        caps = probe_capabilities(exe, runner=runner)
        if use_nsfw and not caps["flags"].get("nsfw", False):
            return [(
                "Sherlock",
                name,
                "Source unavailable",
                "",
                f"Installed Sherlock ({caps.get('version') or 'unknown'}) does not support --nsfw.",
            )]

    with tempfile.TemporaryDirectory(prefix="fieldindex_sherlock_") as tmp:
        args = [
            str(exe),
            name,
            "--csv",
            "--no-color",
            "--timeout",
            str(int(timeout_per_site)),
            "--folderoutput",
            tmp,
        ]
        if use_nsfw:
            args.append("--nsfw")
        for site in selected:
            args += ["--site", site]
        try:
            run_kwargs = {"cwd": tmp, "cancel": cancel, "timeout": 600}
            if on_output is not None:
                run_kwargs["on_output"] = on_output
            code, output = runner(args, **run_kwargs)
        except ToolCancelled:
            return [("Sherlock", name, "Cancelled", "", "Scan cancelled; no incomplete findings saved.")]
        except (TimeoutError, OSError, ValueError) as exc:
            return [("Sherlock", name, "Source unavailable", "", "Could not complete Sherlock: " + str(exc)[:300])]
        reports = sorted(Path(tmp).glob("*.csv"))
        if not reports:
            note = f"Exit code {code}. " + output[-350:]
            return [("Sherlock", name, "Source unavailable", "", note.strip())]
        try:
            rows = parse_report(reports[0], name, include_unconfirmed=include_unconfirmed)
        except (ValueError, OSError, csv.Error) as exc:
            return [("Sherlock", name, "Source unavailable", "", str(exc)[:350])]
        if code:
            rows.append(("Sherlock", name, "Incomplete scan", "", f"Exit {code}; report may be partial. " + output[-200:]))
        elif not rows:
            rows.append((
                "Sherlock",
                name,
                "No profile leads reported",
                "",
                "No public-profile leads in the parsed results; this does not establish absence.",
            ))
        return rows
