"""Public directory records researched on 2026-11-21. Membership availability varies."""
REVIEWED = "2026-11-21"
ROWS = [
  [
    "Swinger platforms",
    "SDC",
    "https://www.sdc.com/about-us/",
    "International",
    "Platform",
    "Global lifestyle community with public business and event information."
  ],
  [
    "Club directories",
    "SDC business directory",
    "https://www.sdc.com/biz/",
    "International",
    "Directory",
    "Club and lifestyle-business directory."
  ],
  [
    "Event directories",
    "SDC Europe events",
    "https://www.sdc.com/party/europe/",
    "Europe",
    "Directory",
    "Public event listings. Private events require membership."
  ],
  [
    "Swinger platforms",
    "Kasidie",
    "https://enm.kasidie.com/about-us",
    "International",
    "Platform",
    "ENM and swinger social network."
  ],
  [
    "Swinger platforms",
    "SwingTowns",
    "https://www.swingtowns.com/",
    "International",
    "Platform",
    "Swinging, polyamory and open-relationship community."
  ],
  [
    "Swinger platforms",
    "FabSwingers",
    "https://www.fabswingers.com/content/about",
    "United Kingdom",
    "Platform",
    "Swinger community with public service information."
  ],
  [
    "Swinger platforms",
    "SpicyMatch",
    "https://www.spicymatch.com/",
    "International",
    "Platform",
    "Lifestyle network with party and event information."
  ],
  [
    "Swinger platforms",
    "Wyylde",
    "https://ask.wyylde.com/hc/en-150/articles/33918184223122-Wyylde-what-is-it",
    "France",
    "Platform",
    "Libertine community. Entry links to the official service overview."
  ],
  [
    "Club directories",
    "JOYclub club directory",
    "https://www.joyclub.com/en/swingerclubs/",
    "Europe",
    "Directory",
    "European swinger-club listings. Some automated access is blocked."
  ],
  [
    "Club directories",
    "Swinging Heaven clubs",
    "https://www.swingingheaven.co.uk/clubs",
    "United Kingdom",
    "Directory",
    "UK club directory with venue information."
  ],
  [
    "Club directories",
    "SwingRoad UK",
    "https://swingroad.co.uk/clubs/uk",
    "United Kingdom",
    "Directory",
    "Swinger and fetish venue directory."
  ],
  [
    "Club directories",
    "Swing Directory",
    "https://swing.directory/",
    "Europe",
    "Directory",
    "Regional club and platform guides."
  ],
  [
    "Club directories",
    "Swinging Clubs UK",
    "https://www.swingingclubsuk.co.uk/",
    "United Kingdom",
    "Directory",
    "UK club and event directory."
  ],
  [
    "Sex & lifestyle clubs",
    "Colette events",
    "https://coletteclubs.com/events/widget_featured",
    "United States",
    "Venue group",
    "Dallas, Houston and Austin club event information."
  ],
  [
    "Sex & lifestyle clubs",
    "Club Eden",
    "https://edenclubs.com/events/",
    "United States",
    "Venue group",
    "Club-group event calendar."
  ],
  [
    "Sex & lifestyle clubs",
    "Trapeze",
    "https://trapezeclubs.com/",
    "United States",
    "Venue group",
    "Atlanta and South Florida lifestyle clubs."
  ],
  [
    "Sex & lifestyle clubs",
    "Club M4",
    "https://clubm4.com/",
    "Canada",
    "Venue",
    "Toronto-area swinger club."
  ],
  [
    "Sex & lifestyle clubs",
    "Oasis Aqualounge",
    "https://oasisaqualounge.com/",
    "Canada",
    "Venue",
    "Toronto adult social club."
  ],
  [
    "Sex & lifestyle clubs",
    "Liberty Elite",
    "https://libertyelite.co.uk/home-2/",
    "United Kingdom",
    "Venue",
    "Private members club for swinging and fetish events."
  ],
  [
    "Sex & lifestyle clubs",
    "Chameleons",
    "https://www.chameleons.cc/",
    "United Kingdom",
    "Venue group",
    "Swinger clubs with public venue information."
  ],
  [
    "Sex & lifestyle clubs",
    "Townhouse",
    "https://townhouseswingers.com/about",
    "United Kingdom",
    "Venue",
    "Swing, kink and LGBTQ community events."
  ],
  [
    "Sex & lifestyle clubs",
    "Xtasia",
    "https://xtasia.co.uk/",
    "United Kingdom",
    "Venue",
    "West Bromwich lifestyle club."
  ],
  [
    "Sex & lifestyle clubs",
    "Fun4Two",
    "https://www.fun4two.nl/english/informatie/index.html",
    "Netherlands",
    "Venue",
    "Private club with public visitor information."
  ],
  [
    "Sex & lifestyle clubs",
    "Le Glamour",
    "https://www.leglamour.com/",
    "France",
    "Venue",
    "Libertine club in Cap d'Agde."
  ],
  [
    "Sex & lifestyle clubs",
    "Our Secret Spot",
    "https://oursecretspot.com.au/",
    "Australia",
    "Venue",
    "Sydney adult play-party club."
  ],
  [
    "Sex & lifestyle clubs",
    "CCK",
    "https://swinging.nz/the-club/",
    "New Zealand",
    "Venue",
    "Auckland adult lounge and swinger club."
  ],
  [
    "Sex & lifestyle clubs",
    "KiwiKlub",
    "https://www.kiwiklub.com/",
    "South Africa",
    "Venue",
    "South African swinger club."
  ],
  [
    "Sex & lifestyle clubs",
    "Club Privata",
    "https://www.clubprivata.com/",
    "United States",
    "Venue",
    "Portland lifestyle club."
  ],
  [
    "Sex & lifestyle clubs",
    "Club Sapphire",
    "https://clubsapphire.com/",
    "United States",
    "Venue",
    "Seattle-area private lifestyle club."
  ],
  [
    "Lifestyle resorts & travel",
    "Hedonism II",
    "https://hedonism.com/resort/",
    "Jamaica",
    "Resort",
    "Adults-only, clothing-optional, lifestyle-friendly resort."
  ],
  [
    "Lifestyle resorts & travel",
    "Temptation Cancun",
    "https://www.temptation-experience.com/",
    "Mexico",
    "Resort",
    "Adults-only resort. Review its own conduct and admission rules."
  ],
  [
    "Lifestyle resorts & travel",
    "Bliss Cruise",
    "https://blisscruise.com/first-timers/",
    "International",
    "Travel",
    "Couples-only lifestyle cruises and first-time visitor information."
  ],
  [
    "Kink events & festivals",
    "Darklands",
    "https://darklands.be/general-festival-information/",
    "Belgium",
    "Event",
    "Antwerp fetish festival and event information."
  ],
  [
    "Kink events & festivals",
    "BoundCon",
    "https://www.boundcon.com/en/boundcon/convention",
    "Germany",
    "Event",
    "Munich bondage, BDSM and fetish convention."
  ],
  [
    "Kink events & festivals",
    "Torture Garden",
    "https://torturegarden.com/events/",
    "United Kingdom",
    "Event",
    "London and international fetish events."
  ],
  [
    "Kink events & festivals",
    "Folsom Street",
    "https://www.folsomstreet.org/",
    "United States",
    "Event",
    "Leather and kink community organization and events."
  ],
  [
    "BDSM & kink",
    "Fetish.com community guidelines",
    "https://www.fetish.com/guidelines",
    "International",
    "Platform",
    "Community rules and description of age-gated access."
  ],
  [
    "Adult dating platforms",
    "Feeld",
    "https://feeld.co/about",
    "International",
    "Platform",
    "Public information about the dating service."
  ],
  [
    "Adult dating platforms",
    "ROMEO",
    "https://www.romeo.com/en/about/",
    "International",
    "Platform",
    "Public company overview of the dating platform."
  ],
  [
    "Adult dating platforms",
    "Recon",
    "https://t101.com/recon/",
    "International",
    "Platform",
    "Operator's overview of the fetish dating service."
  ],
  [
    "Adult dating platforms",
    "Squirt",
    "https://mediakit.squirt.org/",
    "International",
    "Platform",
    "Publisher's media kit for the dating and social service."
  ],
  [
    "Swinger platforms",
    "NZSwingers",
    "https://www.nzswingers.co.nz/",
    "New Zealand",
    "Platform",
    "New Zealand swinger community."
  ]
]

RECORDS = [dict(category=c, name=n, url=u, country=r, kind=k, description=t,
                evidence_url=u, reviewed=REVIEWED, status="Public web source located")
           for c,n,u,r,k,t in ROWS]

