"""SQLite schema migrations, provenance review decisions, hypotheses, atomic backups, and reporting."""
from __future__ import annotations

import os
import sqlite3
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import adapters

CURRENT_SCHEMA_VERSION = 8

REVIEW_DECISIONS = (
    "Unreviewed",
    "Same handle — identity not established",
    "Confirmed public page",
    "Corroborated fact",
    "Rejected / false positive",
    "Counterevidence",
    "Inaccessible / blocked source",
)

HYPOTHESIS_STATUSES = (
    "Open — needs corroboration",
    "Partially supported (public leads only)",
    "Contradicted by evidence",
    "Substantiated by primary source",
    "Withdrawn",
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def apply_migrations(db: sqlite3.Connection) -> list[int]:
    """Initialize base tables (v0.6/v0.10 compatible) and run incremental migrations through v8."""
    try:
        db.execute("PRAGMA foreign_keys = ON")
        db.execute("PRAGMA journal_mode = WAL")
    except sqlite3.Error:
        pass

    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS cases(id INTEGER PRIMARY KEY, name TEXT UNIQUE);
        CREATE TABLE IF NOT EXISTS fields(c INTEGER, k TEXT, v TEXT, PRIMARY KEY(c, k));
        CREATE TABLE IF NOT EXISTS records(id INTEGER PRIMARY KEY, c INTEGER, time TEXT, source TEXT, query TEXT, status TEXT, url TEXT, note TEXT);
        INSERT OR IGNORE INTO cases VALUES(1, 'Research desk');
        CREATE TABLE IF NOT EXISTS annotations(record INTEGER PRIMARY KEY, body TEXT);
        CREATE TABLE IF NOT EXISTS runs(id INTEGER PRIMARY KEY, c INTEGER, started TEXT);
        CREATE TABLE IF NOT EXISTS run_records(run INTEGER, record INTEGER PRIMARY KEY);
        CREATE TABLE IF NOT EXISTS captures(c INTEGER, digest TEXT, PRIMARY KEY(c, digest));
        CREATE TABLE IF NOT EXISTS publishers(c INTEGER, name TEXT, url TEXT, PRIMARY KEY(c, url));
        CREATE TABLE IF NOT EXISTS recipes(c INTEGER, name TEXT, settings TEXT, PRIMARY KEY(c, name));
        CREATE TABLE IF NOT EXISTS dork_recipes(c INTEGER NOT NULL, name TEXT NOT NULL, settings TEXT NOT NULL, created TEXT NOT NULL, PRIMARY KEY(c, name));
        CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, applied_utc TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS run_routes(run INTEGER, position INTEGER, route TEXT NOT NULL, completed INTEGER DEFAULT 0, PRIMARY KEY(run, position));
        """
    )

    existing = {row[0] for row in db.execute("SELECT version FROM schema_migrations")}
    applied = []
    stamp = utc_now()

    if 6 not in existing:
        with db:
            db.execute("INSERT OR IGNORE INTO schema_migrations VALUES(6, ?)", (stamp,))
        applied.append(6)

    if 7 not in existing:
        with db:
            db.executescript(
                """
                CREATE TABLE IF NOT EXISTS evidence_reviews(
                    record INTEGER PRIMARY KEY,
                    decision TEXT NOT NULL DEFAULT 'Unreviewed',
                    published_date TEXT NOT NULL DEFAULT '',
                    event_date TEXT NOT NULL DEFAULT '',
                    counterevidence TEXT NOT NULL DEFAULT '',
                    reviewed_utc TEXT NOT NULL DEFAULT ''
                );
                """
            )
            db.execute("INSERT OR IGNORE INTO schema_migrations VALUES(7, ?)", (stamp,))
        applied.append(7)

    if 8 not in existing:
        with db:
            db.executescript(
                """
                CREATE TABLE IF NOT EXISTS case_hypotheses(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    c INTEGER NOT NULL,
                    claim TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'Open — needs corroboration',
                    supporting TEXT NOT NULL DEFAULT '',
                    contradicting TEXT NOT NULL DEFAULT '',
                    missing_evidence TEXT NOT NULL DEFAULT '',
                    updated_utc TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS case_scope(
                    c INTEGER PRIMARY KEY,
                    authority_basis TEXT NOT NULL DEFAULT '',
                    allowed_scope TEXT NOT NULL DEFAULT '',
                    prohibited_scope TEXT NOT NULL DEFAULT '',
                    updated_utc TEXT NOT NULL DEFAULT ''
                );
                """
            )
            db.execute("INSERT OR IGNORE INTO schema_migrations VALUES(8, ?)", (stamp,))
        applied.append(8)

    return applied


def atomic_write_text(path, content: str, encoding="utf-8"):
    """Write text to a sibling temporary file, flush/fsync, and atomically replace destination."""
    dest = Path(path)
    dest.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=".fieldindex-tmp-", dir=str(dest.parent))
    try:
        with os.fdopen(fd, "w", encoding=encoding, newline="") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_name, dest)
    except Exception:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise


def atomic_backup(db: sqlite3.Connection, destination) -> Path:
    """Create a verified SQLite backup via a temporary file before atomically replacing destination."""
    dest = Path(destination)
    dest.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=".fieldindex-backup-", suffix=".sqlite3", dir=str(dest.parent))
    os.close(fd)
    tmp_path = Path(tmp_name)
    target = None
    try:
        target = sqlite3.connect(tmp_path)
        db.backup(target)
        integrity = target.execute("PRAGMA integrity_check").fetchone()
        if not integrity or integrity[0] != "ok":
            raise sqlite3.DatabaseError("Backup failed SQLite integrity_check")
        target.close()
        target = None
        os.replace(tmp_path, dest)
        return dest
    except Exception:
        if target is not None:
            target.close()
        tmp_path.unlink(missing_ok=True)
        raise


def save_review(db: sqlite3.Connection, record_id: int, decision: str, published_date="", event_date="", counterevidence=""):
    if decision not in REVIEW_DECISIONS:
        raise ValueError("Unsupported review decision: " + str(decision))
    with db:
        db.execute(
            """
            INSERT OR REPLACE INTO evidence_reviews(record, decision, published_date, event_date, counterevidence, reviewed_utc)
            VALUES(?, ?, ?, ?, ?, ?)
            """,
            (record_id, decision, published_date.strip()[:40], event_date.strip()[:40], counterevidence.strip()[:2000], utc_now()),
        )


def get_review(db: sqlite3.Connection, record_id: int) -> dict:
    row = db.execute(
        "SELECT decision, published_date, event_date, counterevidence, reviewed_utc FROM evidence_reviews WHERE record=?",
        (record_id,),
    ).fetchone()
    if not row:
        return {
            "decision": "Unreviewed",
            "published_date": "",
            "event_date": "",
            "counterevidence": "",
            "reviewed_utc": "",
        }
    return {
        "decision": row[0],
        "published_date": row[1],
        "event_date": row[2],
        "counterevidence": row[3],
        "reviewed_utc": row[4],
    }


def generate_report_markdown(db: sqlite3.Connection, case_id: int) -> str:
    """Produce a defensible, clearly sourced Markdown investigation report."""
    case_row = db.execute("SELECT name FROM cases WHERE id=?", (case_id,)).fetchone()
    case_name = case_row[0] if case_row else f"Case #{case_id}"
    scope = db.execute(
        "SELECT authority_basis, allowed_scope, prohibited_scope, updated_utc FROM case_scope WHERE c=?",
        (case_id,),
    ).fetchone()
    hypotheses = list(
        db.execute(
            "SELECT claim, status, supporting, contradicting, missing_evidence, updated_utc FROM case_hypotheses WHERE c=? ORDER BY id",
            (case_id,),
        )
    )
    records = list(
        db.execute(
            """
            SELECT r.id, r.time, r.source, r.query, r.status, r.url, r.note,
                   coalesce(a.body, ''),
                   coalesce(ev.decision, 'Unreviewed'),
                   coalesce(ev.published_date, ''),
                   coalesce(ev.event_date, ''),
                   coalesce(ev.counterevidence, ''),
                   coalesce(ev.reviewed_utc, '')
            FROM records r
            LEFT JOIN annotations a ON a.record = r.id
            LEFT JOIN evidence_reviews ev ON ev.record = r.id
            WHERE r.c = ?
            ORDER BY r.id
            """,
            (case_id,),
        )
    )

    deduped = adapters.deduplicate_observations([(r[1], r[2], r[3], r[4], r[5], r[6]) for r in records])
    errors = [r for r in records if adapters.normalize_outcome(r[4]) in ("unavailable", "timeout", "throttled", "blocked/auth", "malformed", "transport_error")]
    dated_events = [r for r in records if r[10] or r[9]]

    lines = [
        f"# FieldIndex Investigation Report: {case_name}",
        "",
        f"- **Generated (UTC):** {utc_now()}",
        f"- **Total logged observations:** {len(records)}",
        f"- **Distinct public URLs observed:** {len(deduped)}",
        f"- **Blocked / errored / unavailable checks:** {len(errors)}",
        "",
        "## Evidence & Attribution Boundary",
        "",
        "> A search snippet, handle match, or automated tool hit is an **unverified lead**, never proof of real-world identity, account ownership, venue attendance, or personal conduct. Blocked, rate-limited, or login-walled sites are not evidence of absence. Original observations remain immutable.",
        "",
    ]

    if scope:
        lines += [
            "## Case Scope & Authorization",
            "",
            f"- **Authority / permission basis:** {scope[0] or 'Not documented'}",
            f"- **Permitted public scope:** {scope[1] or 'Not documented'}",
            f"- **Prohibited scope:** {scope[2] or 'Not documented'}",
            f"- **Last updated (UTC):** {scope[3] or 'N/A'}",
            "",
        ]

    if hypotheses:
        lines += ["## Case Hypotheses & Competing Explanations", ""]
        for i, (claim, status, supp, contra, missing, upd) in enumerate(hypotheses, 1):
            lines += [
                f"### Hypothesis {i}: {claim}",
                f"- **Status:** {status} (updated {upd})",
                f"- **Supporting observations:** {supp or 'None recorded'}",
                f"- **Contradicting / alternative explanations:** {contra or 'None recorded'}",
                f"- **Missing evidence required:** {missing or 'None recorded'}",
                "",
            ]

    lines += ["## Deduplicated Public URL Observations (Source Dependency Summary)", ""]
    if not deduped:
        lines.append("_No canonical public URL observations recorded in this case._")
        lines.append("")
    else:
        for item in deduped:
            lines.append(f"- **{item['canonical_url']}**")
            lines.append(f"  - Observed by: {', '.join(item['adapters'])} ({len(item['observations'])} record(s))")
            lines.append(f"  - Normalized categories: {', '.join(item['categories'])}")
            lines.append(f"  - First/last collected (UTC): {item['first_seen_utc']} .. {item['last_seen_utc']}")
            lines.append(f"  - Provenance note: {item['independence_note']}")
        lines.append("")

    if dated_events:
        lines += ["## Source-Dated Timeline (Distinct from Collection Timestamps)", ""]
        for r in sorted(dated_events, key=lambda x: x[10] or x[9]):
            lines.append(
                f"- **Event/Published date:** {r[10] or r[9]} | **Source:** {r[2]} | **Decision:** {r[8]} | **URL:** {r[5] or 'N/A'} | (Collected {r[1]})"
            )
        lines.append("")

    lines += ["## Blocked, Rate-Limited, and Failed Checks (Unknowns)", ""]
    if not errors:
        lines.append("_No blocked or failed checks recorded._")
        lines.append("")
    else:
        for r in errors:
            lines.append(f"- `{r[1]}` | **{r[2]}** | `{r[4]}` | Query: `{r[3]}` | {r[6][:220]}")
        lines.append("")

    lines += ["## Appendix: Complete Immutable Observation & Review Log", ""]
    for r in records:
        lines.append(
            f"- **#{r[0]}** `{r[1]}` | **{r[2]}** | Outcome: `{r[4]}` | Review: **{r[8]}** | Query: `{r[3]}` | URL: {r[5] or 'none'}"
        )
        if r[6]:
            lines.append(f"  - Original record: {r[6][:400]}")
        if r[7]:
            lines.append(f"  - Analyst notes: {r[7][:400]}")
        if r[11]:
            lines.append(f"  - Counterevidence / caveats: {r[11][:400]}")
    lines.append("")
    return "\n".join(lines)
