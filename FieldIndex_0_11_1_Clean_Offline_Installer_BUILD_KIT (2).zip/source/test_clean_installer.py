"""Verify the installer-specific first-run safety behavior."""
from __future__ import annotations

import sqlite3
import tempfile
import unittest
from pathlib import Path
import tkinter as tk

from fieldindex import Workspace


class CleanInstallerSafetyTests(unittest.TestCase):
    def test_first_launch_creates_consistent_non_destructive_backup(self):
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            root = tk.Tk()
            root.withdraw()
            first = Workspace(root, folder)
            with first.db:
                first.db.execute("INSERT INTO cases(name) VALUES(?)", ("Preserve this case",))
            first.close()
            self.assertFalse(list(folder.glob("cases.before_0_11_1_*.sqlite3")))

            second_root = tk.Tk()
            second_root.withdraw()
            second = Workspace(second_root, folder)
            backups = list(folder.glob("cases.before_0_11_1_*.sqlite3"))
            self.assertEqual(len(backups), 1)
            with sqlite3.connect(backups[0]) as backup:
                self.assertEqual(backup.execute("PRAGMA integrity_check").fetchone()[0], "ok")
                self.assertIsNotNone(backup.execute("SELECT 1 FROM cases WHERE name=?", ("Preserve this case",)).fetchone())
            second.close()

            third_root = tk.Tk()
            third_root.withdraw()
            third = Workspace(third_root, folder)
            self.assertEqual(len(list(folder.glob("cases.before_0_11_1_*.sqlite3"))), 1)
            third.close()


if __name__ == "__main__":
    unittest.main()
