import json
import tempfile
import threading
import time
import tkinter as tk
import unittest
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.parse import urlsplit,parse_qs

import discovery as d
import engine
from fieldindex import Workspace

class DiscoveryTests(unittest.TestCase):
    def test_transport_parser_and_challenge(self):
        fixture=b'<a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.org%2Freport">News <b>report</b></a><a class="result__snippet">Archive</a>'
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                query=parse_qs(urlsplit(self.path).query).get("q",[""])[0]
                body=fixture if query=='"fixture@example.org"' else b'<div class="anomaly-modal">challenge</div>'
                self.send_response(200);self.send_header("Content-Type","text/html");self.end_headers();self.wfile.write(body)
            def log_message(self,*args):pass
        server=ThreadingHTTPServer(("127.0.0.1",0),Handler);worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
        read=d.read
        try:
            with patch("discovery.read",side_effect=lambda url:read("http://127.0.0.1:"+str(server.server_port)+"/?"+urlsplit(url).query)):
                rows=d.web_results('"fixture@example.org"')
                self.assertEqual(rows[0][2:4],("Indexed result","https://example.org/report"))
                self.assertIn("News report",rows[0][4]);self.assertEqual(d.web_results("challenge")[0][2],"Search provider challenge")
        finally:server.shutdown();server.server_close();worker.join()
    def test_providers(self):
        brave={"type":"search","web":{"results":[{"title":"Test","url":"https://example.org/item","description":"Description"}]*2}}
        with patch("discovery.read",return_value=json.dumps(brave)):
            rows=d.web_results("term","Brave Search","fixture");self.assertEqual(len(rows),1);self.assertEqual(rows[0][2],"Indexed result")
        with patch("discovery.read",side_effect=HTTPError("",429,"",{},None)):
            self.assertEqual(d.web_results("term")[0][2],"Rate limited")
        for group,reply in [
            ("Organizations",{"data":[{"attributes":{"entity":{"legalName":{"name":"Example"}}},"id":"ABC"}]}),
            ("Places & maps",{"results":[{"name":"Goura","country":"Greece","latitude":37.9,"longitude":22.3,"id":12}]}),
            ("News & web",{"articles":[{"title":"Source article","url":"https://example.org/article"}]})]:
            with patch("engine.fetch",return_value=reply):
                self.assertEqual(engine.run_source((engine.CATALOG_PROVIDERS[group],"term","Catalogue API",True))[0][2],"Catalogue record")
    def test_file_mentions(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/"article.html";f.write_text("<script>hiddenonly</script><p>Public term</p>",encoding="utf-8")
            self.assertEqual(d.search_file(f,"hiddenonly")[2],"No literal file mention")
            record=d.search_file(f,"public term");self.assertEqual(record[2],"Literal file mention");self.assertIn("SHA-256",record[-1])
    def test_capture_import_twice_and_export(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=tk.Tk();root.withdraw();app=Workspace(root,tmp)
            try:
                f=Path(tmp)/"capture.json";f.write_text(json.dumps({"format":"fieldindex.capture.v1","query":"test","provider":"Google","captured":"2026-11-21T00:00:00Z","page":"https://www.google.com/search?q=test","results":[{"title":"Title","url":"https://example.org/report"}]*2}))
                with patch("fieldindex.filedialog.askopenfilename",return_value=str(f)):
                    app.show("Web discovery");app.import_capture();app.import_capture()
                self.assertEqual(app.db.execute("SELECT count(*) FROM records").fetchone()[0],1)
                app.show("Evidence");app.grouped()
                out=Path(tmp)/"report.json"
                with patch("fieldindex.filedialog.asksaveasfilename",return_value=str(out)):app.export("json")
                self.assertEqual(json.loads(out.read_text())["entries"][0]["outcome"],"Browser capture")
                with patch("fieldindex.filedialog.askopenfilename",return_value=str(out)),patch("fieldindex.simpledialog.askstring",return_value="Imported"):
                    app.import_case()
                self.assertEqual(app.casebox.get(),"Imported")
                self.assertEqual(app.db.execute("SELECT count(*) FROM records WHERE c=?",(app.case,)).fetchone()[0],1)
                def find_button(parent,title):
                    for widget in parent.winfo_children():
                        if isinstance(widget,tk.Button) and widget.cget("text")==title:return widget
                        found=find_button(widget,title)
                        if found:return found
                backup=Path(tmp)/"backup.sqlite3"
                with patch("fieldindex.filedialog.asksaveasfilename",return_value=str(backup)):
                    find_button(app.body,"Back up all cases").invoke()
                import sqlite3
                restored=sqlite3.connect(backup)
                try:
                    self.assertEqual(restored.execute("PRAGMA integrity_check").fetchone()[0],"ok")
                    self.assertEqual(restored.execute("SELECT count(*) FROM records").fetchone()[0],2)
                finally:restored.close()
                app.show("Community sources")
                app.start_plan([("Google","test","Browser search",True)])
                app.show("Investigation plan")
                for _ in range(100):
                    root.update();time.sleep(.01)
                    if not app.active_plans:break
                self.assertEqual(app.db.execute("SELECT count(*) FROM run_records").fetchone()[0],1)
            finally:
                for callback in root.tk.splitlist(root.tk.call("after","info")):root.after_cancel(callback)
                app.db.close();root.destroy()
if __name__=="__main__":unittest.main()


