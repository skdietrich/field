"""Public-search builder tests: operators, site packs, identity caution, GUI and persistence."""
import json
import tempfile
import unittest
from pathlib import Path
from urllib.parse import parse_qs, urlsplit
from unittest.mock import patch
import tkinter as tk

import dork_search as d
from extensions import Registry
from fieldindex import Workspace

PACK = Path(__file__).resolve().parent.parent/'ExtensionPacks'/'adult-public-research.fipack'


def walk(widget):
    for child in widget.winfo_children():
        yield child
        yield from walk(child)


def dispose(app):
    for ident in app.root.tk.splitlist(app.root.tk.call('after','info')):
        app.root.after_cancel(ident)
    app.db.close()
    app.root.destroy()


class DorkSearchTests(unittest.TestCase):
    def test_google_core_filters_and_encoded_search(self):
        fields={'subject':'resistance letters','exact':'Goura roundup',
                'sites':'https://www.loc.gov/collections/, archives.gov',
                'exclude':'modern fiction, commercial','filetype':'pdf',
                'after':'2020-01-01','before':'2027-01-01','title':'historical records',
                'inurl':'collections'}
        result=d.build_plan(fields)
        self.assertEqual(len(result.branches),2)
        query=result.branches[0].query
        self.assertIn('site:www.loc.gov',query)
        self.assertIn('"Goura roundup"',query)
        self.assertIn('-"modern fiction"',query)
        self.assertIn('filetype:pdf',query)
        self.assertIn('intitle:"historical records"',query)
        self.assertIn('inurl:"collections"',query)
        self.assertIn('after:2020-01-01',query)
        self.assertIn('before:2027-01-01',query)
        self.assertEqual(parse_qs(urlsplit(result.branches[0].url).query)['q'],[query])

    def test_engine_urls_all_seven_and_dates_not_silently_claimed(self):
        for name in d.ENGINE_URLS:
            with self.subTest(name=name):
                result=d.build_plan({'exact':'public festival','after':'2026-01-01'},name)
                url=result.branches[0].url
                self.assertEqual(urlsplit(url).scheme,'https')
                self.assertIn('public',result.branches[0].query)
                if name!='Google':
                    self.assertNotIn('after:2026',result.branches[0].query)
                    self.assertIn('date', ' '.join(result.notes))
                else:self.assertIn('after:2026',result.branches[0].query)

    def test_reject_invalid_domains_dates_and_overlarge_plans(self):
        bad=[({'subject':'x','sites':'http://www.example.com'},'domain'),
             ({'subject':'x','sites':'example.com','exclude_sites':'example.com'},'excluded'),
             ({'subject':'x','before':'2026-02-30'},'date'),
             ({'subject':'x','after':'2026-10-01','before':'2026-01-01'},'later'),
             ({'subject':'x','filetype':'/etc/passwd'},'extension'),
             ({'exact':'"bad quote"'},'quotation')]
        for fields,_ in bad:
            with self.subTest(fields=fields):
                with self.assertRaises(ValueError):d.build_plan(fields)
        with self.assertRaises(ValueError):d.build_plan({'subject':'x','filetype':'pdf,csv,docx'},pack_domains=[f'example{i}.org' for i in range(45)])

    def test_pack_covers_categories_and_generates_selected_queries(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Registry(tmp)
            store.install(PACK)
            packs=d.source_pack_choices(store.active())
            group=packs['adult-public-research::*'][1]
            self.assertGreaterEqual(len(group),45)
            all_queries=d.build_plan({'subject':'public event schedule'},pack_domains=group).branches
            self.assertEqual(len(all_queries),len(group))
            self.assertTrue(all('site:' in item.query for item in all_queries))
            self.assertTrue(all('https://' in item.url for item in all_queries))

    def test_variants_separate_without_query_explosion(self):
        plan=d.build_plan({'subject':'archives','sites':'loc.gov,archives.gov','filetype':'pdf,csv',
                           'variants':'1944, 1945'})
        self.assertEqual(len(plan.branches),8)
        self.assertEqual(len({x.query for x in plan.branches}),8)

    def test_gui_navigates_and_records_opened_query_without_tampering_with_previous_records(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=tk.Tk();root.withdraw()
            app=Workspace(root,tmp)
            try:
                app.record(app.case,'Existing case','original','Verified by human','https://example.org/')
                app.show('Google dorking')
                words=[w.cget('text') for w in walk(app.body) if isinstance(w,tk.Button)]
                self.assertIn('Open selected search',words)
                self.assertIn('Copy selected',words)
                self.assertIn('Save reusable recipe',words)
                self.assertIn('5-minute directions',words)
                app.var('dork.subject').set('archive finding aid')
                app.var('dork.sites').set('loc.gov')
                with patch('fieldindex.browser') as browser:
                    btn=next(w for w in walk(app.body) if isinstance(w,tk.Button) and w.cget('text')=='Open selected search')
                    btn.invoke()
                    browser.assert_called_once()
                entries=app.db.execute('SELECT source,status,query,url FROM records WHERE c=? ORDER BY id',(app.case,)).fetchall()
                self.assertEqual(entries[0][0],'Existing case')
                self.assertEqual(entries[0][1],'Verified by human')
                self.assertEqual(entries[1][0],'Dork / Google')
                self.assertIn('site:loc.gov',entries[1][2])
                self.assertEqual(len(entries),2)
            finally:dispose(app)

    def test_export_import_keeps_saved_dork_recipes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=tk.Tk();root.withdraw()
            app=Workspace(root,tmp)
            try:
                recipe={'fields':{'subject':'Goura history','sites':'loc.gov'},'engine':'Google','pack':'','advanced':'0'}
                with app.db:
                    app.db.execute('INSERT INTO dork_recipes VALUES(?,?,?,?)',
                                   (app.case,'Goura archives',json.dumps(recipe),'2026-11-21T00:00:00Z'))
                archive=Path(tmp)/'case.json'
                with patch('fieldindex.filedialog.asksaveasfilename',return_value=str(archive)):
                    app.export('json')
                data=json.loads(archive.read_text(encoding='utf-8'))
                self.assertEqual(data['dork_recipes'][0][0],'Goura archives')
                with patch('fieldindex.filedialog.askopenfilename',return_value=str(archive)), \
                     patch('fieldindex.simpledialog.askstring',return_value='Imported case'):
                    app.import_case()
                row=app.db.execute('SELECT name,settings FROM dork_recipes WHERE c=?',(app.case,)).fetchone()
                self.assertEqual(row[0],'Goura archives')
                self.assertEqual(json.loads(row[1])['fields']['subject'],'Goura history')
            finally:dispose(app)

    def test_pack_switch_and_saved_recipe_are_case_scoped(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=tk.Tk();root.withdraw()
            app=Workspace(root,tmp)
            try:
                app.extensions.install(PACK)
                app.show('Google dorking')
                app.var('dork.subject').set('public event schedule')
                app.var('dork.pack').set('adult-public-research::*')
                spec={'fields':{'subject':app.var('dork.subject').get()},'engine':'Google',
                      'pack':'adult-public-research::*','advanced':'0'}
                with app.db:
                    app.db.execute('INSERT INTO dork_recipes VALUES(?,?,?,?)',
                                   (app.case,'Public event directories',json.dumps(spec),'2026-11-21T00:00:00Z'))
                    app.db.execute('INSERT INTO cases(name) VALUES(?)',('Second case',))
                self.assertEqual(app.db.execute('SELECT count(*) FROM dork_recipes WHERE c=1').fetchone()[0],1)
                self.assertEqual(app.db.execute('SELECT count(*) FROM dork_recipes WHERE c=2').fetchone()[0],0)
                app.show('Google dorking')
                combo=[x for x in walk(app.body) if isinstance(x, __import__('tkinter.ttk',fromlist=['Combobox']).Combobox)]
                self.assertTrue(any('Public event directories' in x.cget('values') for x in combo))
            finally:dispose(app)


if __name__=='__main__':unittest.main()
