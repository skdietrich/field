"""Extension acceptance, integrity, safe installation and desktop integration."""
import json
import tempfile
import unittest
import zipfile
import tkinter as tk
from pathlib import Path
from unittest.mock import patch
from extensions import Registry, PackError, pack_bytes, make_query
from fieldindex import Workspace

PACKS=Path(__file__).resolve().parent.parent/'ExtensionPacks'


def children(widget):
    for w in widget.winfo_children():
        yield w
        yield from children(w)


def dispose(app):
    for callback in app.root.tk.splitlist(app.root.tk.call('after','info')):
        app.root.after_cancel(callback)
    app.db.close()
    app.root.destroy()


class ExtensionTests(unittest.TestCase):
    def test_bundled_manifests_and_sources(self):
        expected={'adult-public-research':73,'historical-archives':14,'domain-research':16,'holehe-research':3}
        for path in PACKS.glob('*.fipack'):
            data,_=pack_bytes(path)
            self.assertEqual(len(data['sources']),expected[data['id']])
            if data['id'] != 'holehe-research':
                self.assertTrue(data['recipes'])

    def test_install_upgrade_disable_remove_and_db_independence(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Registry(tmp)
            file=PACKS/'adult-public-research.fipack'
            obj=store.install(file)
            self.assertEqual(obj['name'],'Adult public research')
            self.assertEqual(len(store.sources()[0]),73)
            store.enable(obj['id'],False)
            self.assertEqual(store.sources()[0],[])
            store.install(file)
            self.assertFalse(store.installed()[0][1], 'Update preserves disabled setting')
            store.enable(obj['id'],True)
            self.assertEqual(len(store.recipes()),10)
            store.remove(obj['id'])
            self.assertEqual(store.installed(),[])

    def test_invalid_and_path_traversal_zip_fails_without_change(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Registry(tmp)
            store.install(PACKS/'adult-public-research.fipack')
            original=(store.folder/'adult-public-research'/'manifest.json').read_bytes()
            pack=Path(tmp)/'invalid.fipack'
            with zipfile.ZipFile(pack,'w') as f:
                f.writestr('manifest.json',original)
                f.writestr('../out.txt','bad')
            with self.assertRaises(PackError):store.install(pack)
            self.assertEqual((store.folder/'adult-public-research'/'manifest.json').read_bytes(),original)
            data=json.loads(original)
            data['sources'][0]['url']='file:///secret'
            with zipfile.ZipFile(pack,'w') as f:f.writestr('manifest.json',json.dumps(data))
            with self.assertRaises(PackError):store.install(pack)
            self.assertEqual((store.folder/'adult-public-research'/'manifest.json').read_bytes(),original)

    def test_csv_import_and_pack_export(self):
        with tempfile.TemporaryDirectory() as tmp:
            registry=Registry(tmp)
            path=Path(tmp)/'sources.csv'
            path.write_text('name,url,category,region,type,description\nSample,https://www.loc.gov/,Archives,USA,Archive,Public archive\n',encoding='utf-8')
            obj=registry.import_csv(path,'My sources')
            self.assertEqual(obj['id'],'my-sources')
            self.assertEqual(len(registry.sources()[0]),1)
            out=Path(tmp)/'export.fipack'
            registry.export('my-sources',out)
            self.assertEqual(pack_bytes(out)[0]['id'],'my-sources')
            path.write_text('name,url\nPrivate,http://localhost:80/,\n',encoding='utf-8')
            with self.assertRaises(PackError):registry.import_csv(path,'My sources')
            self.assertEqual(len(registry.sources()[0]),1)

    def test_recipe_substitution_and_injection_rejection(self):
        text=make_query('"{topic}" "{region}" club','live shows','Denton')
        self.assertEqual(text,'"live shows" "Denton" club')
        with self.assertRaises(PackError):make_query('{topic.__class__}','test')

    def test_desktop_install_filter_search_and_disable(self):
        with tempfile.TemporaryDirectory() as home:
            root=tk.Tk();root.withdraw()
            app=Workspace(root,home)
            try:
                app.show('Extensions')
                buttons=[w['text'] for w in children(root) if isinstance(w,tk.Button)]
                self.assertIn('Install: Adult public research',buttons)
                next(w for w in children(root) if isinstance(w,tk.Button) and w['text']=='Install: Adult public research').invoke()
                app.show('Community sources')
                count=[w.cget('text') for w in children(app.body) if isinstance(w,tk.Label) and 'entries displayed' in str(w.cget('text'))]
                self.assertEqual(len(count),1)
                self.assertGreaterEqual(int(count[0].split(' of ')[1].split()[0]),85)
                app.show('Extensions')
                self.assertIn('Adult public research',str([w.cget('text') for w in children(app.body) if isinstance(w,tk.Label)]))
                next(w for w in children(root) if isinstance(w,tk.Button) and w['text']=='Disable').invoke()
                self.assertFalse(app.extensions.installed()[0][1])
            finally:dispose(app)

if __name__=='__main__':unittest.main()
