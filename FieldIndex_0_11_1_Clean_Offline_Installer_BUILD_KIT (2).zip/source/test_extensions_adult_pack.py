"""Unit tests for v0.11.0 extension provenance schema, filters, CSV/JSON import, and Texas/International adult pack."""
import json
import tempfile
import unittest
import zipfile
from pathlib import Path

import extensions

PACK_DIR = Path(__file__).resolve().parent.parent / "ExtensionPacks"
ADULT_PACK = PACK_DIR / "adult-public-research.fipack"
ADULT_CSV = PACK_DIR / "adult-public-research-directory.csv"
ADULT_JSON = PACK_DIR / "adult-public-research-directory.json"


class ExtensionsAdultPackV011Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.home = Path(self.tmp.name)
        self.reg = extensions.Registry(self.home)

    def tearDown(self):
        self.tmp.cleanup()

    def test_adult_pack_v2_provenance_texas_and_international_coverage(self):
        installed = self.reg.install(ADULT_PACK)
        self.assertEqual(installed["id"], "adult-public-research")
        self.assertEqual(installed["version"], "2.0.0")
        rows, info = self.reg.sources()
        self.assertEqual(len(rows), 73)
        regions = {meta["country"] for meta in info.values()}
        self.assertIn("United States - Texas", regions)
        self.assertIn("International - Europe", regions)
        dallas = info["https://coletteclubs.com/clubs/dallas"]
        self.assertEqual(dallas["locality"], "Dallas-Fort Worth, TX")
        self.assertEqual(dallas["age_gate"], "21+")
        self.assertEqual(dallas["login_required"], "partial_member_areas")
        self.assertEqual(dallas["reviewed"], "2026-11-21")

    def test_region_and_category_filters_persist_across_reinstall(self):
        self.reg.install(ADULT_PACK)
        all_rows, _ = self.reg.sources()
        self.reg.set_filters(
            "adult-public-research",
            disabled_categories=["Sexual health & relationship education"],
            disabled_regions=["International - Europe"],
        )
        filtered_rows, filtered_info = self.reg.sources()
        self.assertLess(len(filtered_rows), len(all_rows))
        self.assertTrue(all(r[0] != "Sexual health & relationship education" for r in filtered_rows))
        self.assertTrue(all(meta["country"] != "International - Europe" for meta in filtered_info.values()))
        # Re-install preserves filters
        self.reg.install(ADULT_PACK)
        self.assertIn("International - Europe", self.reg.get_filters("adult-public-research")["disabled_regions"])

    def test_reviewed_csv_and_json_directory_imports(self):
        csv_obj = self.reg.import_csv(ADULT_CSV, "Adult CSV Mirror")
        self.assertEqual(len(csv_obj["sources"]), 36)
        json_obj = self.reg.import_json(ADULT_JSON, "Adult JSON Import")
        self.assertEqual(len(json_obj["sources"]), 36)
        self.assertEqual(len(json_obj["recipes"]), 9)

    def test_rejects_python_payload_ip_literals_dangerous_urls_and_zip_bombs(self):
        evil = self.home / "evil.fipack"
        with zipfile.ZipFile(evil, "w") as z:
            z.writestr("manifest.json", ADULT_JSON.read_text(encoding="utf-8"))
            z.writestr("payload.py", "print('nope')")
        with self.assertRaises(extensions.PackError):
            self.reg.install(evil)

        for bad_url in (
            "javascript:alert(1)",
            "file:///C:/Windows/win.ini",
            "http://example.org/",
            "https://user:pass@example.org/",
            "https://127.0.0.1/admin",
            "https://[::1]/admin",
            "https://internal.local/secret",
            "https://example.org:8443/",
        ):
            with self.assertRaises(extensions.PackError, msg=bad_url):
                extensions._web_url(bad_url)

        bomb = self.home / "bomb.fipack"
        with zipfile.ZipFile(bomb, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("manifest.json", " " * (extensions.MAX_FILE + 1024))
        with self.assertRaises(extensions.PackError):
            extensions.pack_bytes(bomb)


if __name__ == "__main__":
    unittest.main(verbosity=2)
