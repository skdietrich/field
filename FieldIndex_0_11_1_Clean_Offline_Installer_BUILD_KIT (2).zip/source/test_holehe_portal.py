import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import holehe_portal as hp

class HoleheValidationTests(unittest.TestCase):
    def test_supported_modes(self):
        self.assertEqual(hp.validate_lookup('Username','@sample.user'), 'sample.user')
        self.assertEqual(hp.validate_lookup('Email','test@example.com'), 'test@example.com')
        self.assertEqual(hp.validate_lookup('Phone','+1 (555) 555-0100'), '+1 (555) 555-0100')
        self.assertEqual(hp.validate_lookup('IP address','2001:db8::1'), '2001:db8::1')
    def test_invalid_inputs(self):
        for kind, value in [('Username', '../foo'), ('Email', 'oops@@example.com'), ('Phone', 'abc'), ('IP address', '256.256.5.5'), ('Email','bad\n@example.org')]:
            with self.subTest(kind=kind,value=value), self.assertRaises(ValueError):
                hp.validate_lookup(kind,value)
    def test_provider_origins_not_interchangeable(self):
        self.assertEqual(hp.WEB_PORTAL,'https://holehe.org/')
        self.assertNotEqual(hp.WEB_PORTAL,hp.ORIGINAL_CLI)
    def test_pack_contract(self):
        from extensions import pack_bytes
        obj,raw=pack_bytes(Path(__file__).resolve().parent.parent/'ExtensionPacks'/'holehe-research.fipack')
        self.assertEqual(obj['id'],'holehe-research')
        self.assertEqual(len(obj['sources']),3)
    @unittest.skipUnless(os.environ.get('DISPLAY'), 'Requires graphical desktop')
    def test_manual_lookups_require_action_and_save_unverified_status(self):
        import tkinter as tk
        from fieldindex import Workspace
        def all_widgets(w):
            for x in w.winfo_children():
                yield x
                yield from all_widgets(x)
        with tempfile.TemporaryDirectory() as tmp, patch('fieldindex.browser') as browser, patch('fieldindex.messagebox.askyesno',return_value=True):
            root=tk.Tk()
            try:
                app=Workspace(root,folder=tmp)
                app.show('Holehe OSINT')
                box=next(x for x in all_widgets(app.body) if isinstance(x,tk.Entry))
                box.insert(0,'selftest')
                root.update()
                self.assertEqual(app.db.execute('SELECT count(*) FROM records').fetchone()[0],0)
                button=next(x for x in all_widgets(app.body) if isinstance(x,tk.Button) and x.cget('text')=='Copy lookup + open Holehe.org')
                button.invoke()
                browser.assert_called_once_with(hp.WEB_PORTAL)
                self.assertEqual(app.db.execute('SELECT count(*) FROM records').fetchone()[0],0)
                save=next(x for x in all_widgets(app.body) if isinstance(x,tk.Button) and x.cget('text')=='Save unverified reference to Evidence')
                save.invoke()
                row=app.db.execute('SELECT query,status,note FROM records WHERE c=?',(app.case,)).fetchone()
                self.assertEqual(row[0],'selftest')
                self.assertEqual(row[1],'Manual lookup pending')
                self.assertIn('not imported or verified',row[2])
                for after_id in root.tk.splitlist(root.tk.call('after','info')):
                    root.after_cancel(after_id)
                app.db.close()
            finally:
                root.destroy()

    @unittest.skipUnless(os.environ.get('DISPLAY'), 'Requires graphical desktop')
    def test_workspace_open_does_not_open_browser(self):
        import tkinter as tk
        from fieldindex import Workspace
        with tempfile.TemporaryDirectory() as tmp, patch('fieldindex.browser') as browser:
            root=tk.Tk()
            try:
                app=Workspace(root,folder=tmp)
                app.show('Holehe OSINT')
                root.update()
                self.assertEqual(app.view,'Holehe OSINT')
                self.assertFalse(browser.called)
                self.assertEqual(app.db.execute('SELECT count(*) FROM records').fetchone()[0],0)
                for after_id in root.tk.splitlist(root.tk.call('after','info')):
                    root.after_cancel(after_id)
                app.db.close()
            finally:
                root.destroy()

if __name__=='__main__':
    unittest.main()
