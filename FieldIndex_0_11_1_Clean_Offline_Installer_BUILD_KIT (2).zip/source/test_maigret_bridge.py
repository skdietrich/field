"""Unit and simulated GUI integration tests for uncapped Maigret CLI bridge (no live network)."""
import json
import tempfile
import threading
import time
import tkinter as tk
import unittest
from pathlib import Path
from unittest.mock import patch

import engine
import maigret_bridge as mb
from process_runner import ToolCancelled
from fieldindex import Workspace

SAMPLE_SIMPLE_JSON = {
    "GitHub": {
        "url_user": "https://github.com/example_researcher",
        "http_status": 200,
        "status": {
            "site_name": "GitHub",
            "status": "Claimed",
            "url": "https://github.com/example_researcher",
            "query_time": 0.41,
            "tags": ["coding", "us"],
        },
    },
    "BlockedSite": {
        "url_user": "https://blocked.example/u/example_researcher",
        "http_status": 403,
        "status": {
            "site_name": "BlockedSite",
            "status": "Available",
            "context": "Cloudflare WAF challenge",
        },
    },
    "ThrottledSite": {
        "url_user": "https://throttled.example/u/example_researcher",
        "http_status": 429,
        "status": {
            "site_name": "ThrottledSite",
            "status": "Unknown",
            "context": "Too many requests",
        },
    },
    "TimedOutSite": {
        "url_user": "https://slow.example/u/example_researcher",
        "http_status": "",
        "status": {
            "site_name": "TimedOutSite",
            "status": "Unknown",
            "context": "Connection timed out",
        },
    },
    "OpenArchive": {
        "url_user": "https://archive.example/u/example_researcher",
        "http_status": 404,
        "status": {
            "site_name": "OpenArchive",
            "status": "Available",
        },
    },
}


class MaigretBridgeTests(unittest.TestCase):
    def test_username_validation_and_executable_discovery(self):
        self.assertEqual(mb.validate_username(" @sample_user "), "sample_user")
        for bad in ("", "user@example.org", "has space", "../bad", "a" * 65, ";whoami"):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                mb.validate_username(bad)
        with tempfile.TemporaryDirectory() as tmp:
            standalone = Path(tmp) / "tools" / "maigret" / "maigret_standalone.exe"
            standalone.parent.mkdir(parents=True)
            standalone.write_bytes(b"MZ")
            self.assertEqual(mb.find_executable(base=tmp, which=lambda _: None), str(standalone))
            venv_exe = Path(tmp) / "tools" / "maigret" / ".venv" / "Scripts" / "maigret.exe"
            venv_exe.parent.mkdir(parents=True)
            venv_exe.write_bytes(b"MZ")
            self.assertEqual(mb.find_executable(base=tmp, which=lambda _: None), str(venv_exe))

    def test_parse_simple_json_never_calls_blocked_or_throttled_no_account(self):
        with tempfile.TemporaryDirectory() as tmp:
            rep = Path(tmp) / "report_example_researcher_simple.json"
            rep.write_text(json.dumps(SAMPLE_SIMPLE_JSON), encoding="utf-8")
            rows, counts = mb.parse_json_report(rep, "example_researcher", include_unconfirmed=False)
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0][2], "Maigret-reported public profile")
            self.assertEqual(counts["attempted"], 5)
            self.assertEqual(counts["claimed"], 1)
            self.assertEqual(counts["blocked"], 1)
            self.assertEqual(counts["rate_limited"], 1)
            self.assertEqual(counts["timed_out"], 1)
            self.assertEqual(counts["not_found"], 1)

            verbose, _ = mb.parse_json_report(rep, "example_researcher", include_unconfirmed=True)
            statuses = {r[2] for r in verbose}
            self.assertIn("Blocked / auth required", statuses)
            self.assertIn("Rate limited", statuses)
            self.assertIn("Timed out", statuses)
            self.assertIn("No profile reported", statuses)

    def test_parse_ndjson_and_txt_fallback_and_malformed_json(self):
        with tempfile.TemporaryDirectory() as tmp:
            nd = Path(tmp) / "out.json"
            nd.write_text(
                json.dumps({"sitename": "Codeberg", "url_user": "https://codeberg.org/alpha", "status": {"status": "Claimed"}}) + "\n"
                + json.dumps({"sitename": "Blocked", "url_user": "https://b.example/alpha", "http_status": 403, "status": {"status": "WAF"}}) + "\n",
                encoding="utf-8",
            )
            rows, counts = mb.parse_json_report(nd, "alpha")
            self.assertEqual(len(rows), 1)
            self.assertEqual(counts["blocked"], 1)

            txt = Path(tmp) / "fallback.txt"
            txt.write_text("[+] https://example.org/alpha\n[+] https://archive.example/alpha\n", encoding="utf-8")
            trows, tcounts = mb.parse_txt_report(txt, "alpha")
            self.assertEqual(len(trows), 2)
            self.assertEqual(tcounts["claimed"], 2)

            bad = Path(tmp) / "bad.json"
            bad.write_text("{not valid json", encoding="utf-8")
            with self.assertRaises(ValueError):
                mb.parse_json_report(bad, "alpha")

    def test_scan_modes_full_all_sites_tags_legacy_cancel_timeout_and_malformed(self):
        seen_cmds = []

        def fake_json_run(cmd, **kwargs):
            seen_cmds.append(cmd)
            Path(kwargs["cwd"], "report_alpha_simple.json").write_text(json.dumps(SAMPLE_SIMPLE_JSON), encoding="utf-8")
            return (0, "OK")

        # Default top-500 scan (NO artificial 3-site cap!)
        rows = mb.scan("alpha", executable="/mock/maigret", runner=fake_json_run)
        self.assertNotIn("--site", seen_cmds[-1])
        self.assertIn("--top-sites", seen_cmds[-1])
        self.assertIn("--json", seen_cmds[-1])
        self.assertTrue(any(r[2] == "Maigret-reported public profile" for r in rows))
        self.assertTrue(any(r[2] == "Scan coverage summary" and "blocked=1" in r[4] for r in rows))

        # All-sites (-a) mode
        mb.scan("alpha", all_sites=True, executable="/mock/maigret", runner=fake_json_run)
        self.assertIn("-a", seen_cmds[-1])
        self.assertNotIn("--site", seen_cmds[-1])

        # Tag-filtered mode
        mb.scan("alpha", tags=["us", "dating"], executable="/mock/maigret", runner=fake_json_run)
        self.assertIn("--tags", seen_cmds[-1])
        self.assertIn("us,dating", seen_cmds[-1])

        # Explicit legacy 3-site compat mode
        mb.scan("alpha", legacy_three_sites=True, executable="/mock/maigret", runner=fake_json_run)
        self.assertEqual(seen_cmds[-1].count("--site"), 3)

        # Cancelled scan
        def raise_cancel(cmd, **kwargs):
            raise ToolCancelled("Cancelled by researcher")
        crows = mb.scan("alpha", executable="/mock/maigret", runner=raise_cancel)
        self.assertEqual(crows[0][2], "Cancelled")

        # Timeout scan
        def raise_timeout(cmd, **kwargs):
            raise TimeoutError("deadline")
        trows = mb.scan("alpha", executable="/mock/maigret", runner=raise_timeout)
        self.assertEqual(trows[0][2], "Timed out")

        # Malformed report from CLI
        def write_bad(cmd, **kwargs):
            Path(kwargs["cwd"], "bad.json").write_text("{{{corrupt", encoding="utf-8")
            return (0, "")
        mrows = mb.scan("alpha", executable="/mock/maigret", runner=write_bad)
        self.assertEqual(mrows[0][2], "Malformed tool report")

        # Capability probing
        def fake_probe(cmd, **kwargs):
            if "--version" in cmd:
                return (0, "maigret 0.6.1")
            return (0, "--json --tags --site --top-sites -a, --all-sites --folderoutput --no-recursion --timeout --txt --no-color")
        caps = mb.probe_capabilities("/mock/maigret", runner=fake_probe)
        self.assertTrue(caps["installed"])
        self.assertEqual(caps["version"], "maigret 0.6.1")
        self.assertTrue(caps["flags"]["json"] and caps["flags"]["all_sites"] and caps["flags"]["tags"])

    def test_engine_dispatches_full_maigret_and_gui_screen_saves_leads(self):
        expected = [("Maigret", "alpha", "Maigret-reported public profile", "https://example.org/alpha", "unverified")]
        with patch("maigret_bridge.scan", return_value=expected) as mocked:
            self.assertEqual(engine.run_source(("maigret", "alpha", "Local tool", True)), expected)
            mocked.assert_called_once()

        with tempfile.TemporaryDirectory() as tmp:
            root = tk.Tk(); root.withdraw()
            app = Workspace(root, tmp)
            try:
                app.var("maigret.username").set("alpha")
                with patch("maigret_bridge.find_executable", return_value="/mock/maigret"):
                    app.show("Maigret")
                def walk(widget):
                    yield widget
                    for child in widget.winfo_children():
                        yield from walk(child)
                start = next(w for w in walk(root) if isinstance(w, tk.Button) and w.cget("text") == "Run full Maigret scan")
                with patch("maigret_bridge.scan", return_value=expected):
                    start.invoke()
                    for _ in range(100):
                        root.update()
                        if not app.running:
                            break
                        time.sleep(0.02)
                rows = app.db.execute("SELECT source,query,status,url,note FROM records WHERE c=?", (app.case,)).fetchall()
                self.assertEqual(rows, expected)
            finally:
                for cb in app.root.tk.splitlist(app.root.tk.call("after", "info")):
                    app.root.after_cancel(cb)
                app.db.close(); root.destroy()


if __name__ == "__main__":
    unittest.main(verbosity=2)
