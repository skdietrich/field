"""Sherlock integration tests with simulated tool outputs; no network calls."""
import tempfile
import unittest
import time
from pathlib import Path
from unittest.mock import patch
import tkinter as tk
import sherlock_bridge as sb
import engine
from fieldindex import Workspace

CSV = '''username,name,url_main,url_user,exists,http_status,response_time_s\nalpha,Example,https://example.org,https://example.org/alpha,QueryStatus.CLAIMED,200,0.2\nalpha,Another,https://another.example,https://another.example/alpha,QueryStatus.AVAILABLE,404,0.3\nalpha,Unavailable,https://unavailable.example,https://unavailable.example/alpha,QueryStatus.UNKNOWN,,\n'''

class SherlockIntegrationTests(unittest.TestCase):
    def test_username_validation(self):
        self.assertEqual(sb.validate_username(' @public.handle '),'public.handle')
        for bad in ('','john@example.org','two words','../escape','a'*65,';danger'):
            with self.subTest(bad=bad),self.assertRaises(ValueError):sb.validate_username(bad)

    def test_report_keeps_only_unverified_leads_by_default(self):
        with tempfile.TemporaryDirectory() as tmp:
            report=Path(tmp)/'alpha.csv';report.write_text(CSV)
            rows=sb.parse_report(report,'alpha')
            self.assertEqual(len(rows),1)
            self.assertEqual(rows[0][2],'Sherlock-reported public profile')
            self.assertIn('independently verify',rows[0][4])
            self.assertEqual(len(sb.parse_report(report,'alpha',include_unconfirmed=True)),3)

    def test_report_does_not_accept_fake_data(self):
        with tempfile.TemporaryDirectory() as tmp:
            report=Path(tmp)/'bad.csv';report.write_text('url,exists\nhttps://example.com,CLAIMED\n')
            with self.assertRaises(ValueError):sb.parse_report(report,'alpha')

    def test_scan_no_three_site_cap_and_adult_opt_in(self):
        commands=[]
        def fake_run(cmd,**kwargs):
            commands.append(cmd)
            Path(kwargs['cwd'],'alpha.csv').write_text(CSV)
            return (0,'OK')
        rows=sb.scan('alpha',executable='/mock/sherlock',runner=fake_run,nsfw=True)
        self.assertEqual(len(rows),1)
        self.assertIn('--nsfw',commands[0])
        self.assertNotIn('--site',commands[0])
        commands.clear()
        sb.scan('alpha',executable='/mock/sherlock',runner=fake_run,sites=['GitHub','Reddit'])
        self.assertEqual(commands[0].count('--site'),2)
        self.assertNotIn('--nsfw',commands[0])

    def test_missing_installer_and_malformed_results_propagate(self):
        with patch('sherlock_bridge.find_executable',return_value=None):
            rows=sb.scan('alpha')
        self.assertEqual(rows[0][2],'Source unavailable')
        def no_report(cmd,**kwargs):return (2,'problem')
        rows=sb.scan('alpha',executable='/mock/sherlock',runner=no_report)
        self.assertEqual(rows[0][2],'Source unavailable')
        self.assertIn('Exit code 2',rows[0][4])

    def test_engine_dispatches_full_sherlock(self):
        expected=[('Sherlock','alpha','Sherlock-reported public profile','https://example.org/alpha','unverified')]
        with patch('sherlock_bridge.scan',return_value=expected) as mocked:
            self.assertEqual(engine.run_source(('sherlock','alpha','Local tool',True)), expected)
            mocked.assert_called_once()

    def test_managed_tool_discovery(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'tools'/'sherlock'/'.venv'/'Scripts'/'sherlock.exe'
            path.parent.mkdir(parents=True)
            path.write_bytes(b'test')
            self.assertEqual(sb.find_executable(base=tmp,which=lambda _:None),str(path))

    def test_gui_runs_and_saves_unverified_findings(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=tk.Tk();root.withdraw()
            app=Workspace(root,tmp)
            try:
                app.var('sherlock.username').set('alpha')
                app.show('Sherlock')
                def walk(widget):
                    yield widget
                    for child in widget.winfo_children(): yield from walk(child)
                start=next(w for w in walk(root) if isinstance(w,tk.Button) and w.cget('text')=='Run full Sherlock scan')
                findings=[('Sherlock','alpha','Sherlock-reported public profile','https://example.org/alpha','Unverified automated lead')]
                with patch('sherlock_bridge.scan',return_value=findings):
                    start.invoke()
                    for _ in range(100):
                        root.update()
                        if not app.running:break
                        time.sleep(.02)
                rows=app.db.execute("SELECT source,query,status,url,note FROM records WHERE c=?",(app.case,)).fetchall()
                self.assertEqual(rows,findings)
            finally:
                for cb in app.root.tk.splitlist(app.root.tk.call('after','info')):
                    app.root.after_cancel(cb)
                app.db.close();root.destroy()

    def test_ui_sherlock_screen_and_case_database(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=tk.Tk();root.withdraw()
            app=Workspace(root,tmp)
            try:
                with patch('sherlock_bridge.find_executable',return_value='/mock/sherlock'):
                    app.show('Sherlock')
                self.assertEqual(app.view,'Sherlock')
                def walk(widget):
                    yield widget
                    for child in widget.winfo_children(): yield from walk(child)
                buttons=[w.cget('text') for w in walk(root) if isinstance(w,tk.Button)]
                self.assertIn('Run full Sherlock scan',buttons)
                self.assertIn('Install / repair Sherlock',buttons)
                self.assertIn('Cancel Sherlock',buttons)
                self.assertEqual(app.db.execute('SELECT COUNT(*) FROM records').fetchone()[0],0)
            finally:
                for cb in app.root.tk.splitlist(app.root.tk.call('after','info')):
                    app.root.after_cancel(cb)
                app.db.close();root.destroy()

if __name__=='__main__':unittest.main()
