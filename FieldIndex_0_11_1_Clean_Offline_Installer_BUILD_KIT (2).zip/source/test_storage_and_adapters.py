"""Tests for migrations (v0.6/v0.10 -> v8), provenance reviews, adapters, dorking hardening, capture extension, and Unicode."""
import json
import sqlite3
import tempfile
import tkinter as tk
import unittest
from pathlib import Path
from unittest.mock import patch

import adapters
import discovery
import dork_search as ds
import sherlock_bridge as sb
import storage
from fieldindex import Workspace

ROOT = Path(__file__).resolve().parent
FIXTURE = ROOT.parent / "SAMPLES" / "fictional_research_fixture.json"


class StorageAdaptersAndRegressionTests(unittest.TestCase):
    def test_v06_and_v010_database_migrations_preserve_all_existing_data(self):
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "cases.sqlite3"
            # Construct a real v0.6-era schema with Greek & German Unicode records
            conn = sqlite3.connect(db_path)
            conn.executescript("""
                CREATE TABLE cases(id INTEGER PRIMARY KEY, name TEXT UNIQUE);
                CREATE TABLE fields(c INTEGER, k TEXT, v TEXT, PRIMARY KEY(c, k));
                CREATE TABLE records(id INTEGER PRIMARY KEY, c INTEGER, time TEXT, source TEXT, query TEXT, status TEXT, url TEXT, note TEXT);
                INSERT INTO cases VALUES(1, 'Αρχείο Φενεού / München');
                INSERT INTO fields VALUES(1, 'subject', 'Γκούρα / Feneos');
                INSERT INTO records VALUES(1, 1, '2026-05-01T10:00:00+00:00', 'Library of Congress', 'Γκούρα', 'Catalogue record', 'https://www.loc.gov/item/1', 'Original Greek record: Φενεός');
            """)
            conn.close()

            conn2 = sqlite3.connect(db_path)
            applied = storage.apply_migrations(conn2)
            self.assertEqual(applied, [6, 7, 8])
            # Re-running migrations is idempotent
            self.assertEqual(storage.apply_migrations(conn2), [])
            # Verify legacy Unicode data intact
            case_name = conn2.execute("SELECT name FROM cases WHERE id=1").fetchone()[0]
            self.assertEqual(case_name, "Αρχείο Φενεού / München")
            orig_note = conn2.execute("SELECT note FROM records WHERE id=1").fetchone()[0]
            self.assertIn("Φενεός", orig_note)

            # Save editable review without mutating original record
            storage.save_review(
                conn2,
                1,
                "Same handle — identity not established",
                published_date="1944-05-12",
                event_date="1944-05-10",
                counterevidence="Common regional surname; needs primary corroboration.",
            )
            self.assertEqual(conn2.execute("SELECT note FROM records WHERE id=1").fetchone()[0], orig_note)
            rev = storage.get_review(conn2, 1)
            self.assertEqual(rev["decision"], "Same handle — identity not established")
            self.assertEqual(rev["event_date"], "1944-05-10")

            # Verify atomic backup integrity
            bkp = storage.atomic_backup(conn2, Path(tmp) / "backup.sqlite3")
            bconn = sqlite3.connect(bkp)
            self.assertEqual(bconn.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            self.assertEqual(bconn.execute("SELECT decision FROM evidence_reviews WHERE record=1").fetchone()[0], "Same handle — identity not established")
            bconn.close()

            # Verify Markdown report generation
            with conn2:
                conn2.execute(
                    "INSERT INTO case_hypotheses(c,claim,status,supporting,contradicting,missing_evidence,updated_utc) VALUES(?,?,?,?,?,?,?)",
                    (1, "Handle belongs to subject", "Open — needs corroboration", "One public profile", "Common alias", "Primary verification", storage.utc_now()),
                )
            md = storage.generate_report_markdown(conn2, 1)
            self.assertIn("Αρχείο Φενεού / München", md)
            self.assertIn("never proof of real-world identity", md)
            self.assertIn("1944-05-10", md)
            self.assertIn("Common regional surname", md)
            conn2.close()

    def test_fictional_fixture_and_source_overlap_deduplication(self):
        data = json.loads(FIXTURE.read_text(encoding="utf-8"))
        # Verify fixture expectations with normalized outcome categories
        normalized = [adapters.normalize_outcome(obs["status"]) for obs in data["observations"]]
        self.assertEqual(normalized.count("candidate_public_page"), data["expected"]["public_page_observations"])
        self.assertEqual(normalized.count("blocked/auth"), data["expected"]["blocked"])
        self.assertEqual(normalized.count("verified_public_page"), data["expected"]["confirmed_real_world_identities"])

        # Overlapping Sherlock + Maigret + GitHub API on same URL must NOT be 3 independent proofs
        records = [
            ("2026-11-21T01:00:00Z", "Sherlock", "example_researcher", "Sherlock-reported public profile", "https://github.com/example_researcher", "Sherlock hit"),
            ("2026-11-21T01:05:00Z", "Maigret", "example_researcher", "Maigret-reported public profile", "https://www.github.com/example_researcher/", "Maigret hit"),
            ("2026-11-21T01:10:00Z", "GitHub", "example_researcher", "Handle match", "https://github.com/example_researcher", "API hit"),
        ]
        deduped = adapters.deduplicate_observations(records)
        self.assertEqual(len(deduped), 1)
        self.assertTrue(deduped[0]["overlapping_tools"])
        self.assertEqual(deduped[0]["adapters"], ["GitHub", "Maigret", "Sherlock"])
        self.assertIn("NOT independent", deduped[0]["independence_note"])

        # discovery.grouped_records MUST retain Sherlock & Maigret full-scan leads (regression fix)
        grouped = discovery.grouped_records([
            ("2026-11-21T01:00:00Z", "Sherlock", "alpha", "Sherlock-reported public profile", "https://example.org/alpha", "S"),
            ("2026-11-21T01:01:00Z", "Maigret", "alpha", "Maigret-reported public profile", "https://example.org/alpha", "M"),
        ])
        self.assertEqual(len(grouped), 1)
        self.assertTrue(grouped[0]["overlapping_tools"])

    def test_sherlock_capability_probe_and_blocked_rate_limit_classification(self):
        with tempfile.TemporaryDirectory() as tmp:
            rep = Path(tmp) / "alpha.csv"
            rep.write_text(
                "username,name,url_main,url_user,exists,http_status,response_time_s\n"
                "alpha,One,https://one.example,https://one.example/alpha,QueryStatus.CLAIMED,200,0.2\n"
                "alpha,Two,https://two.example,https://two.example/alpha,QueryStatus.UNKNOWN,403,0.4\n"
                "alpha,Three,https://three.example,https://three.example/alpha,QueryStatus.UNKNOWN,429,0.5\n"
                "alpha,Four,https://four.example,https://four.example/alpha,QueryStatus.AVAILABLE,404,0.1\n",
                encoding="utf-8",
            )
            counts = sb.summarize_report(rep)
            self.assertEqual(counts["attempted"], 4)
            self.assertEqual(counts["claimed"], 1)
            self.assertEqual(counts["blocked"], 1)
            self.assertEqual(counts["rate_limited"], 1)
            self.assertEqual(counts["available"], 1)

            def fake_no_nsfw(cmd, **kwargs):
                if "--version" in cmd:
                    return (0, "sherlock 0.14.0")
                return (0, "--csv --site --timeout --folderoutput")
            res = sb.scan("alpha", nsfw=True, executable="/mock/sherlock", check_capabilities=True, runner=fake_no_nsfw)
            self.assertEqual(res[0][2], "Source unavailable")
            self.assertIn("--nsfw", res[0][4])

    def test_dork_search_idn_quotes_and_disclosure_warning(self):
        self.assertEqual(ds.search_domain("münchen.de"), "xn--mnchen-3ya.de")
        with self.assertRaises(ValueError):
            ds.build_plan({"any": 'bad"token'})
        self.assertTrue(ds.disclosure_warning('site:example.org "person@example.org"'))
        self.assertTrue(ds.disclosure_warning('"+1 (214) 555-0199"'))
        self.assertEqual(ds.disclosure_warning('site:loc.gov "oral history"'), "")

    def test_restored_browser_capture_extension_files_present_and_valid(self):
        cap = ROOT / "capture"
        manifest = json.loads((cap / "manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["manifest_version"], 3)
        self.assertTrue((cap / "capture.html").is_file())
        js = (cap / "capture.js").read_text(encoding="utf-8")
        self.assertIn("fieldindex.capture.v1", js)

    def test_import_case_name_shadow_fix_with_dork_recipes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = tk.Tk(); root.withdraw()
            app = Workspace(root, tmp)
            try:
                recipe = {"fields": {"subject": "Archives"}, "engine": "Google", "pack": "", "advanced": "0"}
                with app.db:
                    app.db.execute("INSERT INTO dork_recipes VALUES(?,?,?,?)", (app.case, "RecipeNameShouldNotShadowCase", json.dumps(recipe), "2026-11-21T00:00:00Z"))
                out = Path(tmp) / "export.json"
                with patch("fieldindex.filedialog.asksaveasfilename", return_value=str(out)):
                    app.export("json")
                with patch("fieldindex.filedialog.askopenfilename", return_value=str(out)), \
                     patch("fieldindex.simpledialog.askstring", return_value="Real Case Title"):
                    app.import_case()
                self.assertEqual(app.status.get(), "Imported case into Real Case Title")
            finally:
                for cb in app.root.tk.splitlist(app.root.tk.call("after", "info")):
                    app.root.after_cancel(cb)
                app.db.close(); root.destroy()


if __name__ == "__main__":
    unittest.main(verbosity=2)
