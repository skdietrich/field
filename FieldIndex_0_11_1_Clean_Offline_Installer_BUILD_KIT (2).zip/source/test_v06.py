"""Regression checks for the 0.6 integration."""
import json
import sqlite3
import sys
import tempfile
import threading
import time
import tkinter as tk
import unittest
from pathlib import Path
from unittest.mock import patch
import discovery
import engine
from fieldindex import Workspace
from process_runner import run_command, ToolCancelled

def children(widget):
    for child in widget.winfo_children():
        yield child
        yield from children(child)

def press(root,label):
    next(w for w in children(root) if isinstance(w,tk.Button) and w["text"]==label).invoke()

def dispose(app):
    for cb in app.root.tk.splitlist(app.root.tk.call("after","info")):
        app.root.after_cancel(cb)
    app.db.close()
    app.root.destroy()

class IntegrationTests(unittest.TestCase):
    def test_multi_domain_queries_and_dates(self):
        spec=dict(terms="public history",site="loc.gov,archives.gov",file="pdf,docx",
                  after="2000-01-01",before="2020-01-01",title="oral history",other="Goura,Gkoura")
        google=engine.queries(spec,3)
        self.assertEqual(len(google),8)
        self.assertTrue(all('intitle:"oral history"' in q for q in google))
        translated,notes=engine.provider_queries(spec,3,"DuckDuckGo")
        self.assertEqual(len(translated),8)
        self.assertTrue(all("after:" not in q and "before:" not in q for q in translated))
        self.assertTrue(notes)
        with self.assertRaises(ValueError):engine.provider_queries(dict(spec,before="1999-01-01"),3,"DuckDuckGo")
        with self.assertRaises(ValueError):engine.queries(dict(spec,skip="gov,loc.gov"),3)
    def test_actual_large_output_and_cancellation(self):
        code,tail=run_command([sys.executable,"-c","import sys;sys.stdout.write('x'*2000000);print('END')"],timeout=5)
        self.assertEqual(code,0);self.assertTrue(tail.rstrip().endswith("END"));self.assertLessEqual(len(tail),32000)
        cancelled=threading.Event();timer=threading.Timer(.2,cancelled.set);timer.start()
        try:
            with self.assertRaises(ToolCancelled):run_command([sys.executable,"-c","import time;time.sleep(30)"],cancel=cancelled,timeout=5)
        finally:timer.join()
        with self.assertRaises(TimeoutError):run_command([sys.executable,"-c","import time;time.sleep(30)"],timeout=.1)
    def test_provenance_keeps_query_identity(self):
        self.assertNotEqual(discovery.canonical("https://news.example/user?id=one"),discovery.canonical("https://news.example/user?id=two"))
        self.assertEqual(discovery.canonical("https://example.org:443/item"),"https://example.org/item")
        self.assertEqual(discovery.canonical("https://example.org:bad/item"),"")
        records=[
            ("2026-01-01","First","test","Indexed result","https://example.org/?id=one","A"),
            ("2026-01-02","Second","test","No record returned","https://example.org/?id=one","B"),
            ("2026-01-03","Third","test","Indexed result","https://example.org/?id=two","C")]
        groups=discovery.grouped_records(records)
        self.assertEqual(len(groups),2);self.assertEqual(len(groups[0]["observations"]),2)
        self.assertEqual(groups[0]["sources"],["First","Second"])
    def test_ui_query_review_and_retry_after_restart(self):
        with tempfile.TemporaryDirectory() as folder:
            root=tk.Tk();root.withdraw();app=Workspace(root,folder)
            try:
                app.var("mode").set("God Mode")
                for k,v in {"terms":"Feneos","site":"loc.gov,archives.gov","file":"pdf,docx"}.items():app.var("g."+k).set(v)
                app.show("Google builder");press(root,"Review and send")
                popup=next(w for w in root.winfo_children() if isinstance(w,tk.Toplevel))
                self.assertEqual(next(w for w in children(popup) if isinstance(w,tk.Listbox)).size(),4)
                with patch("fieldindex.filedialog.asksaveasfilename",return_value=folder+"/queries.json"):press(popup,"Export query plan")
                self.assertEqual(len(json.loads(Path(folder+"/queries.json").read_text())["branches"]),4)
                popup.destroy()
                app.start_plan([("Google","Public history","Browser search",True)])
                for _ in range(100):
                    root.update();time.sleep(.01)
                    if not app.active_plans:break
                self.assertEqual(app.db.execute("SELECT completed FROM run_routes").fetchone()[0],1)
                # Simulate an interrupted route in a previously stored run.
                with app.db:app.db.execute("UPDATE run_routes SET completed=0")
            finally:dispose(app)
            root=tk.Tk();root.withdraw();app=Workspace(root,folder)
            try:
                app.show("Investigation plan");press(root,"Retry failed or unfinished sources")
                for _ in range(100):
                    root.update();time.sleep(.01)
                    if not app.active_plans:break
                self.assertEqual(app.db.execute("SELECT count(*) FROM runs").fetchone()[0],2)
                self.assertEqual(app.db.execute("SELECT count(*) FROM schema_migrations WHERE version=6").fetchone()[0],1)
                self.assertEqual(app.db.execute("SELECT completed FROM run_routes ORDER BY run DESC").fetchone()[0],1)
            finally:dispose(app)
    def test_bad_import_rolls_back(self):
        with tempfile.TemporaryDirectory() as folder:
            root=tk.Tk();root.withdraw();app=Workspace(root,folder)
            try:
                payload={"case":"Corrupt","entries":[{"utc":"now","source":"s","query":"q","outcome":"Indexed result","url":"","original_record":"x","research_notes":None}]}
                path=Path(folder)/"bad.json";path.write_text(json.dumps(payload))
                with patch("fieldindex.filedialog.askopenfilename",return_value=str(path)),patch("fieldindex.simpledialog.askstring",return_value="Corrupt"),patch("fieldindex.messagebox.showerror") as error:
                    app.import_case();self.assertTrue(error.called)
                self.assertEqual(app.db.execute("SELECT count(*) FROM cases").fetchone()[0],1)
                self.assertEqual(app.db.execute("SELECT count(*) FROM records").fetchone()[0],0)
            finally:dispose(app)

if __name__=="__main__":unittest.main()

