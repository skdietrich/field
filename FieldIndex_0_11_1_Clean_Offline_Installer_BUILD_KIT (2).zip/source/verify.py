"""Offline regression and Windows UI smoke tests. No case data leaves the machine."""
import json
import tempfile
import tkinter as tk
import unittest
from unittest.mock import patch
from urllib.error import HTTPError
import engine
from fieldindex import Workspace,NAV

class ResearchTests(unittest.TestCase):
    def test_one_run_with_partial_failure_and_case_switch(self):
        import time
        from tkinter import ttk
        def walk(widget):
            for w in widget.winfo_children():
                yield w
                yield from walk(w)
        def click(root,text):
            next(w for w in walk(root) if isinstance(w,tk.Button) and w["text"]==text).invoke()
        with tempfile.TemporaryDirectory() as folder:
            root=tk.Tk();root.withdraw();app=Workspace(root,folder)
            next(w for w in walk(app.body) if isinstance(w,tk.Entry)).insert(0,"foxyeve@example.org")
            def response(name,user):
                self.assertEqual(user,"foxyeve")
                if name=="GitLab":raise OSError("Offline fixture")
                return "Handle match","https://example.org/"+user
            fixture='<a class="result__a" href="https://example.org/public">Test article</a>'
            with patch.dict("os.environ",{"BRAVE_SEARCH_API_KEY":""}),patch("discovery.read",return_value=fixture),patch("engine.shutil.which",return_value=None),patch("engine.lookup",side_effect=response):
                click(root,"Build investigation plan")
                self.assertEqual(app.view,"Investigation plan")
                with patch("fieldindex.browser") as browser:
                    click(root,"Search full address in Google")
                    browser.assert_called_once_with("https://www.google.com/search?q=%22foxyeve%40example.org%22")
                click(root,"Run selected plan")
                with patch("fieldindex.simpledialog.askstring",return_value="Unrelated"):app.new_case()
                for _ in range(100):
                    root.update();time.sleep(.01)
                    if not app.active_plans:break
            statuses=list(app.db.execute("SELECT c,query,status FROM records JOIN run_records ON record=id"))
            self.assertEqual(len(statuses),12)
            self.assertIn((1,'"foxyeve@example.org"',"Prepared browser search"),statuses)
            self.assertIn((1,'"foxyeve@example.org"',"Indexed result"),statuses)
            self.assertTrue(all(c==1 and q=="foxyeve" for c,q,s in statuses if s not in ("Prepared browser search","Indexed result")))
            self.assertEqual(sum(status=="Source unavailable" for _,_,status in statuses),1)
            self.assertEqual(sum(status=="Handle match" for _,_,status in statuses),9)
            for callback in root.tk.splitlist(root.tk.call('after','info')):root.after_cancel(callback)
            app.db.close();root.destroy()
    def test_handle_contracts(self):
        for source,(_,_,key) in engine.PROVIDERS.items():
            with self.subTest(source=source):
                record={key:"TestHandle"}
                replies={"GitLab":[record],"Keybase":{"status":{"code":0},"them":[{"basics":record}]},"English Wikipedia":{"query":{"users":[record]}}}
                with patch("engine.fetch",return_value=replies.get(source,record)):
                    self.assertEqual(engine.lookup(source,"TestHandle")[0],"Handle match")
                for code,outcome in [(403,"Access restricted"),(429,"Rate limited"),(404,"No record returned")]:
                    with patch("engine.fetch",side_effect=HTTPError("https://example.org",code,"",{},None)):
                        self.assertEqual(engine.lookup(source,"TestHandle")[0],outcome)
                with patch("engine.fetch",return_value={"error":"bad schema"}):
                    self.assertNotEqual(engine.lookup(source,"TestHandle")[0],"Handle match")
    def test_queries(self):
        data=dict(terms="Feneos",phrase="oral history",site="loc.gov",omit="fiction",file="pdf",after="2000-01-01",other="Goura, Gkoura",skip="example.org")
        self.assertEqual(engine.queries(data,0),["Feneos"])
        self.assertEqual(len(engine.queries(data,3)),2)
        self.assertIn('-"fiction"',engine.queries(data,3)[0])
        self.assertIn('filetype:pdf',engine.queries(data,3)[0])
        for extra in [dict(before="1999-01-01"),dict(after="2023-02-29"),dict(skip="loc.gov"),dict(site="bad domain")]:
            with self.assertRaises(ValueError):engine.queries(dict(data,**extra),3)
    def test_catalogues(self):
        with patch("engine.fetch",return_value={"message":{"items":[{"title":["Work"],"DOI":"10.1/x"}]}}):
            self.assertEqual(engine.catalogue_results("Publications","book")[0][0],"Work")
        with patch("engine.fetch",return_value={"response":{"docs":[{"identifier":"a","title":"Collection"}]}}):
            self.assertEqual(engine.catalogue_results("Archives","book")[0][1],"https://archive.org/details/a")
    def test_desktop(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=tk.Tk();root.withdraw()
            app=Workspace(root,tmp)
            for n in NAV:app.show(n);root.update()
            app.var("email").set("foxyeve@example.org")
            self.assertEqual(app.suggested(),"foxyeve")
            app.record(1,"Example","terms","Manual observation","https://example.org","Original")
            with patch("fieldindex.filedialog.asksaveasfilename",return_value=tmp+"/export.json"):app.export("json")
            with open(tmp+"/export.json",encoding="utf-8") as f:self.assertEqual(json.load(f)["entries"][0]["original_record"],"Original")
            with patch("fieldindex.simpledialog.askstring",return_value="Second case"):app.new_case()
            self.assertEqual(app.suggested(),"")
            self.assertEqual(app.db.execute("select count(*) from records where c=?",(app.case,)).fetchone()[0],0)
            for callback in root.tk.splitlist(root.tk.call('after','info')):root.after_cancel(callback)
            app.db.close();root.destroy()

if __name__=="__main__":unittest.main()

