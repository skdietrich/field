FIELD INDEX 0.11.1 — CLEAN OFFLINE WINDOWS INSTALLER BUILD KIT
================================================================

WHAT THIS IS
A verified source-and-installer BUILD KIT, not a finished Windows installer.
It is designed to produce ONE conventional Inno Setup .exe that installs a
fully bundled Python/Tkinter FieldIndex application. The resulting installer
DOES NOT download or execute Python, PowerShell, or CLI tools on the user's PC.

WHY THERE IS NO COMPILED EXE IN THIS ZIP
The current build environment is Linux without Windows/Python/Tcl runtime
assets and cannot execute Windows installers. Cross-building a tested, fully
bundled Windows Tk application here would be unreliable. Windows compilation
and Defender scanning must take place on a Windows runner.

EASIEST WAY TO BUILD (no Python install on your own PC)
1. Create a PRIVATE GitHub repository for FieldIndex.
2. Upload all files and folders from this ZIP into the repository root,
   INCLUDING .github/workflows/build-windows.yml (don't upload case databases).
3. Open Actions > Build FieldIndex offline Windows installer > Run workflow.
4. When the workflow succeeds, download the artifact named
   FieldIndex-0.11.1-offline-setup-x64-UNSIGNED.
5. Scan the downloaded EXE with Microsoft Defender before execution.
6. If Defender flags it, do NOT bypass Defender. Check the exact detection,
   submit it for independent analysis, or sign/rebuild the installer.

Result should be ONE EXE around tens of MB, with no Python installation required
on the end user's machine. This ZIP itself is not an installable application.

ALTERNATIVE: BUILD_ON_WINDOWS.ps1
Requires Python 3.13 with Tkinter and Inno Setup 6 only on the Windows BUILD PC.
The packaged end user does NOT need Python or Inno Setup. The build runs 55 tests,
creates a folder-based PyInstaller program, runs a GUI/SQLite smoke test of that
compiled program, then packages it with standard Inno Setup.

SECURITY NOTES
- Custom self-extracting bootstrap has been REMOVED.
- No run-time interpreter download, PowerShell elevation, or hidden CLI installs.
- Data is stored separately in %LOCALAPPDATA%\FieldIndex. No uninstaller deletes it.
- First launch takes a SQLite-consistent backup when an earlier DB exists.
- Sherlock/Maigret are optional THIRD-PARTY tools and are NOT silently bundled.
- An unsigned installer can still trigger antivirus or SmartScreen. Building
  cleanly does not guarantee an antivirus will accept it. Never whitelist on trust.
- Verify scripts and review the source before building.

ORIGINAL SOURCE
FieldIndex 0.11 v2 was supplied by the user. Only minimal changes were made:
app-local case database backup before schema migration, packaged GUI smoke-test
command, and truthful optional-scanner guidance for the frozen build.
The 55 application and installer-specific tests pass in the Linux virtual desktop test environment.

Rebuild and verify on Windows BEFORE describing this as a working installer.

WINDOWS TEST FIX (22 NOV 2026)
The build kit includes a fix for the SQLite backup file-handle bug exposed by
GitHub Actions on Windows (WinError 32). The application backup connection and
its verification-test connection are explicitly closed. See
WINDOWS_SQLITE_LOCK_FIX.md. This is the corrected kit. Remove the old build-kit
ZIP from the repository root before uploading this replacement, because the
existing GitHub workflow selects the first matching ZIP filename.
