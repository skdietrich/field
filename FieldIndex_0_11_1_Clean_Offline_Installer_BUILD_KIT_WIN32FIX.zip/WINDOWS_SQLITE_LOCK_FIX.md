# FieldIndex 0.11.1 Windows SQLite lock repair

GitHub Actions build failure addressed:

```
PermissionError: [WinError 32] ...cases.before_0_11_1_...sqlite3
```

Cause: Python `sqlite3.Connection` used as a `with` statement commits or
rolls back a transaction, but does not close the underlying file handle.
Windows disallows deletion of files still held open, so the temporary test
workspace could not be cleaned up.

Changes:
* `source/fieldindex.py`: always close the SQLite pre-upgrade backup connection
  with `contextlib.closing`; check backup integrity before writing completion marker.
* `source/test_clean_installer.py`: explicitly close verification connection.
* Added regression test that asserts the application's backup connection is
  truly closed, not just committed.

Build instructions: Replace the previous build-kit ZIP in the GitHub repository
root with this corrected archive. Keep the existing Windows Actions workflow.
Re-run **Build FieldIndex 0.11.1 Windows Installer** from Actions.

This is a source/test fix; the compiled Windows EXE must still build and pass
Windows smoke tests on GitHub Actions. A green CI run is not a malware-free guarantee.
