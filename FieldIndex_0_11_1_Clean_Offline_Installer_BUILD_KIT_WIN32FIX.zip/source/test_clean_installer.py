"""Verify the installer-specific first-run safety behavior."""
from __future__ import annotations

import sqlite3
from contextlib import closing
from unittest.mock import patch
import tempfile
import unittest
from pathlib import Path
import tkinter as tk

from fieldindex import Workspace


class CleanInstallerSafetyTests(unittest.TestCase):
    def test_first_launch_creates_consistent_non_destructive_backup(self):
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            root = tk.Tk()
            root.withdraw()
            first = Workspace(root, folder)
            with first.db:
                first.db.execute("INSERT INTO cases(name) VALUES(?)", ("Preserve this case",))
            first.close()
            self.assertFalse(list(folder.glob("cases.before_0_11_1_*.sqlite3")))

            second_root = tk.Tk()
            second_root.withdraw()
            second = Workspace(second_root, folder)
            backups = list(folder.glob("cases.before_0_11_1_*.sqlite3"))
            self.assertEqual(len(backups), 1)
            # A SQLite connection context manager does NOT close the connection.
            # The explicit close is required by Windows TemporaryDirectory cleanup.
            with closing(sqlite3.connect(backups[0])) as backup:
                self.assertEqual(backup.execute("PRAGMA integrity_check").fetchone()[0], "ok")
                self.assertIsNotNone(backup.execute("SELECT 1 FROM cases WHERE name=?", ("Preserve this case",)).fetchone())
            second.close()

            third_root = tk.Tk()
            third_root.withdraw()
            third = Workspace(third_root, folder)
            self.assertEqual(len(list(folder.glob("cases.before_0_11_1_*.sqlite3"))), 1)
            third.close()


    def test_migration_backup_handle_is_explicitly_closed(self):
        # Instrument the real SQLite connection, not a mock backup, to ensure
        # the actual application closes its pre-migration backup handle.
        original_connect = sqlite3.connect
        backup_connections = []

        class TrackedConnection(sqlite3.Connection):
            was_closed = False

            def close(self):
                self.was_closed = True
                return super().close()

        def connect_with_tracking(database, *args, **kwargs):
            if "cases.before_0_11_1_" in str(database):
                kwargs["factory"] = TrackedConnection
                conn = original_connect(database, *args, **kwargs)
                backup_connections.append(conn)
                return conn
            return original_connect(database, *args, **kwargs)

        with tempfile.TemporaryDirectory() as folder:
            root = tk.Tk()
            root.withdraw()
            first = Workspace(root, folder)
            first.close()

            with patch("fieldindex.sqlite3.connect", side_effect=connect_with_tracking):
                root = tk.Tk()
                root.withdraw()
                second = Workspace(root, folder)
                second.close()

            self.assertEqual(len(backup_connections), 1)
            self.assertTrue(backup_connections[0].was_closed,
                            "Backup connection must be closed before Windows cleanup")



if __name__ == "__main__":
    unittest.main()
